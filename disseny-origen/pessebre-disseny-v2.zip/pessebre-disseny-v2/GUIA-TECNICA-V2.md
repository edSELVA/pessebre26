# Pessebre de l'escola · Guia tècnica del paquet de disseny v2 (10 nov 2026)

Disseny validat per Eduard. Aquest paquet és nou i **no substitueix la v1** (que es conserva tal qual).

## 1. Contingut
| Carpeta / fitxer | Què és |
|---|---|
| `peces/*.svg` (102) + `registre.json` | Peces reutilitzables amb ancoratge i colors per variables CSS |
| `terreny/terreny.svg` | Cel, muntanyes, feixes, riu, camins, camps i decoració plana (2400×800) |
| `llum/llum-terra.svg`, `llum/llum-aire.svg` | Capes de llum estàtiques (naixement, foguera, estel, boira, vinyeta, neu) |
| `llum/LLUM-TOLL.svg`, `llum/LLUM-HALO.svg` | Peces de llum per casa ocupada (toll de llum a terra) i per fanal (halo) |
| `moments/{dia,posta,nit,neu}.css`, `moments.json` | Variables de cada moment del dia |
| `mapa.json` | 74 cases de classe + 906 participacions + 18 pastors, amb coordenades i zona |
| `escena-fixa.json` | Peces fixes (naixement, Reis, molí, pont, castell…) |
| `paletes.json` | Opcions de color per a cases i persones |
| `vistes/` | Captures de referència (escena, detalls, quatre moments) |
| `eines/` | Generadors Python (tot es pot regenerar) |

## 2. Coordenades i ancoratge
- Escena: **2400 × 800** unitats (1 unitat = 1 píxel de l'art). `shape-rendering="crispEdges"`.
- Cada peça té `viewBox` `0 0 w h` i un **ancoratge** (`registre.json → ancoratge`, també a `data-ancoratge`): el centre de la base, on toca el terra.
- Col·locar una peça a (x, y): `translate(x − ax, y − ay)`. Mirall horitzontal: `transform="matrix(-1 0 0 1 2x 0)"`.
- Ordre de dibuix: per **y creixent** (les peces més avall, a sobre). `mapa.json` ja dona x, y de cada lloc.
- Cases: viewBox 64×78, ancoratge (32, 76). Variant `-P` té placa per al nom de la classe (`registre.json → placa` dona el rectangle); `-SP` sense placa.
- Escala de figures **uniforme**: no s'escalen mai.

## 3. Colors per variables CSS
Cada forma és un `<path class="rol" fill="var(--rol, #valor)">`. Cada rol de color té **4 tons**: `--rol-clar`, `--rol`, `--rol-ombra`, `--rol-fosc` (els rols de roba i porta, 3).
Personalitzables per l'usuari (s'apliquen amb `style` a l'element `<use>` o `<svg>` de la peça):
- Cases: `facana` (4 tons), `teulada` (4), `porta` (3).
- Adults: `roba` (3), `mocador` (3). Infants: `roba2` (3).
`paletes.json` dona les opcions (cada opció és la llista de tons en l'ordre clar → fosc). Funció d'aplicació: `compon.estil(rol, opcio)`.
Els rols no personalitzables (pell, pedra, fusta, vegetació…) són globals: es poden canviar a l'arrel de l'escena (així es fan els moments del dia).
Contorn comú `--contorn`; ombra a terra `--ombra-terra` (amb opacitat pròpia).

## 4. Estats d'un lloc
- **Tancat** (zona no oberta): no es dibuixa.
- **Lliure** (zona oberta, sense ocupar): silueta fantasma de la peça (cases opacitat .62, elements .5) amb `--rol` en cru/blanc (`compon.estil_fantasma`); en mode participar, a més, marca a terra `MARCA-PER` (persona) o `MARCA-ANI` (animal).
- **Ocupat**: la peça triada amb els seus colors. Si és casa o fanal, afegir `llum/LLUM-TOLL` (a (x, y+5)) o `LLUM-HALO` (a (x, y−22)) al grup de llum.
- Cap dada sensible: els codis no s'enllacen amb alumnat (igual que a la v1).

## 5. Zones (progressives)
Z0 x 780–1820 · Z1 540–780 i 1820–2020 · Z2 270–540 i 2020–2210 · Z3 0–270 i 2210–2400 (`mapa.json → franges`). Les 74 cases de classe són a Z0 (casc antic).
Capacitat: 96 cases de família (38/21/21/16), 270 elements (106/72/50/42), 481 persones (221/106/85/69), 59 animals (14/15/15/15) = **906** + 18 pastors a la clariana (sempre oberts, torronada 21 des.).

## 6. Capes (ordre de dalt a baix de la pila, de darrere cap endavant)
1. `terreny/terreny.svg` (cel, sol, muntanyes, feixes, aigua, camins, decoració).
2. `llum/llum-terra.svg` (a terra) + els `LLUM-TOLL` de les cases ocupades.
3. Peces (ordenades per y).
4. `llum/llum-aire.svg` (boira, vinyeta, raig de l'estel, tint, neu) + els `LLUM-HALO`.
Totes les capes són 2400×800 i es posen a (0, 0). Cal copiar els `<defs>` de degradats d'una capa de llum una sola vegada si s'incrusten (ids `l-*` i `p-neu*`).

## 7. Moments del dia
Quatre: **dia, posta, nit, neu**. Només canvien colors i opacitats (cap peça canvia de forma). Posar la classe `.moment-<nom>` (o les variables de `moments/<nom>.css`) a l'arrel de l'escena.
- `nit` = valors per defecte (només opacitats).
- Variables de capa: `--op-terra`, `--op-boira`, `--op-vinyeta`, `--op-estel`, `--op-tint` (color `--tint`, barreja multiplicativa), `--op-neu`, i el sol: `--sol-op`, `--sol`, `--sol-x`, `--sol-y`.
- Cel/muntanyes: `--cel-*`, `--munt-*`. Finestres: `--llum`, `--llum-clar`, `--llum-ombra` (encesos de nit, apagats de dia).
- **Neu**: a més, l'app ha de nevar les teulades de les cases: barrejar els tons `--teulada*` de cada casa amb `#F2F7FF` al 82 % (`--teulada-fosc` al 60 %); funció de referència `moments.neu_teulada`.
Els estats (lliure/ocupat) i les zones són independents del moment.

## 8. Catàleg de peces
- Cases (20): `CASA-{LLARGA, LLARGA-C, FRONTAL, MASIA, ALTA, BAIXA, VESSANT, CUPULA, PEDRA, TERRAT}-{P,SP}`.
- Persones (15): `PER-ADU-{F, D, CISTELL, BRACOS, GERRA, BARBA, CAPELL, AVI, FANAL, LLENYA}`, `PER-PAS-F`, `PER-INF-{F, D, BRACOS, PILOTA}`.
- Animals (17): `ANI-{OVELLA, OVELLA-NEGRA, CORDER, CABRA, CABRIT, GOS, GOS-NEGRE, GALLINA, GALLINA-ROSSA, GALLINA-GRISA, GALL, ANEC, PORC, CONILL, GAT, ASE, COLOMA}-D` (miren a la dreta; mirall si cal). `ESC-BOU` i `ESC-MULA` són del naixement.
- Elements: `ELE-{ARBRE, ARBRE-2, FRUITER, TARONGER, AMETLLER, OLIVERA, FIGUERA, PI, XIPRER, XIPRER-2, PALMERA, MATA, MATA-FLOR, MATA-2, VINYA, BLAT, LLENYA, CARRO, BANC, FONT, FANAL, PARADA, PARADA-B, PALLER, TANCA, POU, MOLI-V}`.
- Escena fixa: `ESC-NAIXEMENT, MARIA, JOSEP, JESUS, ANGEL, ESTEL, FOGUERA, REI-CAMELL, MOLI-AIGUA, PONT, CASTELL, AQUEDUCTE`.
- Decoració de terra (no ocupen lloc): `DEC-ROQUES(-2), CANYES, FLORS(-G), HERBES, FUM`. Marques: `MARCA-PER`, `MARCA-ANI`.
Cada entrada de `registre.json` porta `categoria`, `viewBox`, `ancoratge`, `caixa` (rectangle opac), `rols` i `personalitzables`.

## 9. Canvis respecte de la v1 (a tenir en compte en programar)
1. Mapa 2400×800 (v1: 1900×420).
2. Quatre tons per rol (v1: dos).
3. El terreny i la llum fan servir degradats i patrons (només a terreny i llum; les peces són formes planes).
4. Dues capes de llum, a terra i d'atmosfera, i els moments del dia per variables.
5. Les figures són més grosses i amb cara; l'escala és uniforme.

## 10. Com regenerar
Des de `eines/`: `python3 peces.py ..` (peces + registre), `python3 exporta.py ..` (terreny, llum, moments), `python3 compon.py .. escena-completa moment-dia moment-posta moment-nit moment-neu` (captures). Cal Python 3 amb numpy, Pillow i Playwright (només per a les captures).

## 11. Limitacions conegudes
- Els colors i models de `vistes/` són d'exemple (aleatoris); l'app els ha de triar per participació.
- Les plaques de les cases de classe són buides: l'app hi posa el nom.
- Variants d'opció de porta/finestra/xemeneia a les cases queden fora d'aquesta versió.
