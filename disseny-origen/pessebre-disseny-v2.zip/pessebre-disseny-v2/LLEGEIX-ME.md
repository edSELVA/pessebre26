# Pessebre de l'escola · Paquet de disseny v2 (10 nov 2026)

Disseny **validat**. Llegiu `GUIA-TECNICA-V2.md`. No substitueix la v1 (paquet a part).

- `peces/` (102 SVG) + `registre.json`; `terreny/`; `llum/`; `moments/` (dia, posta, nit, neu)
- `mapa.json`, `escena-fixa.json`, `paletes.json`; `vistes/`; `eines/` (generadors)
- Regenerar des de `eines/`: `python3 peces.py ..`, `python3 exporta.py ..`, `python3 compon.py .. <vistes>`
