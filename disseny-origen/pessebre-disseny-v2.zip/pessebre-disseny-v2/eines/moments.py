"""Els quatre moments del dia: només canvien valors de variables CSS (colors i opacitats de llum).
Cap peça ni cap forma canvia. Variables d'opacitat de capa: --op-terra, --op-boira, --op-vinyeta, --op-estel, --op-tint, --op-neu, --sol-op."""
import re, os
import px

_FEIXES = ['#539640', '#5FA03F', '#6CAA3E', '#79B33E', '#84BA3F', '#8BBF41', '#86B93E', '#7CB03B', '#72A738', '#689E35']
_ARX = ['terreny.py', 'compon.py']


def defaults():
    """Variables de terreny i llum amb el seu valor per defecte (que és el moment 'nit')."""
    d = {}
    for a in _ARX:
        s = open(os.path.join(os.path.dirname(__file__), a)).read()
        for n, h in re.findall(r'var\(--([a-z0-9-]+),\s*(#[0-9A-Fa-f]{3,8})\)', s):
            d.setdefault(n, h.upper())
    for k, h in enumerate(_FEIXES):
        d[f'feixa-{k + 1}'] = h.upper()
    return d


def mix(h, a, k):
    h = h.lstrip('#')[:6]; a = a.lstrip('#')[:6]
    c = [round(int(h[i:i + 2], 16) * (1 - k) + int(a[i:i + 2], 16) * k) for i in (0, 2, 4)]
    return '#%02X%02X%02X' % tuple(c)


NEU = '#F2F7FF'
OPS_NIT = {'op-terra': 1, 'op-boira': 1, 'op-vinyeta': 1, 'op-estel': 1, 'op-tint': 0, 'op-neu': 0, 'sol-op': 0}

MOMENTS = {
    'nit': {'nom': 'Nit de Nadal', 'v': dict(OPS_NIT)},
    'dia': {'nom': 'Dia', 'v': {
        'cel-alt': '#3E86D8', 'cel-mig': '#6BAAE8', 'cel-baix': '#A8D4F2', 'cel-horitzo': '#F4EBC8',
        'munt-lluny': '#A9C0E0', 'munt-boira': '#D8E4EE', 'munt-mig': '#8DA8D0', 'munt-boira2': '#C4D4E8', 'munt-prop': '#6C8CB6', 'munt-boira3': '#A4BCDA',
        'estel-fi': '#FFFFFF00', 'estel-fi2': '#FFFFFF00', 'boira': '#C8DCF0', 'nit': '#0A1040', 'llum-calida': '#FFF0B8',
        'turo': '#3F8A52', 'turo-baix': '#5FA856', 'turo-llum': '#6CB563', 'turo-ombra': '#2E6A48',
        'llum-clar': '#A8BCD2', 'llum': '#7890AC', 'llum-ombra': '#50627E',
        'sol': '#FFF3B0', 'sol-x': '430px', 'sol-y': '84px',
        **{**OPS_NIT, 'op-terra': .25, 'op-boira': .55, 'op-vinyeta': 0, 'op-estel': 0, 'sol-op': 1}}},
    'posta': {'nom': 'Posta de sol', 'v': {
        'cel-alt': '#3A3A8C', 'cel-mig': '#8E4C90', 'cel-baix': '#EA7A5C', 'cel-horitzo': '#FFC878',
        'munt-lluny': '#C46C8C', 'munt-boira': '#F29C7C', 'munt-mig': '#8C4E88', 'munt-boira2': '#C4667E', 'munt-prop': '#503C7A', 'munt-boira3': '#80507E',
        'estel-fi': '#FFFFFF70', 'estel-fi2': '#FFE9A870', 'boira': '#E8806C', 'nit': '#2A1050', 'llum-calida': '#FFC070',
        'turo': '#2F6A50', 'turo-baix': '#4C8A4C', 'sol': '#FFD890', 'sol-x': '1940px', 'sol-y': '172px', 'tint': '#FFC088',
        **{**OPS_NIT, 'op-terra': .85, 'op-boira': .8, 'op-vinyeta': .45, 'op-estel': .4, 'op-tint': .32, 'sol-op': 1}}},
    'neu': {'nom': 'Neu', 'v': {
        'cel-alt': '#2C3E6C', 'cel-mig': '#4C6696', 'cel-baix': '#8CA6CA', 'cel-horitzo': '#D6E0EE',
        'munt-lluny': '#C8D4EA', 'munt-boira': '#E6EEF8', 'munt-mig': '#B0C0DC', 'munt-boira2': '#D4E0F0', 'munt-prop': '#94A8CC', 'munt-boira3': '#BCCCE4',
        'estel-fi': '#FFFFFFAA', 'estel-fi2': '#FFFFFFAA', 'boira': '#B8CAEA', 'nit': '#1A2450',
        'aigua': '#9CC4E4', 'aigua-clar': '#CFE6F6', 'aigua-fons': '#86B0D6', 'aigua-ombra': '#6E98C2', 'aigua-llum': '#EEF8FF',
        **{**OPS_NIT, 'op-vinyeta': .5, 'op-boira': .6, 'op-estel': .8, 'op-neu': 1}}},
}
_NEU_K = [('feixa', .78), ('herba', .8), ('turo', .72), ('vinya', .7), ('brot', .75), ('fulla', .74), ('xiprer', .5), ('cami', .62),
          ('empedrat', .5), ('mur', .38), ('solc', .6), ('riba', .6), ('pedra', .3), ('tronc', .12), ('teulada', .8)]


def variables(moment):
    """Valors de totes les variables per a un moment (diccionari nom -> valor)."""
    base = defaults()
    for n, (h, op) in px.ROLS.items():
        if n.startswith(('fulla', 'xiprer', 'llum', 'herba', 'aigua', 'tronc')) and not n.startswith('llum-calida'):
            base.setdefault(n, h.upper())
    out = {}
    if moment == 'neu':
        for n, h in base.items():
            for pre, k in _NEU_K:
                if n.startswith(pre):
                    out[n] = mix(h, NEU, k); break
    out.update({k: v for k, v in MOMENTS[moment]['v'].items()})
    return out


def neu_teulada(estil_css):
    """Teulades nevades: barreja els tons --teulada* d'una peça amb blanc (el fa l'app en moment 'neu')."""
    return re.sub(r'(--teulada[a-z-]*:)(#[0-9A-Fa-f]{6})', lambda m: m.group(1) + mix(m.group(2), NEU, .82 if m.group(1) != '--teulada-fosc:' else .6), estil_css)


def css(moment, selector=None):
    sel = selector or f'.moment-{moment}'
    return sel + ' {\n' + ''.join(f'  --{k}: {v};\n' for k, v in sorted(variables(moment).items())) + '}\n'


def style(moment):
    return ';'.join(f'--{k}:{v}' for k, v in variables(moment).items())
