"""Variants noves v2: animals, elements i figures addicionals."""
import math
from px import Llenc, RNG, rol
import figures as F
import natura as N
from figures import _ombra

for n, h in {'llana-neg-clar': '#6E6A78', 'llana-neg': '#4A4654', 'llana-neg-ombra': '#322F3C',
             'oliva-llum': '#C8D68A', 'oliva-clar': '#9FB86A', 'oliva': '#7A9660', 'oliva-ombra': '#587348', 'oliva-fosc': '#3C5236',
             'rosa': '#F2A6A0', 'rosa-ombra': '#D27C7C', 'blat': '#E8C45A'}.items():
    rol(n, h)


def corder():
    cv = Llenc(14, 11)
    for (cx, cy, r) in [(4, 5, 3), (7, 4, 3), (7, 6, 3)]:
        cv.ellipse(cx, cy, r, r * .85, 'llana')
    cv.hl(3, 7, 7, 'llana-ombra'); cv.p(6, 2, 'blanc'); cv.p(4, 3, 'blanc')
    cv.rect(9, 3, 3, 3, 'pell'); cv.p(11, 5, 'pell-ombra'); cv.p(10, 4, 'contorn'); cv.rect(8, 2, 2, 2, 'llana')
    for x in (4, 6, 8):
        cv.vl(x, 8, 2, 'gris-ombra')
    cv.contorn(); _ombra(cv, 2, 10, 10)
    return cv


def cabrit():
    cv = Llenc(16, 13)
    cv.rect(3, 4, 8, 4, 'bru-clar'); cv.hl(3, 4, 8, 'camell-clar'); cv.hl(3, 7, 8, 'bru'); cv.rect(3, 5, 3, 2, 'blanc')
    cv.rect(10, 2, 3, 4, 'bru-clar'); cv.p(13, 4, 'bru-clar'); cv.p(11, 3, 'contorn'); cv.vl(10, 0, 2, 'gris-clar'); cv.vl(12, 1, 1, 'gris-clar')
    for x in (4, 6, 8, 10):
        cv.vl(x, 8, 3, 'bru-ombra')
    cv.contorn(); _ombra(cv, 2, 12, 12)
    return cv


def porc():
    cv = Llenc(24, 16)
    cv.rect(3, 4, 14, 7, 'rosa'); cv.hl(4, 3, 12, 'rosa'); cv.hl(3, 10, 14, 'rosa-ombra'); cv.hl(4, 4, 6, 'blanc-ombra'); cv.vl(16, 4, 7, 'rosa-ombra')
    cv.rect(16, 4, 5, 6, 'rosa'); cv.rect(19, 7, 3, 3, 'rosa-ombra'); cv.p(20, 8, 'contorn'); cv.p(18, 5, 'contorn'); cv.rect(16, 2, 3, 2, 'rosa-ombra'); cv.p(2, 5, 'rosa-ombra'); cv.p(1, 4, 'rosa-ombra')
    for x in (4, 6, 13, 15):
        cv.rect(x, 11, 2, 3, 'rosa-ombra')
    cv.contorn(); _ombra(cv, 3, 19, 15)
    return cv


def conill():
    cv = Llenc(14, 14)
    cv.rect(3, 6, 7, 5, 'gris-clar'); cv.hl(3, 10, 7, 'gris'); cv.rect(2, 7, 2, 3, 'blanc')
    cv.rect(8, 4, 4, 4, 'gris-clar'); cv.p(11, 6, 'contorn'); cv.p(12, 7, 'rosa'); cv.rect(8, 0, 2, 5, 'gris-clar'); cv.rect(10, 1, 1, 3, 'gris'); cv.p(9, 1, 'rosa')
    cv.hl(4, 11, 3, 'gris'); cv.hl(8, 11, 3, 'gris')
    cv.contorn(); _ombra(cv, 2, 11, 13)
    return cv


def gat():
    cv = Llenc(18, 14)
    cv.rect(3, 6, 8, 5, 'camell'); cv.hl(3, 6, 8, 'camell-clar'); cv.hl(3, 10, 8, 'camell-ombra'); cv.hl(5, 8, 4, 'camell-ombra'); cv.vl(6, 7, 3, 'camell-ombra')
    cv.rect(10, 3, 4, 4, 'camell'); cv.p(10, 2, 'camell'); cv.p(13, 2, 'camell'); cv.p(13, 4, 'contorn'); cv.p(11, 4, 'contorn'); cv.hl(11, 6, 2, 'blanc')
    cv.vl(2, 1, 6, 'camell-ombra'); cv.p(3, 0, 'camell-ombra'); cv.p(1, 0, 'camell-ombra')
    for x in (4, 6, 9, 10):
        cv.vl(x, 11, 1, 'camell-ombra')
    cv.contorn(); _ombra(cv, 2, 14, 13)
    return cv


def ase():
    cv = Llenc(30, 22)
    cv.rect(4, 8, 15, 7, 'gris'); cv.hl(4, 8, 15, 'gris-clar'); cv.hl(4, 14, 15, 'gris-ombra'); cv.rect(5, 5, 11, 1, 'gris')
    cv.rect(17, 5, 4, 7, 'gris'); cv.rect(20, 3, 6, 6, 'gris'); cv.hl(20, 3, 6, 'gris-clar'); cv.rect(24, 6, 3, 4, 'blanc-ombra'); cv.p(26, 8, 'contorn'); cv.p(22, 5, 'contorn')
    cv.rect(19, 0, 2, 4, 'gris'); cv.rect(22, 0, 2, 4, 'gris-ombra'); cv.p(20, 1, 'rosa')
    cv.vl(3, 9, 6, 'gris-ombra'); cv.p(2, 15, 'gris-ombra'); cv.hl(5, 8, 8, 'bru-clar')
    for x in (6, 8, 14, 16):
        cv.rect(x, 15, 2, 5, 'gris-ombra'); cv.hl(x, 20, 2, 'contorn')
    cv.contorn(); _ombra(cv, 2, 23, 21)
    return cv


def gall():
    cv = Llenc(14, 15)
    cv.rect(3, 6, 6, 4, 'vermell'); cv.hl(3, 6, 5, 'foc'); cv.hl(4, 9, 5, 'vermell-ombra'); cv.rect(1, 3, 3, 5, 'verd'); cv.vl(1, 3, 5, 'verd-ombra'); cv.p(2, 2, 'groc')
    cv.rect(8, 3, 3, 4, 'bru'); cv.p(9, 4, 'contorn'); cv.p(11, 5, 'groc'); cv.p(8, 1, 'vermell'); cv.p(9, 2, 'vermell'); cv.p(10, 2, 'vermell'); cv.p(10, 7, 'vermell')
    cv.hl(5, 6, 4, 'groc')
    cv.vl(5, 11, 2, 'groc-ombra'); cv.vl(7, 11, 2, 'groc-ombra'); cv.hl(4, 13, 2, 'groc-ombra'); cv.hl(7, 13, 2, 'groc-ombra')
    cv.contorn(); _ombra(cv, 2, 10, 14)
    return cv


def coloma():
    cv = Llenc(14, 11)
    cv.rect(2, 4, 7, 4, 'blanc'); cv.hl(2, 7, 7, 'blanc-ombra'); cv.hl(3, 3, 4, 'blanc'); cv.rect(1, 5, 2, 2, 'blanc-ombra')
    cv.rect(8, 2, 3, 3, 'blanc'); cv.p(11, 3, 'groc-ombra'); cv.p(9, 3, 'contorn'); cv.hl(4, 4, 3, 'gris-clar')
    cv.vl(4, 8, 2, 'rosa-ombra'); cv.vl(6, 8, 2, 'rosa-ombra')
    cv.contorn(); _ombra(cv, 2, 9, 10)
    return cv


# ----------------------------------------------------------- elements
def olivera(seed=2):
    rng = RNG(seed); w, h = 34, 34; cv = Llenc(w, h); cx = w // 2
    N.tronc(cv, cx, 18, h - 4, g=5)
    cv.rect(cx - 5, 20, 3, 8, 'tronc-ombra') if False else None
    to = ('oliva-llum', 'oliva-clar', 'oliva', 'oliva-ombra', 'oliva-fosc')
    R = w / 2 - 2
    blobs = [(cx - 9, 11, 7, 5), (cx + 9, 11, 7, 5), (cx, 8, 9, 6), (cx - 4, 14, 8, 5), (cx + 5, 15, 8, 4), (cx - 11, 16, 5, 3), (cx + 11, 16, 5, 3)]
    N.copa(cv, blobs, to=to, rng=rng, vora='oliva-fosc')
    for _ in range(9):
        x, y = rng.randint(8, w - 9), rng.randint(8, 18)
        if cv.get(x, y) in ('oliva', 'oliva-clar'):
            cv.p(x, y, 'fulla-fosc')
    N.ombra(cv, cx + 2, h - 3, 11)
    return cv


def figuera(seed=3):
    rng = RNG(seed); w, h = 36, 32; cv = Llenc(w, h); cx = w // 2
    N.tronc(cv, cx, 18, h - 4, g=4)
    blobs = [(cx - 9, 11, 8, 6), (cx + 9, 11, 8, 6), (cx, 8, 10, 7), (cx - 5, 15, 8, 5), (cx + 6, 15, 8, 5)]
    N.copa(cv, blobs, to=('fulla-llum', 'fulla-clar', 'fulla-clar', 'fulla', 'fulla-ombra'), rng=rng, vora='fulla-fosc')
    for (x, y) in [(10, 12), (14, 16), (23, 15), (26, 11), (19, 11)]:
        cv.p(x, y, 'lila'); cv.p(x + 1, y, 'lila'); cv.p(x, y + 1, 'lila-ombra'); cv.p(x + 1, y + 1, 'lila-ombra')
    N.ombra(cv, cx + 2, h - 3, 11)
    return cv


def vinya(seed=4):
    rng = RNG(seed); w, h = 40, 18; cv = Llenc(w, h)
    for x in (3, 19, 35):
        cv.vl(x, 4, 11, 'fusta'); cv.p(x, 4, 'fusta-clar')
    cv.hl(3, 6, 33, 'fusta-ombra'); cv.hl(3, 11, 33, 'fusta-ombra')
    for cx in (9, 14, 25, 30):
        N.copa(cv, [(cx, 8, 5, 5), (cx - 2, 11, 4, 3), (cx + 2, 11, 4, 3)], to=('fulla-llum', 'fulla-clar', 'fulla', 'fulla-ombra', 'fulla-fosc'), rng=rng, vora='fulla-fosc')
        cv.rect(cx - 1, 11, 2, 3, 'lila'); cv.hl(cx - 1, 14, 2, 'lila-ombra'); cv.p(cx, 11, 'flor-clar')
    for x in range(2, 38):
        if cv.get(x, 15) is None:
            cv.p(x, 15, 'herba-ombra')
    cv.hl(2, 16, 36, 'ombra-terra')
    return cv


def carro():
    cv = Llenc(36, 26)
    cv.rect(4, 11, 24, 5, 'fusta'); cv.hl(4, 11, 24, 'fusta-clar'); cv.hl(4, 15, 24, 'fusta-ombra'); cv.vl(10, 11, 5, 'fusta-ombra'); cv.vl(18, 11, 5, 'fusta-ombra'); cv.vl(26, 11, 5, 'fusta-ombra')
    for (cx, cy, r) in [(10, 8, 7), (18, 6, 8), (25, 8, 7), (14, 9, 5), (21, 9, 5)]:
        cv.ellipse(cx, cy, r, r * .6, 'palla')
    for (x, y) in [(8, 5), (14, 3), (20, 4), (24, 6), (11, 8), (18, 8)]:
        cv.hl(x, y, 3, 'palla-clar')
    for (x, y) in [(10, 9), (16, 7), (22, 9), (13, 4)]:
        cv.hl(x, y, 3, 'palla-ombra')
    cv.hl(28, 14, 7, 'fusta'); cv.hl(28, 15, 7, 'fusta-ombra')
    cv.ellipse(14, 19, 5.5, 5.5, 'fusta-ombra'); cv.ellipse(14, 19, 3.5, 3.5, 'fusta'); cv.ellipse(14, 19, 1, 1, 'fusta-ombra'); cv.vl(14, 15, 9, 'fusta-ombra'); cv.hl(10, 19, 9, 'fusta-ombra')
    cv.contorn(); _ombra(cv, 6, 30, 24)
    return cv


def banc():
    cv = Llenc(22, 12)
    cv.rect(2, 3, 18, 2, 'pedra-clar'); cv.hl(2, 4, 18, 'pedra'); cv.hl(2, 5, 18, 'pedra-ombra')
    cv.rect(3, 6, 3, 3, 'pedra'); cv.rect(16, 6, 3, 3, 'pedra'); cv.vl(5, 6, 3, 'pedra-ombra'); cv.vl(18, 6, 3, 'pedra-ombra')
    cv.contorn(); _ombra(cv, 2, 19, 10)
    return cv


def font():
    cv = Llenc(26, 24)
    cv.rect(2, 14, 22, 6, 'pedra'); cv.hl(2, 14, 22, 'pedra-clar'); cv.hl(2, 19, 22, 'pedra-ombra'); cv.vl(2, 14, 6, 'pedra-clar'); cv.vl(23, 14, 6, 'pedra-fosc')
    cv.rect(4, 15, 18, 2, 'aigua'); cv.hl(6, 15, 6, 'aigua-clar'); cv.hl(14, 16, 5, 'aigua-ombra')
    cv.rect(11, 5, 4, 10, 'pedra'); cv.vl(11, 5, 10, 'pedra-clar'); cv.vl(14, 5, 10, 'pedra-ombra'); cv.hl(10, 4, 6, 'pedra-clar'); cv.hl(10, 5, 6, 'pedra')
    cv.vl(13, 0, 5, 'aigua-clar'); cv.vl(12, 1, 4, 'escuma'); cv.p(10, 3, 'aigua-clar'); cv.p(16, 3, 'aigua-clar'); cv.p(9, 6, 'aigua-clar'); cv.p(17, 6, 'aigua-clar')
    cv.contorn(); _ombra(cv, 2, 23, 22)
    return cv


def llenya():
    cv = Llenc(24, 14)
    cv.rect(2, 3, 20, 8, 'fusta'); cv.hl(2, 3, 20, 'fusta-clar'); cv.hl(2, 10, 20, 'fusta-ombra')
    for r in range(3):
        for k in range(5):
            x = 4 + k * 4 + (r % 2) * 2; y = 4 + r * 2 + (r > 0)
            cv.p(x, y, 'tronc-clar'); cv.p(x + 1, y, 'tronc-clar'); cv.p(x, y + 1, 'tronc-ombra')
    cv.hl(2, 7, 20, 'fusta-ombra'); cv.vl(2, 3, 8, 'tronc-ombra'); cv.vl(21, 3, 8, 'tronc-ombra')
    cv.contorn(); _ombra(cv, 1, 22, 12)
    return cv


def blat(seed=5):
    rng = RNG(seed); cv = Llenc(26, 16)
    for x in range(2, 24, 2):
        h = rng.randint(5, 9)
        cv.vl(x, 13 - h, h, 'palla'); cv.vl(x + 1, 13 - h, h, 'palla-ombra')
        cv.hl(x, 12 - h, 2, 'palla-clar'); cv.p(x, 11 - h, 'palla-clar')
    cv.hl(2, 14, 22, 'herba-ombra')
    return cv


def totes():
    ad = F.adult
    return {
        'PER-ADU-CAPELL': ad('F', capell=True), 'PER-ADU-AVI': ad('A', barba=False), 'PER-ADU-FANAL': ad('L'), 'PER-ADU-LLENYA': ad('W'),
        'PER-INF-BRACOS': F.infant('B'), 'PER-INF-PILOTA': F.infant('Q'),
        'ANI-OVELLA-NEGRA-D': F.ovella('llana-neg', 'llana-neg-ombra', 'llana-neg-clar', 'gris'), 'ANI-CORDER-D': corder(), 'ANI-CABRIT-D': cabrit(),
        'ANI-GOS-NEGRE-D': F.gos('bru-ombra', 'contorn', 'bru'), 'ANI-GALLINA-ROSSA-D': F.gallina('camell'), 'ANI-GALLINA-GRISA-D': F.gallina('gris'),
        'ANI-GALL-D': gall(), 'ANI-PORC-D': porc(), 'ANI-CONILL-D': conill(), 'ANI-GAT-D': gat(), 'ANI-ASE-D': ase(), 'ANI-COLOMA-D': coloma(),
        'ELE-OLIVERA': olivera(), 'ELE-FIGUERA': figuera(), 'ELE-VINYA': vinya(), 'ELE-CARRO': carro(), 'ELE-BANC': banc(), 'ELE-FONT': font(),
        'ELE-LLENYA': llenya(), 'ELE-BLAT': blat(),
    }
