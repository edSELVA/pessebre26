"""Vegetació i elements naturals del pessebre v2."""
import math
import numpy as np
from px import Llenc, RNG, pedres, _id


def copa(cv, blobs, to=('fulla-llum', 'fulla-clar', 'fulla', 'fulla-ombra', 'fulla-fosc'), rng=None, fruit=None, vora=None):
    """Copa feta de bonys; cada bony té llum a dalt a l'esquerra."""
    ll, cl, ba, om, fo = to
    tot = np.zeros_like(cv.g, bool)
    for (cx, cy, rx, ry) in blobs:
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                dx, dy = (x - cx) / rx, (y - cy) / ry
                d = dx * dx + dy * dy
                if d > 1 or not (0 <= x < cv.w and 0 <= y < cv.h):
                    continue
                v = -dx * .55 - dy * .85
                c = ba
                if d > .78 and v < .1: c = om
                if v < -.5: c = om
                if v < -.8 and d > .5: c = fo
                if v > .38: c = cl
                if v > .72 and d < .9: c = ll
                if rng and rng.random() < .07: c = {ba: cl, cl: ba, om: ba, ll: cl, fo: om}[c]
                cv.g[y, x] = _id(c)
                tot[y, x] = True
    if fruit:
        ys, xs = np.nonzero(tot)
        for _ in range(len(ys) // 38):
            i = rng.randrange(len(ys))
            x, y = xs[i], ys[i]
            if tot[max(0, y - 1), x] and tot[min(cv.h - 1, y + 1), x] and x + 1 < cv.w and tot[y, x + 1]:
                cv.p(x, y, fruit); cv.p(x + 1, y, fruit); cv.p(x, y + 1, fruit); cv.p(x + 1, y + 1, fruit + '-ombra' if fruit == 'flor' else fruit)
                cv.p(x, y, fruit + '-clar')
    # contorn de la copa
    f = tot
    v = np.zeros_like(f)
    v[1:, :] |= f[:-1, :]; v[:-1, :] |= f[1:, :]; v[:, 1:] |= f[:, :-1]; v[:, :-1] |= f[:, 1:]
    cv.g[v & ~f] = _id(vora or fo)
    return tot


def tronc(cv, cx, y0, y1, g=4, forca=True):
    for y in range(y0, y1 + 1):
        w = g + (1 if y > y1 - 2 else 0)
        x = cx - w // 2
        cv.hl(x, y, w, 'tronc'); cv.p(x, y, 'tronc-clar'); cv.p(x + w - 1, y, 'tronc-ombra')
        cv.p(x - 1, y, 'contorn'); cv.p(x + w, y, 'contorn')
    cv.hl(cx - g // 2 - 1, y1 + 1, g + 3, 'contorn')
    if forca:
        for i in range(1, 6):
            cv.p(cx - 1 - i, y0 - i + 2, 'tronc'); cv.p(cx - 2 - i, y0 - i + 2, 'contorn'); cv.p(cx - 1 - i, y0 - i + 3, 'tronc-ombra')
            cv.p(cx + i, y0 - i + 2, 'tronc-ombra'); cv.p(cx + 1 + i, y0 - i + 2, 'contorn')


def ombra(cv, cx, y, rx):
    for x in range(int(cx - rx), int(cx + rx) + 1):
        for yy in (y, y + 1):
            if cv.get(x, yy) is None and (yy == y or abs(x - cx) < rx - 2):
                cv.p(x, yy, 'ombra-terra')


def arbre(seed, w=34, h=44, fruit=None, xip=False):
    rng = RNG(seed); cv = Llenc(w, h); cx = w // 2
    tronc(cv, cx, h - 16, h - 4, g=4)
    R = w / 2 - 2
    blobs = []
    for i in range(7):
        a = rng.random() * 6.28
        r = rng.random() * R * .55
        blobs.append((cx + math.cos(a) * r, (h - 16) * .52 + math.sin(a) * r * .8, R * rng.uniform(.42, .6), R * rng.uniform(.38, .52)))
    blobs.sort(key=lambda b: b[1])
    blobs.append((cx - R * .35, (h - 16) * .78, R * .5, R * .36))
    blobs.append((cx + R * .35, (h - 16) * .8, R * .5, R * .34))
    copa(cv, blobs, rng=rng, fruit=fruit)
    ombra(cv, cx + 2, h - 3, w * .36)
    return cv


def pi(seed):
    rng = RNG(seed); w, h = 36, 50; cv = Llenc(w, h); cx = w // 2
    tronc(cv, cx, 16, h - 4, g=3, forca=True)
    to = ('xiprer-clar', 'fulla', 'xiprer-clar', 'xiprer', 'xiprer-fosc')
    to = ('fulla-clar', 'fulla', 'xiprer-clar', 'xiprer', 'xiprer-ombra')
    blobs = [(cx - 8, 13, 8, 6), (cx + 8, 13, 8, 6), (cx, 9, 10, 7), (cx - 4, 14, 7, 5), (cx + 5, 15, 7, 4)]
    copa(cv, blobs, to=to, rng=rng, vora='xiprer-fosc')
    ombra(cv, cx + 2, h - 3, 11)
    return cv


def xiprer(seed, h=40):
    rng = RNG(seed); w = 14; cv = Llenc(w, h); cx = w // 2
    cv.rect(cx - 1, h - 6, 2, 3, 'tronc'); cv.p(cx - 2, h - 5, 'contorn'); cv.p(cx + 1, h - 5, 'contorn'); cv.p(cx - 2, h - 4, 'contorn'); cv.p(cx + 1, h - 4, 'contorn')
    for y in range(1, h - 5):
        t = y / (h - 6)
        r = 1 + 4.2 * math.sin(min(1, t * 1.15) * math.pi * .62) ** .8
        r += (y % 3 == 0) * .7
        for x in range(int(cx - r), int(cx + r) + 1):
            dx = (x - cx + .5) / r
            c = 'xiprer'
            if dx < -.35: c = 'xiprer-clar'
            if dx > .3: c = 'xiprer-ombra'
            if dx > .7: c = 'xiprer-fosc'
            if rng.random() < .08: c = 'xiprer-clar' if c == 'xiprer' else 'xiprer'
            cv.p(x, y, c)
    cv.contorn('xiprer-fosc')
    ombra(cv, cx + 1, h - 3, 5)
    return cv


def palmera(seed):
    rng = RNG(seed); w, h = 36, 46; cv = Llenc(w, h); cx = w // 2
    for y in range(18, h - 3):
        x = cx - 1 + round(2 * math.sin((y - 18) / 9))
        cv.hl(x, y, 3, 'tronc'); cv.p(x, y, 'tronc-clar');
        if y % 3 == 0: cv.hl(x, y, 3, 'tronc-ombra')
        cv.p(x - 1, y, 'contorn'); cv.p(x + 3, y, 'contorn')
    for k, (ang, L) in enumerate([(-2.9, 15), (-2.4, 16), (-1.9, 14), (-1.25, 14), (-.75, 16), (-.25, 15), (.2, 12), (2.95, 12)]):
        for i in range(L):
            t = i / L
            x = cx + math.cos(ang) * i
            y = 17 + math.sin(ang) * i + t * t * 9
            c = ['fulla-clar', 'fulla', 'fulla-ombra'][(k + (1 if t > .6 else 0)) % 3]
            for d in (0, 1):
                cv.p(int(x), int(y) + d, c)
            if i % 2 == 0 and i > 2:
                cv.p(int(x), int(y) + 2, 'fulla-ombra'); cv.p(int(x), int(y) - 1, 'fulla-llum' if math.sin(ang) < -.5 else 'fulla-clar')
    cv.rect(cx - 2, 16, 4, 3, 'taronja'); cv.p(cx - 2, 16, 'groc')
    cv.contorn('fulla-fosc')
    ombra(cv, cx + 1, h - 3, 8)
    return cv


def mata(seed, w=16, h=11, flor=None):
    rng = RNG(seed); cv = Llenc(w, h)
    blobs = [(w * .3, h * .55, w * .28, h * .34), (w * .68, h * .56, w * .28, h * .32), (w * .5, h * .42, w * .3, h * .36)]
    copa(cv, blobs, rng=rng, fruit=flor)
    return cv


def roques(seed, n=3):
    rng = RNG(seed); w, h = 22, 12; cv = Llenc(w, h)
    x = 1
    for i in range(n):
        rw = rng.randint(5, 8); rh = rng.randint(4, 7)
        y0 = h - 2 - rh
        cv.rect(x + 1, y0, rw - 2, rh, 'gris-clar'); cv.rect(x, y0 + 1, rw, rh - 1, 'gris-clar')
        cv.rect(x + rw // 2, y0 + 1, rw - rw // 2, rh - 1, 'gris'); cv.hl(x, y0 + rh - 1, rw, 'gris-ombra'); cv.p(x + 1, y0, 'blanc-ombra'); cv.p(x + 2, y0, 'blanc-ombra')
        x += rw - 1
        if x > w - 8: break
    cv.contorn('gris-ombra')
    cv.substitueix('gris-ombra', 'gris-ombra')
    return cv


def canyes(seed):
    rng = RNG(seed); w, h = 14, 18; cv = Llenc(w, h)
    for i, x in enumerate([2, 5, 8, 11]):
        hh = rng.randint(10, 15)
        cv.vl(x, h - hh, hh, 'fulla-ombra' if i % 2 else 'fulla')
        cv.rect(x, h - hh - 1, 1, 4, 'taronja'); cv.p(x, h - hh - 1, 'groc')
        cv.linia(x, h - 4, x + rng.choice([-2, 2]), h - 9, 'fulla-clar')
    return cv


def flors(seed, c='flor'):
    rng = RNG(seed); w, h = 12, 6; cv = Llenc(w, h)
    for _ in range(5):
        x = rng.randint(1, w - 2); y = rng.randint(1, h - 2)
        cv.p(x, y + 1, 'fulla-ombra'); cv.p(x, y, c); cv.p(x - 1, y, c + '-clar' if c == 'flor' else c)
    return cv


def herbes(seed):
    rng = RNG(seed); w, h = 9, 5; cv = Llenc(w, h)
    for x in (1, 3, 4, 6, 7):
        hh = rng.randint(2, 4)
        cv.vl(x, h - hh, hh, rng.choice(['herba-ombra', 'fulla', 'herba-clar']))
    return cv


def totes():
    return {
        'ELE-ARBRE': arbre(1), 'ELE-ARBRE-2': arbre(5, w=30, h=40), 'ELE-FRUITER': arbre(3, w=26, h=34, fruit='fruit'),
        'ELE-TARONGER': arbre(9, w=24, h=32, fruit='groc'), 'ELE-AMETLLER': arbre(4, w=28, h=36, fruit='flor'),
        'ELE-PI': pi(2), 'ELE-XIPRER': xiprer(1), 'ELE-XIPRER-2': xiprer(2, h=32), 'ELE-PALMERA': palmera(1),
        'ELE-MATA': mata(1), 'ELE-MATA-FLOR': mata(2, w=18, h=12, flor='flor'), 'ELE-MATA-2': mata(3, w=12, h=9),
        'DEC-ROQUES': roques(1), 'DEC-ROQUES-2': roques(2, 2), 'DEC-CANYES': canyes(1), 'DEC-FLORS': flors(1), 'DEC-FLORS-G': flors(2, 'groc'), 'DEC-HERBES': herbes(1),
    }
