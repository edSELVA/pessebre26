"""Persones i animals del pessebre v2 (escala uniforme)."""
import math
from px import Llenc, RNG


def _ombra(cv, x0, x1, y):
    for x in range(x0, x1 + 1):
        if cv.get(x, y) is None:
            cv.p(x, y, 'ombra-terra')
        if x0 < x < x1 and cv.get(x, y + 1) is None:
            cv.p(x, y + 1, 'ombra-terra')


def adult(mena='F', barba=False, turbant=False, capell=False):
    cv = Llenc(18, 27)
    o = 1  # desplaçament x
    # --- túnica
    cv.rect(o + 4, 10, 8, 6, 'roba'); cv.rect(o + 3, 16, 10, 6, 'roba')
    cv.vl(o + 4, 10, 6, 'roba-clar'); cv.vl(o + 3, 16, 5, 'roba-clar')
    cv.vl(o + 11, 10, 6, 'roba-ombra'); cv.vl(o + 12, 16, 6, 'roba-ombra')
    cv.hl(o + 3, 21, 10, 'roba-ombra'); cv.vl(o + 8, 17, 4, 'roba-ombra'); cv.vl(o + 6, 18, 3, 'roba-clar')
    cv.hl(o + 4, 14, 8, 'roba-ombra'); cv.p(o + 7, 14, 'or'); cv.p(o + 7, 15, 'or-ombra')
    # peus
    cv.hl(o + 4, 22, 3, 'fusta-ombra'); cv.hl(o + 9, 22, 3, 'fusta-ombra')
    # --- cap
    cv.rect(o + 5, 4, 6, 5, 'pell'); cv.hl(o + 6, 9, 4, 'pell-ombra')
    cv.p(o + 6, 6, 'contorn'); cv.p(o + 9, 6, 'contorn')
    cv.p(o + 5, 7, 'pell-ombra'); cv.p(o + 10, 7, 'pell-ombra')
    if mena == 'D':  # perfil cap a la dreta
        cv.rect(o + 5, 4, 3, 5, 'mocador'); cv.p(o + 6, 6, 'mocador'); cv.p(o + 9, 6, 'pell'); cv.p(o + 10, 6, 'contorn')
        cv.p(o + 11, 7, 'pell'); cv.p(o + 10, 7, 'pell')
    if barba:
        cv.rect(o + 5, 7, 6, 3, 'cabell'); cv.hl(o + 6, 10, 4, 'cabell-ombra'); cv.hl(o + 7, 7, 2, 'pell')
        if mena == 'D':
            cv.rect(o + 5, 7, 3, 3, 'mocador')
    # mocador / turbant / capell de palla
    if capell:
        cv.rect(o + 4, 1, 8, 3, 0 if False else 'cabell'); cv.rect(o + 4, 1, 8, 3, 'cabell')
        cv.vl(o + 4, 4, 3, 'cabell'); cv.vl(o + 11, 4, 3, 'cabell-ombra')
        cv.rect(o + 5, 0, 6, 2, 'palla'); cv.hl(o + 5, 0, 6, 'palla-clar'); cv.hl(o + 5, 1, 6, 'fusta')
        cv.hl(o + 1, 2, 14, 'palla'); cv.hl(o + 1, 3, 14, 'palla-ombra'); cv.hl(o + 1, 2, 4, 'palla-clar')
    else:
        cv.rect(o + 5, 1, 6, 1, 'mocador-clar'); cv.rect(o + 4, 2, 8, 2, 'mocador')
        cv.hl(o + 4, 2, 3, 'mocador-clar'); cv.hl(o + 9, 3, 3, 'mocador-ombra')
        if turbant:
            cv.rect(o + 3, 2, 10, 2, 'mocador'); cv.hl(o + 3, 3, 10, 'mocador-ombra'); cv.hl(o + 4, 1, 8, 'mocador-clar')
            cv.p(o + 8, 2, 'vermell')
        else:
            cv.vl(o + 4, 4, 6, 'mocador'); cv.vl(o + 11, 4, 6, 'mocador-ombra')
            cv.p(o + 3, 9, 'mocador'); cv.p(o + 12, 9, 'mocador-ombra')
    if mena == 'A':  # avi: cabells grisos sota el mocador i bastó
        cv.vl(o + 5, 4, 3, 'gris-clar'); cv.vl(o + 10, 4, 3, 'gris')
    # --- braços segons la mena
    if mena in ('F', 'D', 'P', 'A'):
        cv.rect(o + 2, 11, 2, 5, 'roba'); cv.vl(o + 2, 11, 5, 'roba-clar'); cv.hl(o + 2, 16, 2, 'pell')
        cv.rect(o + 12, 11, 2, 5, 'roba-ombra'); cv.hl(o + 12, 16, 2, 'pell-ombra')
    if mena == 'A':
        cv.vl(o + 14, 12, 11, 'fusta'); cv.hl(o + 13, 11, 3, 'fusta-clar'); cv.p(o + 13, 16, 'pell-ombra'); cv.p(o + 14, 16, 'pell-ombra')
    if mena == 'L':  # fanal a la mà
        cv.rect(o + 2, 11, 2, 5, 'roba'); cv.hl(o + 2, 16, 2, 'pell')
        cv.rect(o + 12, 11, 2, 4, 'roba-ombra'); cv.hl(o + 12, 15, 2, 'pell-ombra')
        cv.vl(o + 14, 14, 1, 'fusta-ombra'); cv.hl(o + 13, 13, 4, 'fusta-ombra'); cv.p(o + 15, 12, 'fusta-ombra')
        cv.rect(o + 13, 15, 4, 5, 'llum'); cv.hl(o + 14, 16, 2, 'llum-clar'); cv.hl(o + 13, 20, 4, 'fusta-ombra'); cv.vl(o + 16, 15, 5, 'llum-ombra')
    if mena == 'W':  # feix de llenya als braços
        cv.rect(o + 2, 12, 2, 4, 'roba'); cv.rect(o + 12, 12, 2, 4, 'roba-ombra')
        cv.rect(o + 1, 15, 14, 4, 'fusta'); cv.hl(o + 1, 15, 14, 'fusta-clar'); cv.hl(o + 1, 18, 14, 'fusta-ombra')
        for x in (o + 3, o + 7, o + 11):
            cv.vl(x, 15, 4, 'fusta-ombra')
        cv.vl(o + 8, 15, 4, 'vermell'); cv.p(o + 2, 16, 'pell'); cv.p(o + 14, 16, 'pell-ombra')
    if mena == 'P':  # pastor amb gaiato
        cv.vl(o + 15, 4, 19, 'fusta'); cv.hl(o + 13, 3, 3, 'fusta'); cv.p(o + 13, 4, 'fusta'); cv.p(o + 14, 13, 'pell')
        cv.rect(o + 12, 11, 2, 3, 'roba-ombra'); cv.hl(o + 13, 13, 2, 'pell')
    if mena == 'C':  # cistell de fruita
        cv.rect(o + 2, 11, 2, 4, 'roba'); cv.rect(o + 12, 11, 2, 4, 'roba-ombra')
        cv.rect(o + 4, 15, 8, 4, 'palla'); cv.hl(o + 4, 15, 8, 'palla-clar'); cv.hl(o + 5, 18, 6, 'palla-ombra'); cv.vl(o + 11, 15, 4, 'palla-ombra')
        for i, c in enumerate(['groc', 'taronja', 'groc', 'fruit', 'groc', 'taronja']):
            cv.p(o + 5 + i, 14, c)
        cv.hl(o + 6, 13, 4, 'groc'); cv.p(o + 7, 13, 'groc-clar')
        cv.p(o + 3, 15, 'pell'); cv.p(o + 12, 15, 'pell-ombra'); cv.p(o + 2, 15, 'pell')
    if mena == 'B':  # braços enlaire
        cv.rect(o + 2, 6, 2, 6, 'roba'); cv.vl(o + 2, 6, 6, 'roba-clar'); cv.hl(o + 2, 5, 2, 'pell')
        cv.rect(o + 12, 6, 2, 6, 'roba-ombra'); cv.hl(o + 12, 5, 2, 'pell-ombra')
    if mena == 'G':  # gerra al cap
        cv.rect(o + 2, 11, 2, 5, 'roba'); cv.hl(o + 2, 16, 2, 'pell')
        cv.rect(o + 12, 3, 2, 9, 'roba-ombra'); cv.p(o + 12, 2, 'pell')
    cv.contorn()
    if mena == 'G':
        g = Llenc(18, 27)
        g.rect(o + 6, -0, 5, 1, 'bru-clar')
        cv.rect(o + 5, 0, 6, 1, 'bru'); cv.hl(o + 5, 0, 2, 'bru-clar')
    _ombra(cv, o + 2, o + 14, 24)
    return cv


def infant(mena='F'):
    cv = Llenc(14, 21)
    cv.rect(4, 9, 6, 6, 'roba2'); cv.vl(4, 9, 6, 'roba2-clar'); cv.vl(9, 9, 6, 'roba2-ombra'); cv.hl(4, 14, 6, 'roba2-ombra')
    cv.rect(3, 15, 8, 1, 'roba2-ombra') if False else None
    cv.rect(5, 15, 2, 2, 'pell'); cv.rect(8, 15, 2, 2, 'pell-ombra')
    cv.hl(4, 17, 3, 'fusta-ombra'); cv.hl(8, 17, 3, 'fusta-ombra')
    cv.rect(4, 3, 6, 5, 'pell'); cv.hl(5, 8, 4, 'pell-ombra')
    cv.rect(4, 1, 6, 2, 'cabell'); cv.hl(5, 1, 3, 'cabell'); cv.p(3, 2, 'cabell'); cv.p(3, 3, 'cabell'); cv.p(10, 2, 'cabell-ombra'); cv.p(10, 3, 'cabell-ombra')
    cv.hl(4, 3, 2, 'cabell'); cv.p(9, 3, 'cabell-ombra')
    cv.p(5, 5, 'contorn'); cv.p(8, 5, 'contorn'); cv.p(4, 6, 'flor-clar'); cv.p(9, 6, 'flor-clar')
    if mena in ('F', 'Q'):
        cv.rect(2, 9, 2, 4, 'roba2'); cv.hl(2, 13, 2, 'pell'); cv.rect(10, 9, 2, 4, 'roba2-ombra'); cv.hl(10, 13, 2, 'pell-ombra')
    elif mena == 'B':
        cv.rect(2, 5, 2, 5, 'roba2'); cv.hl(2, 4, 2, 'pell'); cv.rect(10, 5, 2, 5, 'roba2-ombra'); cv.hl(10, 4, 2, 'pell-ombra')
    else:  # corrent / saludant
        cv.rect(2, 6, 2, 4, 'roba2'); cv.hl(2, 5, 2, 'pell'); cv.rect(10, 10, 3, 2, 'roba2-ombra'); cv.p(12, 11, 'pell')
    if mena == 'Q':  # amb pilota
        cv.ellipse(11.5, 15.5, 2, 2, 'vermell'); cv.p(11, 14, 'blanc'); cv.hl(10, 16, 4, 'vermell-ombra')
    cv.contorn()
    _ombra(cv, 2, 11, 19)
    return cv


def ovella(l='llana', lo='llana-ombra', b='blanc', cap='pell'):
    cv = Llenc(22, 16)
    for (cx, cy, r) in [(6, 7, 4), (10, 6, 4.4), (14, 7, 4), (8, 9, 4), (12, 9, 4)]:
        cv.ellipse(cx, cy, r, r * .85, l)
    for (x, y) in [(5, 5), (9, 3), (10, 4), (13, 5), (7, 8)]:
        cv.p(x, y, b); cv.p(x + 1, y, b)
    for x in range(4, 17):
        for y in range(9, 13):
            if cv.get(x, y) == l and (x + y) % 3 == 0:
                cv.p(x, y, lo)
    cv.hl(5, 12, 10, lo)
    cv.rect(16, 5, 4, 4, cap); cv.p(19, 8, cap + '-ombra'); cv.p(18, 6, 'contorn'); cv.rect(15, 4, 3, 2, l); cv.p(16, 6, cap + '-ombra')
    for x in (6, 8, 12, 14):
        cv.vl(x, 13, 2, 'gris-ombra')
    cv.contorn()
    _ombra(cv, 3, 18, 15)
    return cv


def cabra():
    cv = Llenc(22, 17)
    cv.rect(4, 6, 12, 6, 'bru-clar'); cv.hl(4, 6, 12, 'camell-clar'); cv.hl(4, 11, 12, 'bru'); cv.rect(4, 8, 4, 3, 'blanc')
    cv.rect(15, 3, 4, 5, 'bru-clar'); cv.p(19, 6, 'bru-clar'); cv.p(17, 4, 'contorn'); cv.vl(18, 8, 2, 'blanc')
    cv.vl(15, 0, 3, 'gris-clar'); cv.vl(17, 1, 2, 'gris-clar'); cv.p(3, 6, 'bru')
    for x in (5, 7, 12, 14):
        cv.vl(x, 12, 3, 'bru-ombra')
    cv.contorn()
    _ombra(cv, 3, 18, 16)
    return cv


def gos(c='blanc', co='blanc-ombra', t='bru-clar'):
    cv = Llenc(18, 13)
    cv.rect(3, 5, 9, 4, c); cv.rect(5, 5, 4, 2, t); cv.hl(3, 8, 9, co)
    cv.rect(11, 2, 4, 5, c); cv.p(15, 5, c); cv.p(15, 4, 'contorn'); cv.p(13, 3, 'contorn'); cv.rect(11, 1, 2, 3, t)
    cv.vl(2, 2, 4, c); cv.p(2, 2, t)
    for x in (4, 6, 9, 11):
        cv.vl(x, 9, 2, co)
    cv.contorn()
    _ombra(cv, 2, 14, 12)
    return cv


def gallina(c='bru'):
    cv = Llenc(12, 12)
    cv.rect(2, 4, 6, 4, c); cv.hl(2, 4, 5, c + '-clar'); cv.hl(3, 7, 5, c + '-ombra'); cv.rect(1, 3, 2, 2, c + '-ombra')
    cv.rect(7, 2, 3, 3, c); cv.p(10, 3, 'groc'); cv.p(8, 1, 'vermell'); cv.p(9, 1, 'vermell'); cv.p(9, 5, 'vermell'); cv.p(8, 3, 'contorn')
    cv.p(4, 8, 'groc-ombra'); cv.p(6, 8, 'groc-ombra'); cv.p(4, 9, 'groc-ombra'); cv.p(6, 9, 'groc-ombra')
    cv.contorn()
    return cv


def anec():
    cv = Llenc(16, 11)
    cv.rect(2, 5, 9, 3, 'blanc'); cv.hl(3, 4, 6, 'blanc'); cv.hl(2, 7, 9, 'blanc-ombra'); cv.p(1, 4, 'blanc')
    cv.rect(10, 1, 3, 5, 'blanc'); cv.hl(13, 3, 2, 'taronja'); cv.p(11, 2, 'contorn')
    cv.contorn()
    cv.hl(1, 9, 13, 'aigua-clar'); cv.hl(3, 10, 8, 'escuma')
    return cv


def bestia(mena):  # bou / mula, mirant a la dreta
    cv = Llenc(34, 24)
    c = 'bru' if mena == 'bou' else 'gris'
    cv.rect(4, 8, 18, 9, c); cv.hl(4, 8, 18, c + '-clar'); cv.hl(5, 7, 15, c + '-clar'); cv.hl(4, 16, 18, c + '-ombra'); cv.rect(4, 13, 6, 3, c + '-ombra')
    cv.rect(20, 5, 5, 7, c)  # coll
    cv.rect(23, 3, 7, 7, c); cv.hl(23, 3, 7, c + '-clar'); cv.rect(28, 7, 3, 4, 'pell' if mena == 'bou' else 'blanc-ombra'); cv.p(30, 9, 'contorn'); cv.p(26, 5, 'contorn')
    if mena == 'bou':
        cv.rect(22, 1, 2, 3, 'blanc'); cv.rect(28, 1, 2, 3, 'blanc'); cv.p(21, 0, 'blanc'); cv.p(30, 0, 'blanc')
        cv.rect(9, 9, 5, 4, 'bru-clar')
    else:
        cv.rect(23, 0, 2, 4, c); cv.rect(27, 0, 2, 4, c + '-ombra'); cv.vl(21, 4, 6, 'gris-ombra')
    cv.vl(3, 9, 6, c + '-ombra'); cv.p(3, 15, 'contorn')
    for x in (6, 9, 17, 20):
        cv.rect(x, 17, 2, 4, c + '-ombra'); cv.hl(x, 21, 2, 'contorn')
    cv.contorn()
    _ombra(cv, 3, 26, 23)
    return cv


def totes():
    return {
        'PER-ADU-F': adult('F'), 'PER-ADU-D': adult('D'), 'PER-ADU-CISTELL': adult('C'), 'PER-ADU-BRACOS': adult('B'),
        'PER-ADU-GERRA': adult('G'), 'PER-PAS-F': adult('P', barba=True, turbant=True), 'PER-ADU-BARBA': adult('F', barba=True, turbant=True),
        'PER-INF-F': infant('F'), 'PER-INF-D': infant('D'),
        'ANI-OVELLA-D': ovella(), 'ANI-CABRA-D': cabra(), 'ANI-GOS-D': gos(), 'ANI-GALLINA-D': gallina(), 'ANI-ANEC-D': anec(),
        'ESC-BOU': bestia('bou'), 'ESC-MULA': bestia('mula'),
    }
