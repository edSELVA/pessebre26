"""Compon l'escena: terreny + peces ordenades per y + capa de llum, i en fa captures.
  python3 compon.py <carpeta paquet> [vistes]"""
import json, math, os, random, sys
import terreny as T
import peces as P
import px
import moments as MO
from mapa import Mapa, dins_casc
from captura import captura

PALETES = {
    'cases': {
        'facana': {'nom': 'Façana', 'opcions': [['#FFEFCB', '#F5D9A8', '#D8AE7C', '#B98A60'], ['#FBE0A4', '#EFC47A', '#CF9C56', '#A87840'], ['#FFE0CC', '#F3C2A4', '#D49A7C', '#B0785E'],
                                                 ['#FFF9EA', '#F2E6CE', '#D2C0A2', '#B09C80'], ['#F3CFA0', '#E0AE78', '#BC8854', '#966A40'], ['#EFE6D6', '#D6C8B2', '#AE9E88', '#887868']]},
        'teulada': {'nom': 'Teulada', 'opcions': [['#F08A55', '#D9603A', '#A8402C', '#7A2C22'], ['#E36A5A', '#C1433B', '#8E2A30', '#661E26'], ['#F2A268', '#DC7E42', '#AE5A2C', '#80401F'],
                                                   ['#C98858', '#A8683C', '#7C4828', '#583220'], ['#FBE0D2', '#EEBFAC', '#CC9482', '#A47062']]},
        'porta': {'nom': 'Porta i fusta', 'opcions': [['#B07A46', '#8A5A35', '#633D24'], ['#7FAEC8', '#4F84A6', '#365E7A'], ['#9AB45A', '#6E8A3E', '#4C632A'], ['#C4684A', '#9C4A32', '#703222'], ['#8A6444', '#6A4830', '#4A3020']]},
    },
    'persones': {
        'roba': {'nom': 'Roba', 'opcions': [['#6FA3EA', '#3F7FD8', '#2A57A6'], ['#72BE7E', '#4E9A5B', '#377243'], ['#AC86DC', '#8A5FC0', '#664394'], ['#F0766A', '#D9503A', '#A33528'],
                                             ['#F6BC5E', '#E39A2E', '#B4731F'], ['#58BEBE', '#2F9A9A', '#227272'], ['#EE86AE', '#D45A8A', '#A63F68']]},
        'mocador': {'nom': 'Mocador', 'opcions': [['#FFFFFF', '#F3EBDD', '#CBBBA4'], ['#FFE9A8', '#F2CC6A', '#C89A3A'], ['#F6C2B0', '#E89A84', '#BC6E5C'], ['#CFE4F4', '#A4C8E4', '#7A9EC0']]},
        'roba2': {'nom': 'Roba (infant)', 'opcions': [['#F2B054', '#E39A2E', '#B4731F'], ['#6FA3EA', '#3F7FD8', '#2A57A6'], ['#F0766A', '#D9503A', '#A33528'], ['#72BE7E', '#4E9A5B', '#377243'], ['#58BEBE', '#2F9A9A', '#227272']]},
    },
}
SUFIX = ['-clar', '', '-ombra', '-fosc']
FANTASMA = {'-clar': '#FFFDF4', '': '#FFF3DA', '-ombra': '#EBDCC0', '-fosc': '#D8C6A6', 'contorn': '#FFFFFF'}


def estil(rol, opcio):
    return ';'.join(f'--{rol}{SUFIX[i]}:{c}' for i, c in enumerate(opcio))


def estil_fantasma(rols):
    out = []
    for r in rols:
        if r == 'contorn': out.append('--contorn:#FFFFFF')
        elif r == 'ombra-terra': out.append('--ombra-terra:#FFFFFF')
        else:
            suf = next((s for s in ('-clar', '-ombra', '-fosc', '-llum') if r.endswith(s)), '')
            out.append(f'--{r}:{FANTASMA.get(suf, "#FFFDF4")}')
    return ';'.join(out)


# ------------------------------------------------------------------ terreny complet
def terreny_svg(m, seed=4):
    o, rng = T.svg_terreny(seed)
    A = o.append
    f = lambda k: (lambda x: T.nivell(k, x))
    # camps conreats
    for (k, xa, xb, pat) in T.CAMPS:
        g0 = 13; g1 = (lambda kk: (lambda x: T.nivell(kk + 1, x) - T.nivell(kk, x) - 20))(k)
        if pat == 'solc':
            A(f'<path d="{T.franja(f(k), xa, xb, g0, g1)}" fill="url(#p-solc)"/>')
        else:
            A(f'<path d="{T.franja(f(k), xa, xb, g0, g1)}" fill="var(--feixa-ombra, #2F6B33)" fill-opacity=".16"/><path d="{T.franja(f(k), xa, xb, g0, g1)}" fill="url(#p-vinya)"/>')
    x0, y0, x1, y1 = T.HORT
    A(f'<rect x="{x0 - 2}" y="{y0 - 2}" width="{x1 - x0 + 4}" height="{y1 - y0 + 4}" fill="var(--solc-ombra, #6A4028)"/><rect x="{x0}" y="{y0}" width="{x1 - x0}" height="{y1 - y0}" fill="url(#p-solc)"/>')
    # marges solts de pedra seca a la perifèria
    murs = list(m.murs)
    for _ in range(34):
        k = rng.randrange(1, T.NIV); xa = rng.randrange(0, T.W - 120); L = rng.randrange(80, 230)
        if 800 < xa + L / 2 < 1420 and k < 7: continue
        murs.append((k, xa, min(T.W, xa + L), rng.choice([6, 7, 8])))
    # turó del casc antic: terra batuda i llambordes, carrers esglaonats amb marge de pedra
    tc = T.turo_casc()
    A(f'<path d="{T.pts2d(tc)}" fill="var(--feixa-ombra, #2F6B33)" fill-opacity=".5" stroke="var(--feixa-ombra, #2F6B33)" stroke-opacity=".5" stroke-width="10" stroke-linejoin="round"/>')
    A(f'<path d="{T.pts2d(tc)}" fill="var(--cami-vora, #B9965E)" stroke="var(--cami-vora, #B9965E)" stroke-width="4" stroke-linejoin="round"/>')
    A(f'<path d="{T.pts2d(tc)}" fill="var(--empedrat, #DCC49C)"/><path d="{T.pts2d(tc)}" fill="url(#p-llamb)" fill-opacity=".6"/>')
    for (r, xa, xb, off) in m.carrers:
        ff = (lambda rr, oo: (lambda x: T.fila_y(rr, x) + oo))(r, off)
        A(f'<path d="{T.franja(ff, xa, xb, 0, 11)}" fill="var(--mur-fosc, #3A2820)" fill-opacity=".3"/>')
        A(f'<path d="{T.franja(ff, xa, xb, 0, 8)}" fill="url(#p-mur)"/>')
        A(f'<path d="{T.franja(ff, xa, xb, -1, 1)}" fill="var(--mur-llum, #F3E6CE)"/>')
    for (x, r, off) in m.escales:
        y = round(T.fila_y(r, x) + off) - 4
        A(f'<rect x="{x - 7}" y="{y}" width="14" height="20" fill="var(--mur-ombra, #9A836E)"/>')
        A('<path d="' + ''.join(f'M{x - 6} {y + i * 3}h12v2h-12z' for i in range(7)) + '" fill="var(--mur-llum, #F3E6CE)"/>')
    for (k, xa, xb, h) in murs:
        xa, xb = max(0, xa), min(T.W, xb)
        if xb - xa < 30: continue
        tap = (lambda a, b, hh: (lambda x: 1 + hh * min(1, (x - a) / 16, (b - x) / 16)))(xa, xb, h)
        tap2 = (lambda a, b, hh: (lambda x: 1 + hh * min(1, (x - a) / 16, (b - x) / 16) + 3))(xa, xb, h)
        A(f'<path d="{T.franja(f(k), xa, xb, 0, tap2)}" fill="var(--mur-fosc, #3A2820)" fill-opacity=".35"/>')
        A(f'<path d="{T.franja(f(k), xa, xb, 0, tap)}" fill="url(#p-mur)"/>')
        A(f'<path d="{T.franja(f(k), xa, xb, -1, 1)}" fill="var(--mur-llum, #F3E6CE)"/>')
    # camins de terra
    for i, pts in enumerate([T.CAMI] + T.BRANQUES):
        w = 16 if i == 0 else 10
        d = T.cami_d(pts)
        A(f'<path d="{d}" fill="none" stroke="var(--cami-vora, #B9965E)" stroke-width="{w + 4}" stroke-linecap="round" stroke-linejoin="round"/>')
        A(f'<path d="{d}" fill="none" stroke="var(--cami, #EBD09C)" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"/>')
    for i, pts in enumerate([T.CAMI] + T.BRANQUES):
        A(f'<path d="{T.cami_d(pts)}" fill="none" stroke="url(#p-cami)" stroke-width="{16 if i == 0 else 10}" stroke-linecap="round" stroke-linejoin="round"/>')
    cx, cy, rx, ry = T.PLACA_NAIX
    A(f'<path d="{T.rodona(cx, cy + 2, rx + 3, ry + 3)}" fill="var(--cami-vora, #B9965E)"/><path d="{T.rodona(cx, cy, rx, ry)}" fill="var(--cami-clar, #F6E2B4)"/><path d="{T.rodona(cx, cy, rx, ry)}" fill="url(#p-llamb)" fill-opacity=".55"/>')
    # riu, salts d'aigua i estany
    riu = T.poligon_riu(T.RIU); sor = T.poligon_riu(T.SORTIDA)
    ex, ey, erx, ery = T.ESTANY
    est = ''.join(T.rodona(a, b, c, d) for a, b, c, d in T.ESTANYS)
    est_v = ''.join(T.rodona(a, b + 2, c + 4, d + 4) for a, b, c, d in T.ESTANYS)
    est_f = ''.join(T.rodona(a, b + 6, c - 22, d - 12) for a, b, c, d in T.ESTANYS[:2])
    A(f'<path d="{T.pts2d(riu)}" fill="var(--riba, #2F6B33)" stroke="var(--riba, #2F6B33)" stroke-width="5"/><path d="{est_v}{T.pts2d(sor)}" fill="var(--riba, #2F6B33)" stroke="var(--riba, #2F6B33)" stroke-width="4"/>')
    A(f'<path d="{T.pts2d(riu)}{est}{T.pts2d(sor)}" fill="var(--aigua, #4696E6)"/>')
    A(f'<path d="{est_f}" fill="var(--aigua-fons, #3A82DA)"/>')
    A(f'<path d="{T.pts2d(riu)}{est}{T.pts2d(sor)}" fill="url(#p-aigua)"/>')
    s = T.suau(T.RIU, 10)
    for k in range(T.NIV):
        for a, b in zip(s, s[1:]):
            if (a[1] - T.nivell(k, a[0])) * (b[1] - T.nivell(k, b[0])) <= 0:
                w = round(a[2]) + 2; x = round(a[0] - w / 2); y = round(a[1])
                A(f'<rect x="{x}" y="{y - 1}" width="{w}" height="11" fill="var(--aigua-clar, #8FD0FA)"/>')
                A('<path d="' + ''.join(f'M{x + i} {y - 1}h1v{9 + (i * 7) % 4}h-1z' for i in range(0, w, 2)) + '" fill="var(--escuma, #EAF7FF)"/>')
                A(f'<path d="M{x - 2} {y + 9}h{w + 4}v3h-{w + 4}z" fill="var(--escuma, #EAF7FF)" fill-opacity=".8"/>')
                break
    # decoració plana: herbes, flors, pedres
    dec = []
    mp = m.mp
    for codi, n in [('DEC-HERBES', 520), ('DEC-FLORS', 230), ('DEC-FLORS-G', 150), ('DEC-ROQUES-2', 70), ('DEC-ROQUES', 36), ('ELE-MATA-2', 90), ('ELE-MATA', 50), ('ELE-MATA-FLOR', 80)]:
        fets = 0
        while fets < n:
            x = rng.randrange(6, T.W - 6); y = rng.randrange(int(T.carena(x)) + 14, T.H - 2)
            if mp[x, y] != T.HERBA: continue
            dec.append((codi, x, y)); fets += 1
    # ribes: canyes i pedres vora l'aigua
    for (ecx, ecy, erx_, ery_) in T.ESTANYS:
        for a in range(0, 360, 11):
            x = ecx + math.cos(math.radians(a)) * (erx_ + 6); y = ecy + math.sin(math.radians(a)) * (ery_ + 6)
            if not (0 < x < T.W and 0 < y < T.H - 2) or mp[int(x), int(y)] != T.HERBA: continue
            dec.append((rng.choice(['DEC-CANYES', 'DEC-ROQUES-2', 'DEC-ROQUES', 'DEC-CANYES', 'ELE-MATA-2']), round(x), round(y) + 3))
    for i in range(6, len(s) - 4, 5):
        for sg in (-1, 1):
            if rng.random() < .6:
                dec.append((rng.choice(['DEC-ROQUES-2', 'DEC-CANYES', 'ELE-MATA-2', 'DEC-ROQUES-2']), round(s[i][0] + sg * (s[i][2] / 2 + 6)), round(s[i][1]) + 3))
    dec.sort(key=lambda d: d[2])
    return o, dec


LLUM_DEFS = '''<defs>
<linearGradient id="l-boira" x1="0" y1="150" x2="0" y2="540" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="var(--boira, #1B2A7A)" stop-opacity="0"/><stop offset=".16" stop-color="var(--boira, #1B2A7A)" stop-opacity=".36"/><stop offset="1" stop-color="var(--boira, #1B2A7A)" stop-opacity="0"/></linearGradient>
<linearGradient id="l-esq" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="var(--nit, #0A1040)" stop-opacity=".42"/><stop offset="1" stop-color="var(--nit, #0A1040)" stop-opacity="0"/></linearGradient>
<linearGradient id="l-dre" x1="1" y1="0" x2="0" y2="0"><stop offset="0" stop-color="var(--nit, #0A1040)" stop-opacity=".42"/><stop offset="1" stop-color="var(--nit, #0A1040)" stop-opacity="0"/></linearGradient>
<linearGradient id="l-baix" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="var(--nit, #0A1040)" stop-opacity=".3"/><stop offset="1" stop-color="var(--nit, #0A1040)" stop-opacity="0"/></linearGradient>
<radialGradient id="l-calid"><stop offset="0" stop-color="var(--llum-calida, #FFE08C)" stop-opacity=".62"/><stop offset=".45" stop-color="var(--llum-calida, #FFE08C)" stop-opacity=".3"/><stop offset="1" stop-color="var(--llum-calida, #FFE08C)" stop-opacity="0"/></radialGradient>
<radialGradient id="l-suau"><stop offset="0" stop-color="var(--llum-calida, #FFE08C)" stop-opacity=".2"/><stop offset="1" stop-color="var(--llum-calida, #FFE08C)" stop-opacity="0"/></radialGradient>
<radialGradient id="l-foc"><stop offset="0" stop-color="var(--llum-foc, #FFC060)" stop-opacity=".7"/><stop offset=".4" stop-color="var(--llum-foc, #FFA848)" stop-opacity=".3"/><stop offset="1" stop-color="var(--llum-foc, #FFA848)" stop-opacity="0"/></radialGradient>
<radialGradient id="l-toll"><stop offset="0" stop-color="var(--llum-calida, #FFE08C)" stop-opacity=".5"/><stop offset="1" stop-color="var(--llum-calida, #FFE08C)" stop-opacity="0"/></radialGradient>
<radialGradient id="l-estel"><stop offset="0" stop-color="var(--llum-estel, #FFF6C8)" stop-opacity=".75"/><stop offset=".35" stop-color="var(--llum-estel, #FFE890)" stop-opacity=".25"/><stop offset="1" stop-color="var(--llum-estel, #FFE890)" stop-opacity="0"/></radialGradient>
<linearGradient id="l-raig" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--llum-estel, #FFF6C8)" stop-opacity=".16"/><stop offset="1" stop-color="var(--llum-estel, #FFF6C8)" stop-opacity="0"/></linearGradient>
<pattern id="p-neu" width="97" height="83" patternUnits="userSpaceOnUse"><path d="M5 6h2v2h-2zM38 22h2v2h-2zM71 12h2v2h-2zM22 44h2v2h-2zM58 52h2v2h-2zM87 70h2v2h-2zM12 74h2v2h-2zM46 66h1v1h-1zM80 36h1v1h-1zM30 8h1v1h-1z" fill="#FFFFFF"/></pattern>
<pattern id="p-neu2" width="71" height="109" patternUnits="userSpaceOnUse"><path d="M9 14h2v2h-2zM44 40h2v2h-2zM28 80h2v2h-2zM60 96h2v2h-2zM14 60h1v1h-1zM52 8h1v1h-1zM66 66h1v1h-1z" fill="#EAF2FF"/></pattern>
</defs>'''


def llum_terra(m, tolls, defs=True):
    """Llum que cau a terra (va SOTA les peces): naixement, foguera, poble, portes i fanals. Opacitat: --op-terra."""
    nx, ny = T.NAIX; cx, cy = T.CLAR
    o = [LLUM_DEFS] if defs else []
    o.append('<g id="llum-terra-gran" style="opacity:var(--op-terra,1)">')
    o.append(f'<ellipse cx="1110" cy="440" rx="440" ry="260" fill="url(#l-suau)"/>')
    o.append(f'<ellipse cx="{nx}" cy="{ny - 6}" rx="400" ry="210" fill="url(#l-calid)"/><ellipse cx="{nx}" cy="{ny + 20}" rx="190" ry="70" fill="url(#l-calid)"/>')
    o.append(f'<ellipse cx="{cx}" cy="{cy}" rx="170" ry="80" fill="url(#l-foc)"/>')
    o.append('</g>')
    o.append('<g id="llum-terra-tolls" style="opacity:var(--op-terra,1)">' + ''.join(f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="url(#l-toll)"/>' for x, y, rx, ry in tolls) + '</g>')
    return o


def llum_aire(m, halos):
    """Atmosfera (va SOBRE les peces). Cada subcapa té la seva opacitat per variable CSS:
    boira (--op-boira), vinyeta (--op-vinyeta), raig i halos d'estel (--op-estel), tint multiplicatiu (--op-tint, color --tint), neu (--op-neu)."""
    nx, ny = T.NAIX; cx, cy = T.CLAR
    o = []
    o.append(f'<g id="llum-boira" style="opacity:var(--op-boira,1)"><rect x="0" y="150" width="{T.W}" height="390" fill="url(#l-boira)"/></g>')
    o.append(f'<g id="llum-vinyeta" style="opacity:var(--op-vinyeta,1)"><rect x="0" y="0" width="300" height="{T.H}" fill="url(#l-esq)"/><rect x="{T.W - 300}" y="0" width="300" height="{T.H}" fill="url(#l-dre)"/><rect x="0" y="{T.H - 120}" width="{T.W}" height="120" fill="url(#l-baix)"/></g>')
    g = [f'<path d="M{nx - 8} 84L{nx + 20} 84L{nx + 110} {ny - 110}L{nx - 110} {ny - 110}Z" fill="url(#l-raig)"/>']
    g.append(f'<ellipse cx="{nx}" cy="{ny - 60}" rx="210" ry="150" fill="url(#l-suau)"/>')
    g.append(f'<circle cx="{nx + 6}" cy="62" r="78" fill="url(#l-estel)"/>')
    g.append(f'<ellipse cx="{cx}" cy="{cy - 14}" rx="96" ry="60" fill="url(#l-suau)"/><ellipse cx="{cx + 4}" cy="{cy - 92}" rx="44" ry="40" fill="url(#l-estel)"/>')
    g.append(f'<ellipse cx="{nx - 34}" cy="{ny - 126}" rx="34" ry="30" fill="url(#l-estel)"/>')
    o.append('<g id="llum-estel" style="opacity:var(--op-estel,1)">' + ''.join(g) + '</g>')
    o.append('<g id="llum-halos" style="opacity:var(--op-estel,1)">' + ''.join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="url(#l-suau)"/>' for x, y, r in halos) + '</g>')
    o.append(f'<rect id="llum-tint" width="{T.W}" height="{T.H}" fill="var(--tint,#FFFFFF)" style="mix-blend-mode:multiply;opacity:var(--op-tint,0)"/>')
    o.append(f'<g id="llum-neu" style="opacity:var(--op-neu,0)"><rect width="{T.W}" height="{T.H}" fill="url(#p-neu)"/><rect width="{T.W}" height="{T.H}" fill="url(#p-neu2)"/></g>')
    return o


# ------------------------------------------------------------------ escena
def ocupants(m, seed=9):
    """Tria fictícia de models i colors per veure el pessebre ple."""
    rng = random.Random(seed)
    pc, pp = PALETES['cases'], PALETES['persones']
    for c in m.cases:
        fa = rng.choices(range(6), [5, 3, 3, 3, 2, 2])[0]
        te = rng.choices(range(5), [5, 3, 4, 2, 0])[0] if 'CUPULA' not in c['codi'] else 4
        c['colors'] = ';'.join([estil('facana', pc['facana']['opcions'][fa]), estil('teulada', pc['teulada']['opcions'][te]), estil('porta', pc['porta']['opcions'][rng.choices(range(5), [5, 2, 2, 2, 3])[0]])])
    for p in m.punts:
        if p['tipus'] == 'persona':
            p['codi'] = rng.choices(['PER-ADU-F', 'PER-ADU-D', 'PER-ADU-CISTELL', 'PER-ADU-BRACOS', 'PER-ADU-GERRA', 'PER-ADU-BARBA', 'PER-PAS-F', 'PER-INF-F', 'PER-INF-D', 'PER-ADU-CAPELL', 'PER-ADU-AVI', 'PER-ADU-FANAL', 'PER-ADU-LLENYA', 'PER-INF-BRACOS', 'PER-INF-PILOTA'], [4, 3, 2.5, 1, 1, 2, 1, 2.5, 1.5, 2.5, 1.5, 1.5, 1.5, 1.5, 1.5])[0]
            p['colors'] = ';'.join([estil('roba', rng.choice(pp['roba']['opcions'])), estil('mocador', rng.choice(pp['mocador']['opcions'])), estil('roba2', rng.choice(pp['roba2']['opcions']))])
        elif p['tipus'] == 'animal':
            p['codi'] = rng.choices(['ANI-OVELLA-D', 'ANI-CABRA-D', 'ANI-GOS-D', 'ANI-GALLINA-D', 'ANI-OVELLA-NEGRA-D', 'ANI-CORDER-D', 'ANI-CABRIT-D', 'ANI-GOS-NEGRE-D', 'ANI-GALLINA-ROSSA-D', 'ANI-GALLINA-GRISA-D', 'ANI-GALL-D', 'ANI-PORC-D', 'ANI-CONILL-D', 'ANI-GAT-D', 'ANI-ASE-D', 'ANI-COLOMA-D'], [4, 2, 2, 2, 1.5, 2, 1.5, 1, 1.5, 1, 1.5, 1.5, 1.5, 1.5, 1.2, 1.2])[0]; p['colors'] = ''
        else:
            p['codi'] = rng.choice(['PER-PAS-F', 'PER-PAS-F', 'PER-ADU-BARBA', 'PER-ADU-F'])
            terra = [['#C89A62', '#A6763E', '#7C5428'], ['#B8866A', '#96644A', '#6E4632'], ['#9AA06A', '#787E48', '#565C30'], ['#D9B078', '#BC8E52', '#8E6836']]
            p['colors'] = estil('roba', rng.choice(terra)) + ';' + estil('mocador', rng.choice(pp['mocador']['opcions'][:2]))
        p['mirall'] = rng.random() < .5


def us(codi, reg, x, y, mirall=False, estil_='', extra=''):
    f = reg[codi]; w, h = f['viewBox'][2], f['viewBox'][3]; ax, ay = f['ancoratge']
    t = f' transform="matrix(-1 0 0 1 {2 * x} 0)"' if mirall else ''
    st = f' style="{estil_}"' if estil_ else ''
    return f'<use href="#s-{codi}" x="{x - ax}" y="{y - ay}" width="{w}" height="{h}"{t}{st}{extra}/>'


def escena(m, estat='ple', seed=5, retall=None, escala=1, moment='nit'):
    """estat: 'terreny' | 'ple' | 'participa' (Z0 oberta, mig plena, amb llocs lliures visibles)."""
    rng = random.Random(seed)
    reg = m.reg
    terr, dec = terreny_svg(m)
    usats = set()
    cos = []      # (ordre, text)
    halos, tolls = [], []
    def afegeix(codi, x, y, mirall=False, st='', ordre=None, extra=''):
        usats.add(codi)
        cos.append((y if ordre is None else ordre, us(codi, reg, x, y, mirall, st, extra)))
    for f in m.fixos:
        st = ';'.join(f'--{k}:{v}' for k, v in f.get('colors', {}).items())
        afegeix(f['codi'], f['x'], f['y'], f.get('mirall', False), st, f.get('ordre'))
    obertes = {'ple': ('Z0', 'Z1', 'Z2', 'Z3'), 'participa': ('Z0',), 'terreny': ()}[estat]
    frac = {'ple': 1.0, 'participa': .5, 'terreny': 0}[estat]
    for c in m.cases:
        if c['zona'] not in obertes: continue
        ple = rng.random() < (frac if c['tipus'] == 'familia' else min(1, frac * 1.5))
        if ple:
            afegeix(c['codi'], c['x'], c['y'], c['mirall'], MO.neu_teulada(c['colors']) if moment == 'neu' else c['colors'])
            tolls.append((c['x'], c['y'] + 5, 30, 9))
            if rng.random() < .3 and 'CUPULA' not in c['codi'] and 'TERRAT' not in c['codi']:
                pass
        else:
            afegeix(c['codi'], c['x'], c['y'], c['mirall'], estil_fantasma(reg[c['codi']]['rols']), extra=' opacity=".62"')
    for e in m.elements:
        if e['zona'] not in obertes: continue
        if rng.random() < frac:
            afegeix(e['codi'], e['x'], e['y'], e['mirall'])
            if e['codi'] == 'ELE-FANAL': halos.append((e['x'], e['y'] - 22, 20)); tolls.append((e['x'], e['y'] + 1, 30, 11))
        else:
            afegeix(e['codi'], e['x'], e['y'], e['mirall'], estil_fantasma(reg[e['codi']]['rols']), extra=' opacity=".5"')
    for p in m.punts:
        if p['tipus'] != 'pastor' and p['zona'] not in obertes: continue
        if estat == 'terreny': continue
        if rng.random() < frac:
            afegeix(p['codi'], p['x'], p['y'], p['mirall'], p['colors'])
        else:
            afegeix('MARCA-PER' if p['tipus'] != 'animal' else 'MARCA-ANI', p['x'], p['y'])
    cos.sort(key=lambda t: t[0])
    for d in dec: usats.add(d[0])
    tot = P.totes()
    simbols = ''.join(f'<symbol id="s-{c}" viewBox="0 0 {tot[c].w} {tot[c].h}">\n{tot[c].svg_interior("")}\n</symbol>\n' for c in sorted(usats))
    x0, y0, w, h = retall or (0, 0, T.W, T.H)
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {y0} {w} {h}" width="{round(w * escala)}" height="{round(h * escala)}" shape-rendering="crispEdges" style="background:var(--cel-alt,#0A1247);{MO.style(moment)}">']
    s.append('<defs>' + simbols + '</defs>')
    s += terr[1:]
    s.append('<g id="decoracio">' + ''.join(us(c, reg, x, y) for c, x, y in dec) + '</g>')
    s.append('<g id="llum-terra">' + ''.join(llum_terra(m, tolls)) + '</g>')
    s.append('<g id="peces">' + '\n'.join(t for _, t in cos) + '</g>')
    s.append('<g id="llum-aire">' + ''.join(llum_aire(m, halos)) + '</g>')
    s.append('</svg>')
    return '\n'.join(s)


if __name__ == '__main__':
    arrel = os.path.abspath(sys.argv[1])
    m = Mapa().construeix(); ocupants(m)
    print(json.dumps({k: v['total'] for k, v in m.recompte().items()}))
    feina = sys.argv[2:] or ['completa']
    V = {
        'escena-completa': ('ple', None, 2), 'detall-naixement': ('ple', (1400, 380, 480, 300), 4), 'detall-casc-antic': ('ple', (790, 170, 660, 500), 3),
        'detall-llocs-lliures': ('participa', (760, 170, 1100, 620), 2), 'terreny': ('terreny', None, 1), 'detall-clariana': ('ple', (120, 220, 480, 300), 4),
        'detall-reis-i-riu': ('ple', (40, 440, 1000, 360), 2), 'x1': ('ple', None, 1),
        'moment-dia': ('ple', None, 1, 'dia'), 'moment-posta': ('ple', None, 1, 'posta'), 'moment-nit': ('ple', None, 1, 'nit'), 'moment-neu': ('ple', None, 1, 'neu'),
        'moment-dia-naixement': ('ple', (1400, 380, 480, 300), 3, 'dia'), 'moment-posta-naixement': ('ple', (1400, 380, 480, 300), 3, 'posta'), 'moment-neu-naixement': ('ple', (1400, 380, 480, 300), 3, 'neu'), 'moment-neu-casc': ('ple', (790, 170, 660, 500), 2, 'neu'),
    }
    for nom in feina:
        estat, retall, esc, *mo = V[nom]
        svg = escena(m, estat, retall=retall, escala=esc, moment=(mo[0] if mo else 'nit'))
        cami = f'/tmp/v2-{nom}.svg'
        open(cami, 'w').write(svg)
        w, h = (retall[2], retall[3]) if retall else (T.W, T.H)
        captura(cami, os.path.join(arrel, 'vistes', f'{nom}.png'), round(w * esc), round(h * esc))
        print(nom, len(svg) // 1024, 'KB')
