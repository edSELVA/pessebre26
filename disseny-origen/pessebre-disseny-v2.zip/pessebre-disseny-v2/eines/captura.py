import sys, asyncio
from playwright.sync_api import sync_playwright
def captura(svg, png, w, h, escala=1):
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = b.new_page(viewport={'width': w, 'height': h}, device_scale_factor=escala)
        pg.goto('file://' + svg)
        pg.screenshot(path=png, full_page=False)
        b.close()
if __name__ == '__main__':
    captura(sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), float(sys.argv[5]) if len(sys.argv) > 5 else 1)
