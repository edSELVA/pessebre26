"""Full de contacte ràpid (PIL) per revisar peces: python3 eines/full.py sortida.png escala modul [filtre]"""
import sys, importlib
from PIL import Image
import numpy as np
import px


def imatge(cv, colors=None):
    pal = np.zeros((len(px._NOMS), 4), np.uint8)
    for i, n in enumerate(px._NOMS):
        if n is None:
            continue
        hexa, op = px.ROLS[n]
        if colors and n in colors:
            hexa = colors[n]
        pal[i] = [int(hexa[1:3], 16), int(hexa[3:5], 16), int(hexa[5:7], 16), int(255 * op)]
    return Image.fromarray(pal[cv.g], 'RGBA')


def full(peces, sortida, escala=5, cols=5, fons=(140, 191, 63, 255)):
    noms = list(peces)
    cw = max(p.w for p in peces.values()) + 4
    ch = max(p.h for p in peces.values()) + 4
    files = (len(noms) + cols - 1) // cols
    im = Image.new('RGBA', (cols * cw, files * ch), fons)
    for i, n in enumerate(noms):
        p = imatge(peces[n])
        im.alpha_composite(p, ((i % cols) * cw + (cw - p.width) // 2, (i // cols) * ch + ch - p.height - 2))
    im = im.resize((im.width * escala, im.height * escala), Image.NEAREST)
    im.save(sortida)


if __name__ == '__main__':
    mod = importlib.import_module(sys.argv[3])
    peces = mod.totes()
    if len(sys.argv) > 4:
        peces = {k: v for k, v in peces.items() if sys.argv[4] in k}
    full(peces, sys.argv[1], int(sys.argv[2]), cols=int(sys.argv[5]) if len(sys.argv) > 5 else 5)
