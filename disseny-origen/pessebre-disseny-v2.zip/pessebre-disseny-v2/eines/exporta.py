"""Exporta terreny, capes de llum i moments com a fitxers independents: python3 exporta.py <arrel>"""
import json, os, sys
import terreny as T, compon as C, peces as P, moments as MO
from mapa import Mapa

arrel = os.path.abspath(sys.argv[1])
for d in ('terreny', 'llum', 'moments'):
    os.makedirs(os.path.join(arrel, d), exist_ok=True)
m = Mapa().construeix(); reg = m.reg
terr, dec = C.terreny_svg(m)
tot = P.totes()
usats = sorted({c for c, _, _ in dec})
simbols = ''.join(f'<symbol id="s-{c}" viewBox="0 0 {tot[c].w} {tot[c].h}">\n{tot[c].svg_interior("")}\n</symbol>\n' for c in usats)
cos = terr[0].replace('shape-rendering="crispEdges">', 'shape-rendering="crispEdges" data-capa="terreny">') + '\n<defs>' + simbols + '</defs>\n' + '\n'.join(terr[1:]) + \
      '\n<g id="decoracio">' + ''.join(C.us(c, reg, x, y) for c, x, y in dec) + '</g>\n</svg>\n'
open(os.path.join(arrel, 'terreny', 'terreny.svg'), 'w').write(cos)
# llum estàtica (sense llums per casa: aquestes són peces LLUM-TOLL i LLUM-HALO)
cap = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {T.W} {T.H}" width="{T.W}" height="{T.H}" data-capa="%s">\n'
open(os.path.join(arrel, 'llum', 'llum-terra.svg'), 'w').write(cap % 'llum-terra' + '\n'.join(C.llum_terra(m, [])) + '\n</svg>\n')
defs = C.LLUM_DEFS
open(os.path.join(arrel, 'llum', 'llum-aire.svg'), 'w').write(cap % 'llum-aire' + defs + '\n' + '\n'.join(C.llum_aire(m, [])) + '\n</svg>\n')
for nom, (rx, ry, g) in {'LLUM-TOLL': (30, 11, 'l-toll'), 'LLUM-HALO': (20, 20, 'l-suau')}.items():
    w, h = rx * 2, ry * 2
    open(os.path.join(arrel, 'llum', nom + '.svg'), 'w').write(
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" data-codi="{nom}" data-ancoratge="{rx},{ry}">{defs}<ellipse cx="{rx}" cy="{ry}" rx="{rx}" ry="{ry}" fill="url(#{g})"/></svg>\n')
# moments
res = {}
for k, v in MO.MOMENTS.items():
    open(os.path.join(arrel, 'moments', f'{k}.css'), 'w').write(f'/* {v["nom"]}: variables de color i opacitat de llum. Aplica la classe .moment-{k} a l\'arrel de l\'escena. */\n' + MO.css(k))
    res[k] = {'nom': v['nom'], 'classe': f'moment-{k}', 'fitxer': f'moments/{k}.css', 'variables': MO.variables(k)}
res['_nota'] = 'nit = valors per defecte de cada variable (només cal fixar les opacitats). neu: a més l\'app ha de nevar les teulades de les cases (barreja --teulada* amb #F2F7FF 82%; el --teulada-fosc 60%).'
json.dump(res, open(os.path.join(arrel, 'moments', 'moments.json'), 'w'), ensure_ascii=False, indent=1)
print('ok', os.path.getsize(os.path.join(arrel, 'terreny', 'terreny.svg')) // 1024, 'KB terreny')
