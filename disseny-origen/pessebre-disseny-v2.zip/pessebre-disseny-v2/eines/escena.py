"""Peces d'escena fixa i elements construïts del pessebre v2."""
import math
import numpy as np
from px import Llenc, RNG, pedres, _id
from cases import teules, finestra
from figures import _ombra


def mascara(cv, x, y, w, h):
    m = np.zeros_like(cv.g, bool)
    m[max(0, y):max(0, y + h), max(0, x):max(0, x + w)] = True
    return m


def biga(cv, x, y, w, h):
    cv.rect(x, y, w, h, 'fusta')
    if h > w:
        cv.vl(x, y, h, 'fusta-clar'); cv.vl(x + w - 1, y, h, 'fusta-ombra')
        for yy in range(y + 3, y + h, 7):
            cv.p(x + 1, yy, 'fusta-ombra')
    else:
        cv.hl(x, y, w, 'fusta-clar'); cv.hl(x, y + h - 1, w, 'fusta-ombra')
        for xx in range(x + 4, x + w, 9):
            cv.p(xx, y + 1, 'fusta-ombra')


def fanalet(cv, x, y):
    cv.vl(x + 1, y - 3, 3, 'contorn')
    cv.rect(x, y, 4, 5, 'llum'); cv.p(x + 1, y + 1, 'llum-clar'); cv.hl(x, y + 4, 4, 'llum-ombra')
    cv.hl(x - 1, y - 1, 6, 'contorn'); cv.hl(x - 1, y + 5, 6, 'contorn'); cv.vl(x - 1, y, 5, 'contorn'); cv.vl(x + 4, y, 5, 'contorn')


def naixement():
    W, H = 188, 136
    cv = Llenc(W, H); rng = RNG(7); cx = 94
    yS = 108           # nivell del terra de la terrassa
    # ---------- terrassa de pedra
    cv.rect(6, yS, 176, 24, 'pedra')
    pedres(cv, mascara(cv, 6, yS + 4, 176, 20), rng, alt=4)
    cv.rect(4, yS, 180, 4, 'pedra-clar')
    for x in range(8, 182, 9):
        cv.p(x, yS + 1, 'pedra-ombra'); cv.p(x + 4, yS + 3, 'pedra-ombra')
    cv.hl(4, yS + 4, 180, 'pedra-fosc')
    # escales centrals
    for i in range(5):
        w = 52 + i * 6
        y = yS + 2 + i * 5
        cv.rect(cx - w // 2, y, w, 5, 'pedra-clar'); cv.hl(cx - w // 2, y + 3, w, 'pedra'); cv.hl(cx - w // 2, y + 4, w, 'pedra-ombra')
        cv.vl(cx - w // 2 - 1, y, 5, 'pedra-fosc'); cv.vl(cx + w // 2, y, 5, 'pedra-fosc')
        for x in range(cx - w // 2 + 5, cx + w // 2, 11):
            cv.p(x + i * 3 % 7, y + 1, 'pedra')
    # ---------- ales de pedra amb arc (bou i mula)
    for s in (-1, 1):
        ax = cx + s * 62            # centre de l'ala
        x0 = ax - 24
        cv.rect(x0, 62, 48, yS - 62, 'pedra')
        pedres(cv, mascara(cv, x0, 62, 48, yS - 62), rng, alt=4)
        # obertura d'arc, fosca i càlida
        for y in range(70, yS):
            for x in range(ax - 16, ax + 17):
                dy = max(0, 86 - y)
                if (x - ax) ** 2 / 16.5 ** 2 + dy ** 2 / 16.5 ** 2 <= 1:
                    d = math.hypot(x - (cx + s * 40), y - 100)
                    c = 'fusta-ombra' if d > 34 else ('fusta' if d > 24 else 'bru')
                    if (x + y) % 2 and 22 < d <= 26: c = 'fusta-ombra' if d > 24 else 'fusta'
                    cv.p(x, y, c)
        # dovelles
        for a in range(0, 181, 12):
            xx = ax + round(math.cos(math.radians(a)) * 18); yy = 86 - round(math.sin(math.radians(a)) * 18)
            cv.rect(xx - 1, yy - 1, 3, 3, 'pedra-clar'); cv.p(xx + 1, yy + 1, 'pedra-ombra')
        cv.rect(ax - 16, yS - 4, 33, 4, 'palla'); cv.hl(ax - 16, yS - 4, 33, 'palla-clar')
        for x in range(ax - 15, ax + 16, 3):
            cv.p(x, yS - 2, 'palla-ombra'); cv.p(x + 1, yS - 5, 'palla')
        # teuladet de l'ala
        m = np.zeros_like(cv.g, bool)
        for r in range(9):
            a = x0 - 3 + (8 - r) // 2 if s < 0 else x0 - 1
            b = x0 + 49 if s < 0 else x0 + 51 - (8 - r) // 2
            m[54 + r, a:b] = True
        teules(cv, m, rng)
        cv.hl(x0 - 3, 63, 54, 'contorn')
        cv.hl(x0, 64, 48, 'pedra-fosc')
    # ---------- interior del porxo: llum que neix del Nen
    x0, x1 = cx - 36, cx + 36
    for y in range(40, yS):
        for x in range(x0, x1 + 1):
            d = math.hypot((x - cx) * .85, (y - 92) * 1.05)
            nivells = [(13, 'llum-clar'), (23, 'palla-clar'), (33, 'llum'), (42, 'palla'), (52, 'foc'), (62, 'bru-clar'), (999, 'bru')]
            for k, (r, c) in enumerate(nivells):
                if d <= r:
                    # tramat a la frontera
                    if d > r - 2.5 and (x + y) % 2 and k + 1 < len(nivells):
                        c = nivells[k + 1][1]
                    cv.p(x, y, c)
                    break
    # taulons del fons, molt suaus
    for x in range(x0 + 6, x1, 9):
        for y in range(42, yS - 8, 2):
            if cv.get(x, y) in ('bru', 'bru-clar', 'foc'):
                cv.p(x, y, 'bru' if cv.get(x, y) != 'bru' else 'fusta')
    # palla a terra
    cv.rect(x0, yS - 5, 73, 5, 'palla'); cv.hl(x0, yS - 5, 73, 'palla-clar')
    for x in range(x0, x1, 2):
        cv.p(x + rng.randint(0, 1), yS - 6, 'palla-clar'); cv.p(x, yS - rng.randint(1, 3), 'palla-ombra')
    # ---------- estructura de fusta
    for px_ in (x0 - 5, x1 + 1):
        biga(cv, px_, 40, 5, yS - 40)
        cv.rect(px_ - 1, yS - 3, 7, 3, 'pedra-clar'); cv.hl(px_ - 1, yS - 1, 7, 'pedra-ombra')
    # tornapuntes
    for i in range(9):
        cv.rect(x0 + i, 52 - i, 2, 2, 'fusta'); cv.p(x0 + i, 53 - i, 'fusta-ombra')
        cv.rect(x1 - 1 - i, 52 - i, 2, 2, 'fusta'); cv.p(x1 - i, 53 - i, 'fusta-ombra')
    biga(cv, x0 - 9, 36, 91, 5)                      # tirant
    # frontó obert: encavallada
    apex = 6
    for y in range(apex + 8, 36):
        t = (y - apex) / (36 - apex)
        half = int(t * 47)
        for x in range(cx - half + 4, cx + half - 3):
            d = math.hypot(x - cx, (y - 60))
            cv.p(x, y, 'bru' if d < 34 else 'fusta-ombra')
    biga(cv, cx - 2, apex + 8, 5, 28)                # monjo
    for i in range(18):
        cv.rect(cx - 4 - i, 33 - round(i * .62), 3, 2, 'fusta'); cv.rect(cx + 2 + i, 33 - round(i * .62), 3, 2, 'fusta-ombra')
    # ---------- coberta de palla
    for s in (-1, 1):
        for i in range(0, 58):
            x = cx + (s * i) + (0 if s > 0 else -1)
            y = apex + round(i * 30 / 47)
            for k in range(10):
                c = 'palla'
                if k == 0: c = 'palla-clar'
                elif k >= 8: c = 'palla-ombra'
                elif (i + k * 2) % 5 == 0: c = 'palla-ombra'
                elif (i * 3 + k) % 7 == 0: c = 'palla-clar'
                if s > 0 and c == 'palla' and k > 4: c = 'palla-ombra' if (i + k) % 2 else 'palla'
                cv.p(x, y + k, c)
            cv.p(x, y + 10, 'palla-fosc')
            if i % 4 == 0 and i > 44:
                cv.p(x, y + 11, 'palla-ombra')
    cv.rect(cx - 3, apex - 2, 6, 5, 'palla-clar'); cv.hl(cx - 3, apex + 2, 6, 'palla-ombra')
    # fanals
    fanalet(cv, cx - 2, 44)
    fanalet(cv, x0 - 16, 68); fanalet(cv, x1 + 13, 68)
    cv.contorn()
    # flors i heura a la base
    for x in list(range(8, 60, 3)) + list(range(128, 180, 3)):
        if rng.random() < .8:
            h = rng.randint(2, 6)
            for k in range(h):
                cv.p(x + rng.randint(0, 1), yS + 23 - k, rng.choice(['fulla', 'fulla-clar', 'fulla-ombra']))
            if rng.random() < .6:
                cv.p(x, yS + 23 - h, rng.choice(['flor', 'flor-clar', 'fruit', 'groc']))
    for x in range(4, 186):
        if cv.get(x, yS + 25) is None: cv.p(x, yS + 25, 'ombra-terra')
        if 8 < x < 182 and cv.get(x, yS + 26) is None: cv.p(x, yS + 26, 'ombra-terra')
    return cv


def maria():
    cv = Llenc(28, 34)
    # mantell blau agenollada
    cv.poli([(8, 12), (17, 12), (23, 30), (3, 30)], 'roba')
    cv.poli([(8, 12), (11, 12), (7, 30), (3, 30)], 'roba-clar')
    cv.poli([(18, 14), (23, 30), (18, 30)], 'roba-ombra')
    cv.hl(3, 30, 21, 'roba-ombra')
    cv.rect(10, 14, 6, 9, 'blanc'); cv.vl(15, 14, 9, 'blanc-ombra'); cv.hl(10, 22, 6, 'blanc-ombra')
    cv.rect(11, 17, 4, 3, 'pell'); cv.p(14, 19, 'pell-ombra')          # mans juntes
    # cap inclinat cap al Nen
    cv.rect(10, 5, 7, 6, 'pell'); cv.hl(11, 11, 5, 'pell-ombra')
    cv.p(12, 8, 'contorn'); cv.p(15, 8, 'contorn'); cv.p(11, 9, 'flor-clar'); cv.p(16, 9, 'flor-clar')
    cv.rect(9, 2, 9, 3, 'roba'); cv.hl(10, 1, 7, 'roba-clar'); cv.hl(9, 2, 4, 'roba-clar')
    cv.vl(8, 3, 10, 'roba-clar'); cv.vl(9, 4, 8, 'roba'); cv.vl(18, 3, 11, 'roba-ombra'); cv.vl(17, 5, 7, 'roba')
    cv.hl(10, 5, 7, 'blanc'); cv.p(10, 6, 'blanc'); cv.p(16, 6, 'blanc-ombra')
    cv.contorn()
    _ombra(cv, 3, 25, 32)
    return cv


def josep():
    cv = Llenc(28, 38)
    cv.rect(8, 13, 11, 20, 'roba'); cv.vl(8, 13, 20, 'roba-clar'); cv.vl(9, 14, 18, 'roba-clar'); cv.vl(18, 13, 20, 'roba-ombra'); cv.vl(17, 15, 18, 'roba-ombra')
    cv.rect(7, 26, 13, 7, 'roba'); cv.vl(7, 26, 7, 'roba-clar'); cv.vl(19, 26, 7, 'roba-ombra'); cv.hl(7, 32, 13, 'roba-ombra')
    cv.rect(11, 13, 5, 19, 'mocador'); cv.vl(15, 13, 19, 'mocador-ombra'); cv.hl(8, 21, 11, 'fusta-ombra'); cv.p(13, 21, 'or')
    cv.rect(5, 15, 3, 9, 'roba'); cv.vl(5, 15, 9, 'roba-clar'); cv.rect(19, 15, 3, 7, 'roba-ombra')
    cv.rect(5, 24, 3, 2, 'pell'); cv.rect(20, 21, 3, 2, 'pell-ombra')
    cv.rect(9, 33, 4, 2, 'fusta-ombra'); cv.rect(15, 33, 4, 2, 'fusta-ombra')
    # cap
    cv.rect(10, 5, 8, 6, 'pell'); cv.p(12, 7, 'contorn'); cv.p(15, 7, 'contorn')
    cv.rect(10, 9, 8, 4, 'cabell'); cv.hl(11, 13, 6, 'cabell-ombra'); cv.hl(12, 9, 4, 'pell'); cv.hl(13, 10, 2, 'pell-ombra')
    cv.rect(9, 2, 10, 3, 'cabell'); cv.hl(10, 1, 8, 'cabell'); cv.vl(9, 4, 6, 'cabell'); cv.vl(18, 4, 6, 'cabell-ombra'); cv.hl(10, 2, 4, 'bru')
    # bastó
    cv.vl(23, 3, 31, 'fusta'); cv.vl(24, 3, 31, 'fusta-ombra'); cv.hl(21, 2, 3, 'fusta'); cv.p(20, 3, 'fusta'); cv.p(20, 4, 'fusta')
    cv.contorn()
    _ombra(cv, 5, 25, 36)
    return cv


def jesus():
    cv = Llenc(30, 24)
    # aurèola
    for a in range(0, 360, 6):
        cv.p(8 + round(math.cos(math.radians(a)) * 6.4), 7 + round(math.sin(math.radians(a)) * 6.4), 'or')
    for a in range(0, 360, 5):
        cv.p(8 + round(math.cos(math.radians(a)) * 5.4), 7 + round(math.sin(math.radians(a)) * 5.4), 'llum-clar')
    # bressol de fusta amb palla
    cv.poli([(3, 12), (26, 12), (23, 18), (6, 18)], 'fusta'); cv.hl(3, 12, 24, 'fusta-clar'); cv.hl(6, 18, 18, 'fusta-ombra')
    for x in range(6, 24, 4):
        cv.vl(x, 13, 5, 'fusta-ombra')
    cv.linia(6, 18, 3, 22, 'fusta'); cv.linia(23, 18, 26, 22, 'fusta'); cv.linia(9, 18, 12, 22, 'fusta-ombra'); cv.linia(20, 18, 17, 22, 'fusta-ombra')
    cv.rect(4, 9, 22, 3, 'palla'); cv.hl(4, 9, 22, 'palla-clar')
    for x in range(3, 27, 2):
        cv.p(x, 8 + x % 3, 'palla-clar'); cv.p(x + 1, 12, 'palla-ombra')
    # el Nen
    cv.rect(11, 5, 13, 5, 'blanc'); cv.hl(12, 4, 11, 'blanc'); cv.hl(11, 9, 13, 'blanc-ombra'); cv.vl(16, 5, 4, 'blanc-ombra'); cv.vl(20, 5, 4, 'blanc-ombra')
    cv.rect(5, 4, 6, 6, 'pell'); cv.hl(6, 3, 4, 'pell'); cv.hl(6, 3, 4, 'cabell') ; cv.p(7, 6, 'contorn'); cv.p(9, 6, 'contorn'); cv.p(6, 8, 'flor-clar'); cv.hl(6, 9, 4, 'pell-ombra')
    m = cv.mask('or', 'llum-clar')
    cv.contorn(dins=~m)
    return cv


def angel():
    cv = Llenc(34, 30)
    cx = 17
    # ales
    for s in (-1, 1):
        for i in range(11):
            h = 9 - abs(i - 4)
            x = cx + s * (4 + i)
            y0 = 10 - i // 2
            cv.vl(x, y0, max(2, h), 'blanc' if s < 0 else 'blanc-ombra')
            cv.p(x, y0, 'blanc')
            if i % 3 == 2: cv.vl(x, y0 + 2, max(1, h - 3), 'blanc-ombra' if s < 0 else 'gris-clar')
    # túnica
    cv.poli([(13, 12), (20, 12), (23, 25), (10, 25)], 'blanc'); cv.poli([(18, 12), (20, 12), (23, 25), (19, 25)], 'blanc-ombra')
    cv.hl(10, 25, 14, 'blanc-ombra'); cv.hl(13, 16, 8, 'or'); cv.vl(16, 17, 7, 'blanc-ombra')
    cv.rect(9, 12, 4, 3, 'blanc'); cv.rect(21, 12, 4, 3, 'blanc-ombra'); cv.rect(7, 11, 2, 2, 'pell'); cv.rect(25, 11, 2, 2, 'pell-ombra')
    # cap
    cv.rect(13, 5, 8, 6, 'pell'); cv.p(15, 8, 'contorn'); cv.p(18, 8, 'contorn'); cv.p(14, 9, 'flor-clar'); cv.p(19, 9, 'flor-clar'); cv.hl(14, 11, 6, 'pell-ombra')
    cv.rect(12, 3, 10, 3, 'groc'); cv.hl(13, 2, 8, 'groc-clar'); cv.vl(12, 5, 4, 'groc'); cv.vl(21, 5, 4, 'groc-ombra'); cv.hl(13, 5, 2, 'groc')
    cv.contorn()
    cv.hl(12, 0, 10, 'or'); cv.p(11, 1, 'or'); cv.p(22, 1, 'or')
    return cv


def estel():
    cv = Llenc(96, 44)
    cx, cy = 18, 24
    # cua
    for i in range(70):
        t = i / 70
        x = cx + 6 + i
        y = cy - 2 - round(16 * math.sin(t * 1.9) ) + round(t * t * 14)
        w = max(1, round(8 * (1 - t) + 1))
        for k in range(w):
            c = 'groc' if k < w - 2 else 'groc-ombra'
            if k == 0: c = 'groc-clar'
            cv.p(x, y + k, c)
    # estel de cinc puntes
    pts = []
    for k in range(10):
        a = -math.pi / 2 + k * math.pi / 5
        r = 16 if k % 2 == 0 else 7
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    cv.poli([(round(x), round(y)) for x, y in pts], 'groc')
    for y in range(cv.h):
        for x in range(cv.w):
            if cv.get(x, y) == 'groc' and math.hypot(x - cx, y - cy) < 17:
                if x - cx + (y - cy) > 5: cv.p(x, y, 'groc-ombra')
                elif math.hypot(x - cx + 2, y - cy + 2) < 5: cv.p(x, y, 'groc-clar')
    cv.contorn('or-ombra')
    return cv


def foguera():
    cv = Llenc(22, 24)
    for (x, w, h, c) in [(5, 12, 12, 'foc-ombra'), (7, 8, 10, 'foc'), (9, 4, 7, 'foc-clar')]:
        for i in range(h):
            ww = max(1, round(w * (1 - (i / h) ** 1.6)))
            cv.hl(11 - ww // 2 + (1 if i % 4 == 1 else 0), 17 - i, ww, c)
    cv.p(6, 7, 'foc'); cv.p(15, 9, 'foc'); cv.p(11, 3, 'foc-ombra')
    cv.linia(3, 20, 17, 16, 'fusta'); cv.linia(3, 21, 17, 17, 'fusta-ombra'); cv.linia(18, 20, 5, 16, 'fusta'); cv.linia(18, 21, 5, 17, 'fusta-ombra')
    for x in (2, 6, 10, 14, 18):
        cv.rect(x, 20, 3, 2, 'gris-clar'); cv.p(x + 2, 21, 'gris')
    cv.contorn(dins=~cv.mask('foc', 'foc-clar', 'foc-ombra'))
    return cv


def rei(i=0):
    cv = Llenc(44, 50)
    c1, c2, c3 = 'camell-clar', 'camell', 'camell-ombra'
    # camell mirant a la dreta
    cv.rect(8, 26, 22, 10, c2); cv.hl(8, 26, 22, c1); cv.hl(9, 25, 20, c1); cv.hl(8, 35, 22, c3)
    cv.ellipse(18, 25, 6, 4, c2); cv.hl(14, 22, 8, c1)                                   # gep
    cv.poli([(27, 30), (33, 30), (36, 16), (31, 16)], c2); cv.vl(31, 17, 12, c1)          # coll
    cv.rect(31, 12, 9, 6, c2); cv.hl(31, 12, 8, c1); cv.rect(38, 15, 3, 3, c1); cv.p(40, 17, 'contorn'); cv.p(35, 14, 'contorn'); cv.rect(31, 10, 2, 3, c2)
    cv.linia(40, 18, 33, 24, 'vermell')
    for x in (10, 14, 24, 28):
        cv.rect(x, 36, 3, 9, c2 if x in (10, 24) else c3); cv.rect(x - (0), 45, 4, 1, 'fusta-ombra')
    cv.vl(7, 27, 7, c3)
    # manta
    cv.rect(12, 24, 14, 9, 'vermell'); cv.hl(12, 32, 14, 'or'); cv.vl(12, 24, 9, 'vermell'); cv.vl(25, 24, 9, 'vermell-ombra')
    for x in range(13, 25, 3): cv.p(x, 28, 'or')
    # rei
    cv.rect(14, 12, 10, 13, 'roba'); cv.vl(14, 12, 13, 'roba-clar'); cv.vl(23, 12, 13, 'roba-ombra'); cv.hl(14, 20, 10, 'or'); cv.vl(18, 12, 8, 'or')
    cv.rect(22, 15, 5, 3, 'roba-ombra'); cv.rect(27, 15, 2, 3, 'pell')
    cv.rect(15, 5, 8, 6, 'pell'); cv.p(18, 7, 'contorn'); cv.p(21, 7, 'contorn')
    cv.rect(15, 9, 8, 4, 'cabell'); cv.hl(16, 13, 6, 'cabell-ombra'); cv.hl(18, 9, 3, 'pell')
    cv.rect(15, 2, 8, 3, 'or'); cv.p(15, 1, 'or'); cv.p(18, 1, 'or'); cv.p(19, 1, 'or'); cv.p(22, 1, 'or'); cv.hl(15, 4, 8, 'or-ombra'); cv.p(18, 3, 'vermell'); cv.p(21, 3, 'verd')
    cv.vl(14, 5, 5, 'cabell')
    cv.contorn()
    _ombra(cv, 7, 34, 47)
    return cv


def moli_aigua():
    cv = Llenc(84, 70); rng = RNG(3)
    # caseta de pedra
    x0, x1, yT, B = 34, 78, 30, 66
    cv.rect(x0, yT, x1 - x0 + 1, B - yT + 1, 'pedra')
    pedres(cv, mascara(cv, x0, yT, x1 - x0 + 1, B - yT + 1), rng, alt=4)
    m = np.zeros_like(cv.g, bool)
    for r in range(13):
        m[yT - 13 + r, x0 - 3 + (12 - r) // 2: x1 + 4 - (12 - r) // 2] = True
    teules(cv, m, rng); cv.hl(x0 - 3, yT, x1 - x0 + 7, 'contorn'); cv.hl(x0, yT + 1, x1 - x0 + 1, 'pedra-fosc')
    finestra(cv, x0 + 28, yT + 7, 7, 7); finestra(cv, x0 + 14, yT + 7, 7, 7)
    cv.rect(x0 + 26, B - 13, 9, 14, 'porta'); cv.vl(x0 + 26, B - 13, 14, 'porta-ombra'); cv.vl(x0 + 30, B - 12, 13, 'porta-ombra'); cv.hl(x0 + 25, B - 14, 11, 'fusta-clar')
    # roda
    cx, cy, R = 24, 44, 21
    for a in range(0, 360, 1):
        for r in (R, R - 1, R - 2, R - 6, R - 7):
            cv.p(cx + round(math.cos(math.radians(a)) * r), cy + round(math.sin(math.radians(a)) * r), 'fusta' if r in (R - 1, R - 6) else ('fusta-clar' if r == R else 'fusta-ombra'))
    for a in range(0, 360, 30):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        cv.linia(cx, cy, cx + round(ca * (R - 2)), cy + round(sa * (R - 2)), 'fusta')
        cv.linia(cx + 1, cy, cx + 1 + round(ca * (R - 2)), cy + round(sa * (R - 2)), 'fusta-ombra')
        px_, py_ = cx + round(ca * (R + 1)), cy + round(sa * (R + 1))
        cv.rect(px_ - 1, py_ - 1, 3, 3, 'fusta-clar')
    cv.rect(cx - 2, cy - 2, 5, 5, 'gris'); cv.p(cx - 1, cy - 1, 'gris-clar')
    cv.contorn()
    for x in range(8, 30, 3):
        cv.vl(x, 62 + x % 2, 4, 'escuma'); cv.vl(x + 1, 63, 3, 'aigua-clar')
    return cv


def pont():
    cv = Llenc(120, 40); rng = RNG(5)
    for x in range(2, 118):
        t = (x - 60) / 58
        top = 6 + round(8 * t * t)
        cv.vl(x, top, 36 - top, 'pedra')
    pedres(cv, cv.plena().copy(), rng, alt=4)
    for x in range(2, 118):
        t = (x - 60) / 58
        top = 6 + round(8 * t * t)
        cv.rect(x, top, 1, 3, 'pedra-clar'); cv.p(x, top + 3, 'pedra-fosc')
        if x % 7 == 0: cv.p(x, top + 1, 'pedra-ombra')
    for acx in (38, 82):
        for y in range(14, 37):
            for x in range(acx - 17, acx + 18):
                dy = max(0, 30 - y)
                if (x - acx) ** 2 + (dy * 1.15) ** 2 <= 16 ** 2:
                    cv.p(x, y, 'aigua-ombra' if y > 30 else 'nit')
        for a in range(0, 181, 14):
            xx = acx + round(math.cos(math.radians(a)) * 17); yy = 30 - round(math.sin(math.radians(a)) * 15)
            cv.rect(xx - 1, yy - 1, 3, 3, 'pedra-clar'); cv.p(xx + 1, yy + 1, 'pedra-ombra')
        for x in range(acx - 14, acx + 15, 4):
            cv.hl(x, 33 + (x % 3), 2, 'aigua-clar')
    cv.contorn()
    cv.g[37:, :] = 0
    return cv


def castell():
    cv = Llenc(110, 52); rng = RNG(11)
    def torre(x, w, top):
        cv.rect(x, top, w, 50 - top, 'pedra')
        for xx in range(x - 1, x + w, 4):
            cv.rect(xx, top - 3, 2, 3, 'pedra')
        cv.rect(x + w // 2 - 1, top + 6, 3, 5, 'llum')
    cv.rect(8, 28, 94, 22, 'pedra')
    for xx in range(8, 102, 5):
        cv.rect(xx, 25, 3, 3, 'pedra')
    torre(4, 14, 16); torre(92, 14, 18); torre(40, 18, 6); torre(64, 12, 14)
    pedres(cv, cv.mask('pedra'), rng, base='pedra', clar='pedra-clar', ombra='pedra-ombra', alt=4)
    cv.rect(26, 34, 4, 6, 'llum'); cv.rect(78, 34, 4, 6, 'llum'); cv.rect(47, 14, 4, 6, 'llum')
    for y in range(36, 50):
        for x in range(50, 61):
            if (x - 55) ** 2 + max(0, 42 - y) ** 2 <= 30: cv.p(x, y, 'fusta-ombra')
    cv.contorn()
    return cv


def aqueducte():
    cv = Llenc(150, 44); rng = RNG(13)
    cv.rect(0, 6, 150, 38, 'pedra')
    pedres(cv, cv.mask('pedra'), rng, alt=4)
    cv.rect(0, 6, 150, 3, 'pedra-clar'); cv.hl(0, 9, 150, 'pedra-fosc')
    for acx in range(15, 150, 30):
        for y in range(14, 44):
            for x in range(acx - 11, acx + 12):
                if (x - acx) ** 2 + max(0, 26 - y) ** 2 <= 11 ** 2:
                    cv.g[y, x] = 0
    cv.contorn()
    return cv


def moli_vent():
    cv = Llenc(56, 62); rng = RNG(17)
    cx = 28
    cv.poli([(cx - 9, 28), (cx + 9, 28), (cx + 12, 58), (cx - 12, 58)], 'facana')
    cv.poli([(cx - 9, 28), (cx - 5, 28), (cx - 8, 58), (cx - 12, 58)], 'facana-clar')
    cv.poli([(cx + 5, 28), (cx + 9, 28), (cx + 12, 58), (cx + 7, 58)], 'facana-ombra')
    for _ in range(14):
        x = rng.randint(cx - 7, cx + 5); y = rng.randint(31, 55); cv.hl(x, y, 3, 'facana-ombra')
    cv.poli([(cx - 11, 28), (cx, 17), (cx + 1, 17), (cx + 11, 28)], 'teulada'); cv.poli([(cx + 1, 17), (cx + 11, 28), (cx + 4, 28)], 'teulada-ombra'); cv.linia(cx - 10, 27, cx, 18, 'teulada-clar')
    cv.rect(cx - 3, 48, 7, 11, 'porta'); cv.vl(cx, 49, 10, 'porta-ombra'); cv.rect(cx - 2, 36, 5, 6, 'llum'); cv.vl(cx, 36, 6, 'fusta-ombra')
    cv.contorn()
    # aspes
    hx, hy = cx, 24
    for a in (35, 125, 215, 305):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        for i in range(3, 25):
            x, y = hx + ca * i, hy + sa * i
            cv.p(round(x), round(y), 'fusta-ombra')
            if i > 7:
                for k in range(1, 6):
                    xx, yy = round(x - sa * k), round(y + ca * k)
                    cv.p(xx, yy, 'blanc' if (i + k) % 3 else 'fusta-clar')
    cv.rect(hx - 1, hy - 1, 3, 3, 'fusta-ombra')
    _ombra(cv, cx - 13, cx + 15, 60)
    return cv


def pou():
    cv = Llenc(28, 34); rng = RNG(19)
    cv.rect(5, 20, 18, 11, 'pedra'); pedres(cv, mascara(cv, 5, 20, 18, 11), rng, alt=3)
    cv.rect(4, 18, 20, 3, 'pedra-clar'); cv.hl(4, 20, 20, 'pedra-ombra')
    cv.vl(6, 6, 12, 'fusta'); cv.vl(7, 6, 12, 'fusta-ombra'); cv.vl(20, 6, 12, 'fusta'); cv.vl(21, 6, 12, 'fusta-ombra')
    m = np.zeros_like(cv.g, bool)
    for r in range(6):
        m[1 + r, 3 + (5 - r): 25 - (5 - r)] = True
    teules(cv, m, rng); cv.hl(3, 7, 22, 'contorn')
    cv.hl(8, 10, 12, 'fusta-ombra'); cv.vl(14, 11, 4, 'contorn'); cv.rect(12, 14, 5, 4, 'fusta-clar'); cv.hl(12, 17, 5, 'fusta-ombra')
    cv.contorn()
    _ombra(cv, 4, 25, 32)
    return cv


def parada(c='vermell'):
    cv = Llenc(40, 36)
    cv.vl(4, 10, 22, 'fusta'); cv.vl(5, 10, 22, 'fusta-ombra'); cv.vl(34, 10, 22, 'fusta'); cv.vl(35, 10, 22, 'fusta-ombra')
    cv.rect(5, 20, 30, 12, 'fusta'); cv.hl(5, 20, 30, 'fusta-clar'); cv.hl(5, 31, 30, 'fusta-ombra')
    for x in range(9, 34, 5): cv.vl(x, 22, 9, 'fusta-ombra')
    cv.rect(6, 13, 28, 7, 'nit')
    # gènere
    for i, x in enumerate(range(7, 32, 3)):
        c2 = ['groc', 'taronja', 'fruit', 'groc', 'fulla-clar', 'taronja', 'flor', 'groc', 'fruit'][i]
        cv.rect(x, 17, 3, 3, c2); cv.p(x, 17, c2 + '-clar' if c2 in ('groc', 'flor', 'fruit', 'fulla') else c2)
        cv.rect(x + 1, 15, 2, 2, c2)
    # tendal ratllat
    for x in range(1, 39):
        col = c if (x // 4) % 2 == 0 else 'blanc'
        y0 = 4 if 3 < x < 36 else 5
        cv.vl(x, y0, 8 - (y0 - 4), col)
        cv.p(x, 11, (c + '-ombra') if col == c else 'blanc-ombra')
        if (x % 4) in (1, 2): cv.p(x, 12, (c + '-ombra') if col == c else 'blanc-ombra')
    cv.hl(3, 3, 34, 'blanc' ); cv.hl(3, 4, 34, c)
    cv.contorn()
    _ombra(cv, 3, 37, 34)
    return cv


def fanal():
    cv = Llenc(12, 30)
    cv.vl(5, 10, 17, 'fusta-ombra'); cv.vl(6, 10, 17, 'contorn'); cv.rect(4, 26, 4, 2, 'gris-ombra')
    cv.rect(3, 3, 6, 7, 'llum'); cv.rect(4, 4, 2, 3, 'llum-clar'); cv.hl(3, 9, 6, 'llum-ombra')
    cv.hl(2, 2, 8, 'contorn'); cv.hl(3, 1, 6, 'contorn'); cv.hl(2, 10, 8, 'contorn'); cv.vl(2, 3, 7, 'contorn'); cv.vl(9, 3, 7, 'contorn'); cv.p(5, 0, 'contorn'); cv.p(6, 0, 'contorn')
    return cv


def paller():
    cv = Llenc(26, 30)
    for y in range(3, 27):
        t = (y - 3) / 23
        r = 3 + 8.5 * math.sin(min(1, t * 1.25) * math.pi / 2)
        for x in range(int(13 - r), int(13 + r) + 1):
            dx = (x - 13) / r
            c = 'palla'
            if dx < -.3: c = 'palla-clar'
            if dx > .35: c = 'palla-ombra'
            if (x * 3 + y * 2) % 7 == 0: c = 'palla-ombra' if c != 'palla-ombra' else 'palla-fosc'
            cv.p(x, y, c)
    cv.vl(13, 0, 4, 'fusta')
    cv.contorn('palla-fosc')
    _ombra(cv, 3, 24, 28)
    return cv


def tanca():
    cv = Llenc(30, 14)
    for x in (2, 14, 26):
        cv.rect(x, 2, 2, 10, 'fusta'); cv.vl(x + 1, 2, 10, 'fusta-ombra'); cv.p(x, 2, 'fusta-clar')
    cv.rect(0, 4, 30, 2, 'fusta'); cv.hl(0, 5, 30, 'fusta-ombra'); cv.rect(0, 8, 30, 2, 'fusta'); cv.hl(0, 9, 30, 'fusta-ombra')
    cv.contorn()
    return cv


def fum():
    cv = Llenc(14, 22)
    for (x, y, r) in [(5, 18, 2.2), (7, 13, 3), (6, 7, 3.6), (9, 3, 2.4)]:
        cv.ellipse(x, y, r, r * .85, 'fum')
        cv.ellipse(x + 1, y + 1, r * .5, r * .4, 'fum-ombra')
    return cv


def marques():
    a = Llenc(12, 6)
    a.rect(2, 1, 8, 3, 'pedra-clar'); a.hl(3, 0, 6, 'pedra-clar'); a.hl(2, 3, 8, 'pedra'); a.hl(3, 4, 6, 'pedra-ombra'); a.p(4, 1, 'blanc')
    a.contorn('pedra-fosc')
    b = Llenc(14, 6)
    b.rect(2, 2, 10, 3, 'palla'); b.hl(3, 1, 8, 'palla-clar')
    for x in range(1, 13, 2): b.p(x, 1 + x % 3, 'palla-clar'); b.p(x + 1, 4, 'palla-ombra')
    b.contorn('palla-fosc')
    return a, b


def totes():
    a, b = marques()
    return {
        'ESC-NAIXEMENT': naixement(), 'ESC-MARIA': maria(), 'ESC-JOSEP': josep(), 'ESC-JESUS': jesus(), 'ESC-ANGEL': angel(),
        'ESC-ESTEL': estel(), 'ESC-FOGUERA': foguera(), 'ESC-REI-CAMELL': rei(), 'ESC-MOLI-AIGUA': moli_aigua(), 'ESC-PONT': pont(),
        'ESC-CASTELL': castell(), 'ESC-AQUEDUCTE': aqueducte(), 'ELE-MOLI-V': moli_vent(), 'ELE-POU': pou(), 'ELE-PARADA': parada(),
        'ELE-PARADA-B': parada('roba'), 'ELE-FANAL': fanal(), 'ELE-PALLER': paller(), 'ELE-TANCA': tanca(), 'DEC-FUM': fum(),
        'MARCA-PER': a, 'MARCA-ANI': b,
    }
