"""Mapa de llocs del pessebre v2: casc antic dens, nuclis de masos a la perifèria,
elements i punts de figura. Tot reposa sobre les feixes del terreny."""
import json, math, random, sys
import terreny as T
import peces as P

QUOTA = {
    'cases':    {'Z0': 38, 'Z1': 21, 'Z2': 21, 'Z3': 16},
    'elements': {'Z0': 106, 'Z1': 72, 'Z2': 50, 'Z3': 42},
    'persones': {'Z0': 221, 'Z1': 106, 'Z2': 85, 'Z3': 69},
    'animals':  {'Z0': 14, 'Z1': 15, 'Z2': 15, 'Z3': 15},
}
# files del casc antic: (feixa, x inicial, x final)
FILES = [(0, 990, 1205), (1, 938, 1272), (2, 892, 1328), (3, 858, 1368), (4, 838, 1388), (5, 832, 1394), (6, 852, 1380)]
TIPUS_CLASSE = [('LLARGA', 3), ('LLARGA-C', 3), ('FRONTAL', 2), ('MASIA', 1.4), ('ALTA', 2.2), ('BAIXA', .8), ('VESSANT', 1.5), ('CUPULA', .7), ('PEDRA', 2.5), ('TERRAT', .8)]
TIPUS_FAM = [('LLARGA', 2), ('LLARGA-C', 1.5), ('FRONTAL', 2), ('MASIA', 2.5), ('BAIXA', 2.5), ('VESSANT', 1.5), ('CUPULA', .6), ('PEDRA', 2.5), ('TERRAT', .6), ('ALTA', .5)]
ELEMENTS = [('ELE-ARBRE', 48), ('ELE-ARBRE-2', 34), ('ELE-FRUITER', 30), ('ELE-TARONGER', 16), ('ELE-AMETLLER', 18), ('ELE-PI', 24), ('ELE-XIPRER', 26), ('ELE-XIPRER-2', 14),
            ('ELE-PALMERA', 8), ('ELE-MATA-FLOR', 22), ('ELE-PALLER', 6)]   # + parades, pous i fanals posats a mà = 270


def tria(rng, llista):
    tot = sum(w for _, w in llista)
    r = rng.random() * tot
    for n, w in llista:
        r -= w
        if r <= 0:
            return n
    return llista[-1][0]


dins_casc = T.dins_casc


def prop_clariana(x, y, f=1.0):
    return ((x - T.CLAR[0]) / (175 * f)) ** 2 + ((y - T.CLAR[1] + 10) / (100 * f)) ** 2 < 1


class Mapa:
    def __init__(self, seed=21):
        self.rng = random.Random(seed)
        self.mask = T.fa_mascara(); self.mp = self.mask.load()
        self.reg = P.registre()
        self.peus = []        # petjades a terra (x0, y0, x1, y1)
        self.cossos = []      # caixes opaques de peces grans (x0, y0, x1, y1, ybase, mena)
        self.cases, self.elements, self.punts, self.fixos, self.decor = [], [], [], [], []
        self.murs, self.carrers, self.escales, self.camps = [], [], [], []

    # ---------- utilitats
    def caixa(self, codi, x, y, mirall=False):
        f = self.reg[codi]
        ax, ay = f['ancoratge']; x0, y0, x1, y1 = f['caixa']
        if mirall:
            w = f['viewBox'][2]
            x0, x1 = w - x1, w - x0
        return (x - ax + x0, y - ay + y0, x - ax + x1, y - ay + y1)

    def terra(self, x, y):
        x, y = int(x), int(y)
        if not (0 <= x < T.W and 0 <= y < T.H):
            return T.RESERVAT
        return self.mp[x, y]

    def peu_lliure(self, x, y, fw, fd, permesos=(T.HERBA,), marge=1):
        r = (x - fw / 2 - marge, y - fd - marge, x + fw / 2 + marge, y + 1 + marge)
        if r[0] < 2 or r[2] > T.W - 2 or r[3] > T.H - 2:
            return False
        for px_, py_ in ((x - fw / 2, y), (x + fw / 2, y), (x, y), (x, y - fd), (x - fw / 2, y - fd), (x + fw / 2, y - fd)):
            if self.terra(px_, py_) not in permesos:
                return False
        for (a, b, c, d) in self.peus:
            if r[0] < c and a < r[2] and r[1] < d and b < r[3]:
                return False
        return True

    def tapat(self, c, y, menes=None):
        """Fracció de la caixa c tapada per peces grans que queden al davant."""
        area = max(1, (c[2] - c[0]) * (c[3] - c[1]))
        pitjor = 0
        for (a, b, cc, d, yb, mena) in self.cossos:
            if yb <= y or (menes and mena not in menes):
                continue
            ix = min(c[2], cc) - max(c[0], a); iy = min(c[3], d) - max(c[1], b)
            if ix > 0 and iy > 0:
                pitjor = max(pitjor, ix * iy / area)
        return pitjor

    def tapa(self, c, y, menes=('casa',)):
        """Fracció màxima d'una peça de darrere que la caixa c taparia."""
        pitjor = 0
        for (a, b, cc, d, yb, mena) in self.cossos:
            if yb >= y or mena not in menes:
                continue
            ix = min(c[2], cc) - max(c[0], a); iy = min(c[3], d) - max(c[1], b)
            if ix > 0 and iy > 0:
                pitjor = max(pitjor, ix * iy / max(1, (cc - a) * (d - b)))
        return pitjor

    def posa(self, codi, x, y, mirall, fw, fd, mena):
        self.peus.append((x - fw / 2, y - fd, x + fw / 2, y + 1))
        if mena:
            self.cossos.append(self.caixa(codi, x, y, mirall) + (y, mena))

    # ---------- casc antic
    def casc_antic(self, pas=(4, 8)):
        rng = self.rng
        cases = []
        for r, (cx, half) in enumerate(T.CASC_FILES):
            xa, xb = cx - half, cx + half
            forats = [(px_ - w / 2, px_ + w / 2) for (px_, w, rr) in T.PLACETES if rr == r]
            x = xa
            while x < xb - 30:
                L = rng.randint(96, 190)                     # tram de carrer
                fi = min(xb, x + L)
                off = rng.randint(-6, 6)
                ini = x
                while x < fi - 14:
                    f = next((f for f in forats if f[0] - 30 < x < f[1]), None)
                    if f:
                        if x - ini > 20: self.carrers.append((r, round(ini) - 5, round(x) + 3, off))
                        x = f[1] + 2; ini = x
                        continue
                    t = tria(rng, TIPUS_CLASSE)
                    codi = f'CASA-{t}-P'
                    c = self.reg[codi]['caixa']; w = c[2] - c[0]
                    hx = x + w / 2
                    if hx + w / 2 > xb + 12 or any(f[0] - 6 < hx + w / 2 and hx - w / 2 < f[1] for f in forats) and False:
                        break
                    yf = T.fila_y(r, hx) + off
                    cases.append({'x': round(hx), 'y': round(yf - 6 - rng.randint(0, 7)), 'tipus': 'classe', 'vol': t.lower(), 'mirall': rng.random() < .5, 'zona': 'Z0', 'codi': codi, 'fila': r, 'yf': round(yf)})
                    x += w - rng.randint(*pas)
                if x - ini > 20: self.carrers.append((r, round(ini) - 5, round(x) + 3, off))
                if x < xb - 40:
                    self.escales.append((round(x) + 8, r, off)); x += 17
        return cases

    def casc_antic_74(self):
        estat = self.rng.getstate()
        for pas in [(4, 8), (5, 9), (6, 10), (7, 11), (8, 12), (3, 7), (2, 6)]:
            self.rng.setstate(estat); self.carrers, self.escales = [], []
            cases = self.casc_antic(pas)
            if len(cases) >= 74:
                break
        rng = self.rng
        while len(cases) > 74:      # treu sobrants dels extrems de les fileres més plenes
            k = max(set(c['fila'] for c in cases), key=lambda kk: sum(1 for c in cases if c['fila'] == kk))
            fila = [c for c in cases if c['fila'] == k]
            cases.remove(rng.choice([fila[0], fila[-1]]))
        self.cases = cases
        for c in self.cases:
            self.posa(c['codi'], c['x'], c['y'], c['mirall'], 40, 9, 'casa')

    # ---------- escena fixa
    def escena_fixa(self):
        rng = self.rng
        F = self.fixos
        nx, ny = T.NAIX
        F.append({'codi': 'ESC-NAIXEMENT', 'x': nx, 'y': ny, 'ordre': ny - 70})
        F.append({'codi': 'ESC-MARIA', 'x': nx - 19, 'y': ny - 26, 'colors': {'roba': '#3F7FD8', 'roba-clar': '#6FA3EA', 'roba-ombra': '#2A57A6'}})
        F.append({'codi': 'ESC-JESUS', 'x': nx + 1, 'y': ny - 25})
        F.append({'codi': 'ESC-JOSEP', 'x': nx + 22, 'y': ny - 26, 'mirall': True, 'colors': {'roba': '#9A6238', 'roba-clar': '#BC8450', 'roba-ombra': '#6E4226', 'mocador': '#E8D9B8', 'mocador-ombra': '#C2AE88'}})
        F.append({'codi': 'ESC-BOU', 'x': nx - 61, 'y': ny - 26})
        F.append({'codi': 'ESC-MULA', 'x': nx + 61, 'y': ny - 26, 'mirall': True})
        F.append({'codi': 'ESC-ANGEL', 'x': nx - 34, 'y': ny - 112, 'ordre': ny})
        F.append({'codi': 'ESC-ESTEL', 'x': nx + 6, 'y': 62, 'ordre': -1})
        self.cossos.append(self.caixa('ESC-NAIXEMENT', nx, ny) + (ny, 'fix'))
        # pastors
        cx, cy = T.CLAR
        F.append({'codi': 'ESC-FOGUERA', 'x': cx, 'y': cy + 2})
        F.append({'codi': 'ESC-ANGEL', 'x': cx + 4, 'y': cy - 78, 'ordre': cy + 40})
        self.peus.append((cx - 12, cy - 8, cx + 12, cy + 4))
        for i, (dx, dy, m) in enumerate([(-104, -4, False), (-96, 22, True), (100, 6, True), (88, 30, False), (-60, 40, False), (56, 46, True), (-128, 30, False), (124, 34, True)]):
            F.append({'codi': 'ANI-OVELLA-D', 'x': cx + dx, 'y': cy + dy, 'mirall': m})
            self.peus.append((cx + dx - 10, cy + dy - 6, cx + dx + 10, cy + dy + 1))
        # reis
        for i, (x, col) in enumerate([(118, ('#3F9A52', '#5DBE70', '#2B7040')), (182, ('#7A4FC0', '#9E78E0', '#553592')), (246, ('#D9443A', '#F0685A', '#A32C2C'))]):
            y = 716 - i
            F.append({'codi': 'ESC-REI-CAMELL', 'x': x, 'y': y, 'colors': {'roba': col[0], 'roba-clar': col[1], 'roba-ombra': col[2]}})
            self.peus.append((x - 22, y - 8, x + 22, y + 2))
            self.cossos.append(self.caixa('ESC-REI-CAMELL', x, y) + (y, 'fix'))
        # molí, pont, castell, aqüeducte, molí de vent
        F.append({'codi': 'ESC-MOLI-AIGUA', 'x': 742, 'y': 534, 'mirall': True}); self.cossos.append(self.caixa('ESC-MOLI-AIGUA', 742, 534, True) + (534, 'fix'))
        F.append({'codi': 'ESC-PONT', 'x': 750, 'y': 653, 'ordre': 600})
        F.append({'codi': 'ESC-CASTELL', 'x': 2140, 'y': round(T.carena(2140)) + 8, 'ordre': 0})
        F.append({'codi': 'ESC-AQUEDUCTE', 'x': 1900, 'y': round(T.carena(1900)) + 22, 'ordre': 0})
        F.append({'codi': 'ELE-MOLI-V', 'x': 1470, 'y': round(T.carena(1470)) + 26, 'ordre': 1})
        for (x, y, m) in [(820, 722, False), (905, 742, True), (868, 750, False), (960, 736, False)]:
            F.append({'codi': 'ANI-ANEC-D', 'x': x, 'y': y, 'mirall': m})
        # bosc de la clariana: arbres darrere i als costats, obert pel davant
        arb = ['ELE-ARBRE', 'ELE-ARBRE-2', 'ELE-PI', 'ELE-ARBRE', 'ELE-XIPRER', 'ELE-ARBRE-2', 'ELE-PI']
        for anell, (rx, ry, n) in enumerate([(108, 46, 15), (140, 66, 19), (176, 90, 22)]):
            for i in range(n):
                a = math.pi + (i + .5 * (anell % 2)) / n * math.pi * 1.0 + rng.uniform(-.06, .06)   # mitja el·lipse del darrere
                a2 = a if anell == 0 else math.pi * .88 + (i + rng.uniform(0, .5)) / n * math.pi * 1.24
                x = cx + math.cos(a2) * rx + rng.uniform(-5, 5); y = cy - 6 + math.sin(a2) * ry + rng.uniform(-4, 4)
                if y < T.carena(x) + 16 or x < 6:
                    continue
                if self.terra(x, y) in (T.AIGUA, T.CAMI_T):
                    continue
                codi = rng.choice(arb)
                F.append({'codi': codi, 'x': round(x), 'y': round(y), 'mirall': rng.random() < .5})
                self.peus.append((x - 7, y - 5, x + 7, y + 1)); self.cossos.append(self.caixa(codi, x, y) + (y, 'arbre'))
        for (dx, dy, c) in [(-84, 44, 'ELE-MATA'), (-40, 54, 'DEC-ROQUES'), (30, 58, 'ELE-MATA-FLOR'), (92, 50, 'ELE-MATA'), (-112, 46, 'DEC-ROQUES-2'), (128, 52, 'ELE-MATA-2')]:
            F.append({'codi': c, 'x': cx + dx, 'y': cy + dy})
        for i, (x, r, off) in enumerate(self.escales):
            c = ['ELE-XIPRER-2', 'ELE-TARONGER', 'ELE-MATA-FLOR', 'ELE-FRUITER', 'ELE-XIPRER-2', 'ELE-MATA-FLOR'][i % 6]
            y = round(T.fila_y(r, x) + off) - 2
            F.append({'codi': c, 'x': x + (11 if i % 2 else -11), 'y': y, 'mirall': False})
            self.peus.append((x - 18, y - 6, x + 18, y + 1))
        for (x, w, r) in T.PLACETES:
            for sg, c in ((-1, 'ELE-TARONGER'), (1, 'ELE-MATA-FLOR')):
                xx = round(x + sg * (w / 2 - 9)); y = round(T.fila_y(r, xx)) - 12
                F.append({'codi': c, 'x': xx, 'y': y}); self.peus.append((xx - 8, y - 5, xx + 8, y + 1))
        # teló d'arbres darrere el naixement
        for (dx, dy, c) in [(-128, -34, 'ELE-XIPRER'), (-112, -58, 'ELE-PI'), (-96, -80, 'ELE-XIPRER-2'), (-142, -8, 'ELE-ARBRE-2'), (126, -30, 'ELE-XIPRER'), (112, -56, 'ELE-ARBRE'),
                            (98, -82, 'ELE-XIPRER-2'), (144, -4, 'ELE-PI'), (-60, -128, 'ELE-ARBRE-2'), (-22, -136, 'ELE-PI'), (24, -134, 'ELE-ARBRE'), (64, -126, 'ELE-PALMERA'), (-150, 26, 'ELE-PALMERA'), (152, 28, 'ELE-MATA-FLOR')]:
            x, y = nx + dx, ny + dy
            F.append({'codi': c, 'x': x, 'y': y, 'mirall': rng.random() < .5})
            self.peus.append((x - 7, y - 5, x + 7, y + 1)); self.cossos.append(self.caixa(c, x, y) + (y, 'arbre'))

    # ---------- nuclis de cases de família
    def masos(self):
        rng = self.rng
        for z, n in QUOTA['cases'].items():
            fets, intents, centres = 0, 0, []
            while fets < n and intents < 30000:
                intents += 1
                a, b = rng.choices(T.FRANGES[z], [t[1] - t[0] for t in T.FRANGES[z]])[0]
                x = rng.uniform(a + 20, b - 20)
                k = rng.choice([1, 2, 3, 4, 5, 6, 7, 8, 8, 9, 9] if z == 'Z0' else [1, 2, 3, 4, 5, 6, 7, 8, 9])
                dmin = 96 if z != 'Z0' else 70
                if any(abs(x - c[0]) < dmin * 1.5 and abs(k - c[1]) < 1 for c in centres) or any(math.hypot(x - c[0], (T.nivell(k, x) - T.nivell(c[1], c[0])) * 1.6) < dmin for c in centres):
                    continue
                m = min(n - fets, rng.choice([2, 2, 3, 3, 4]))
                grup, xx = [], x
                for i in range(m):
                    t = tria(rng, TIPUS_FAM); codi = f'CASA-{t}-SP'
                    cb = self.reg[codi]['caixa']; w = cb[2] - cb[0]
                    cx = xx + w / 2
                    kk = k if (i < 3 or k >= 9) else k + 1
                    if i == 3:
                        cx = x + w / 2 + rng.randint(10, 30)
                    y = round(T.nivell(kk, cx) - 7 - rng.randint(0, 4))
                    if abs(cx - T.NAIX[0]) < 170 and T.NAIX[1] - 170 < y < T.NAIX[1] + 104:
                        break
                    if T.zona(round(cx)) != z or dins_casc(cx, y) or dins_casc(cx, y - 40) or prop_clariana(cx, y) or y > T.H - 8 or y - 62 < T.carena(cx):
                        break
                    if not self.peu_lliure(cx, y, w - 4, 12, marge=4):
                        break
                    cc = self.caixa(codi, cx, y)
                    if self.tapat(cc, y, ('casa', 'fix')) > .22 or self.tapa(cc, y, ('casa', 'fix')) > .22:
                        break
                    grup.append({'x': round(cx), 'y': y, 'tipus': 'familia', 'vol': t.lower(), 'mirall': rng.random() < .5, 'zona': z, 'codi': codi, 'fila': kk, 'w': w})
                    xx += w - rng.randint(2, 6) + (rng.randint(6, 16) if rng.random() < .3 else 0)
                if len(grup) < min(2, m):
                    continue
                centres.append((x, k))
                xs = [g['x'] for g in grup if g['fila'] == k]
                self.murs.append((k, round(min(xs) - 46), round(max(xs) + 46), 9))
                for g in grup:
                    w = g.pop('w')
                    self.cases.append(g); self.posa(g['codi'], g['x'], g['y'], g['mirall'], w - 4, 12, 'casa'); fets += 1
            if fets < n:
                print('AVÍS: cases de família', z, fets, '/', n)

    # ---------- elements
    def elements_(self):
        rng = self.rng
        E = self.elements
        def afegeix(codi, x, y, mena='arbre', fw=12, fd=6):
            x, y = round(x), round(y)
            E.append({'x': round(x), 'y': round(y), 'tipus': codi.split('-', 1)[1].lower(), 'zona': T.zona(x), 'codi': codi, 'mirall': rng.random() < .5})
            self.posa(codi, round(x), round(y), False, fw, fd, mena)
        # mercat: parades vora el camí, sota el poble i prop de la plaça
        for (x, c) in [(968, 'ELE-PARADA'), (1062, 'ELE-PARADA-B'), (1196, 'ELE-PARADA'), (1300, 'ELE-PARADA-B'), (1432, 'ELE-PARADA'), (1862, 'ELE-PARADA-B'), (640, 'ELE-PARADA'), (2090, 'ELE-PARADA')]:
            s = T.suau(T.CAMI, 6); y = min(s, key=lambda p: abs(p[0] - x))[1] - 13
            afegeix(c, x, y, 'element', 34, 8)
        # pous a les placetes i als masos
        for (x, w, r) in T.PLACETES[:3]:
            afegeix('ELE-POU', x, T.fila_y(r, x) - 5, 'element', 20, 6)
        for (x, y) in [(600, 590), (1930, 590), (420, 610)]:
            if self.peu_lliure(x, y, 20, 6):
                afegeix('ELE-POU', x, y, 'element', 20, 6)
        # fanals al llarg del camí
        s = T.suau(T.CAMI, 6)
        fan = 0
        for i in range(8, len(s) - 4, 9):
            if fan >= 14: break
            x, y = s[i][0], s[i][1] + (12 if i % 2 else -12)
            if self.peu_lliure(x, y, 6, 4, permesos=(T.HERBA, T.PLACA_T, T.EMPEDRAT)):
                afegeix('ELE-FANAL', x, y, None, 6, 4); fan += 1
        # la resta, per quota i zona
        per_zona = {z: sum(1 for e in E if e['zona'] == z) for z in QUOTA['elements']}
        for z, n in QUOTA['elements'].items():
            intents = 0
            while per_zona[z] < n and intents < 20000:
                intents += 1
                a, b = rng.choices(T.FRANGES[z], [t[1] - t[0] for t in T.FRANGES[z]])[0]
                x = round(rng.uniform(a + 6, b - 6)); y = round(rng.uniform(T.carena(x) + 34, T.H - 8))
                codi = tria(rng, ELEMENTS)
                if dins_casc(x, y) or dins_casc(x, y - 30):
                    continue
                if prop_clariana(x, y, .62) or (abs(x - T.NAIX[0]) < 128 and T.NAIX[1] - 10 < y < T.NAIX[1] + 96):
                    continue
                if not self.peu_lliure(x, y, 14, 6, marge=3):
                    continue
                cc = self.caixa(codi, x, y)
                if self.tapa(cc, y, ('casa',)) > .16 or self.tapa(cc, y, ('fix', 'element')) > .1 or self.tapat(cc, y, ('casa', 'fix')) > .45:
                    continue
                afegeix(codi, x, y, 'arbre' if 'MATA' not in codi and 'PALLER' not in codi else 'element', 14, 6)
                per_zona[z] += 1

    # ---------- punts de figura
    def punts_(self):
        rng = self.rng
        cand = []
        for c in self.cases:                       # davant de les cases
            if c['tipus'] == 'classe':
                cand.append((c['x'] + rng.randint(-13, 13), c['yf'] - rng.randint(1, 3)))
                if rng.random() < .3:
                    cand.append((c['x'] + rng.choice([-18, 18]), c['yf'] - 1))
            else:
                cand.append((c['x'] + rng.randint(-16, 16), c['y'] + rng.randint(4, 9)))
                cand.append((c['x'] + rng.randint(-30, 30), c['y'] + rng.randint(10, 18)))
        for (x, w, r) in T.PLACETES:               # placetes
            for i in range(5):
                xx = x - w / 2 + 9 + i * (w - 18) / 4
                cand.append((xx, T.fila_y(r, xx) - 2 - (i % 2) * 7))
        for pts in [T.CAMI] + T.BRANQUES:          # camins
            s = T.suau(pts, 6)
            acc, ant = 0, s[0]
            for p in s[1:]:
                acc += math.hypot(p[0] - ant[0], p[1] - ant[1]); ant = p
                if acc > 21:
                    acc = 0
                    cand.append((p[0] + rng.randint(-4, 4), p[1] + rng.choice([-5, -2, 2, 5, 9, -9])))
        cx, cy, rx, ry = T.PLACA_NAIX                # plaça del naixement: als costats i al davant, deixant l'escala neta
        for a in [x / 100 for x in range(8, 307, 13)]:
            for f in (.68, 1.0):
                x = cx + math.cos(a) * rx * f; y = cy + math.sin(a) * ry * f + 2
                if abs(x - cx) > 46 or y > cy + 16:
                    cand.append((x, y))
        rng.shuffle(cand)
        # prats: farciment
        prat = []
        fam = [c for c in self.cases if c['tipus'] == 'familia']
        camins = [p for pts in [T.CAMI] + T.BRANQUES for p in T.suau(pts, 6)]
        for i in range(14000):                       # farciment: sempre a prop de cases, camins o elements
            t = rng.random()
            if t < .45:
                c = rng.choice(fam); x = c['x'] + rng.uniform(-64, 64); y = c['y'] + rng.uniform(2, 34)
            elif t < .8:
                p = rng.choice(camins); x = p[0] + rng.uniform(-30, 30); y = p[1] + rng.uniform(-22, 24)
            elif t < .93:
                e = rng.choice(self.elements); x = e['x'] + rng.uniform(-26, 26); y = e['y'] + rng.uniform(2, 14)
            else:
                x = rng.uniform(8, T.W - 8); y = rng.uniform(T.carena(x) + 44, T.H - 6)
            if 8 < x < T.W - 8 and T.carena(x) + 40 < y < T.H - 6:
                prat.append((x, y))
        compte = {z: 0 for z in QUOTA['persones']}
        def prova(x, y, tipus, llista_ok):
            x, y = round(x), round(y)
            z = T.zona(x)
            if llista_ok[z] <= 0:
                return False
            if prop_clariana(x, y, .64) or (abs(x - T.NAIX[0]) < 40 and T.NAIX[1] - 4 < y < T.NAIX[1] + 26):
                return False
            if not self.peu_lliure(x, y, 13 if tipus == 'persona' else 18, 5, permesos=(T.HERBA, T.CAMI_T, T.PLACA_T, T.EMPEDRAT), marge=1):
                return False
            c = (x - 7, y - 23, x + 7, y) if tipus == 'persona' else (x - 10, y - 13, x + 10, y)
            if self.tapat(c, y) > (.3 if tipus == 'persona' else .2):
                return False
            if tipus == 'persona' and dins_casc(x, y) and self.tapa(c, y, ('casa',)) > .5:
                pass
            self.punts.append({'x': round(x), 'y': round(y), 'tipus': tipus, 'zona': z})
            self.peus.append((x - 7, y - 5, x + 7, y + 1))
            llista_ok[z] -= 1
            return True
        qp = dict(QUOTA['persones']); qa = dict(QUOTA['animals'])
        # animals: vora masos i prats (abans que les persones omplin)
        for c in self.cases:
            if c['tipus'] == 'familia' and rng.random() < .55:
                prova(c['x'] + rng.choice([-34, -28, 28, 34]), c['y'] + rng.randint(2, 12), 'animal', qa)
        for (x, y) in prat[:4000]:
            if not dins_casc(x, y) and self.terra(x, y) == T.HERBA:
                prova(x, y, 'animal', qa)
        for (x, y) in cand:
            prova(x, y, 'persona', qp)
        for (x, y) in prat[4000:]:
            if not dins_casc(x, y):
                prova(x, y, 'persona', qp)
        for z in qp:
            if qp[z] or qa[z]:
                print('AVÍS: punts pendents', z, qp[z], qa[z])
        # rotllana de pastors: 18 llocs en dues anelles, sempre oberts
        cx, cy = T.CLAR
        for (n, rx, ry, fase) in [(8, 50, 16, .3), (10, 82, 27, .0)]:
            for i in range(n):
                a = fase + i / n * 2 * math.pi
                if n == 10 and abs(math.sin(a) - 1) < .02:
                    continue
                self.punts.append({'x': round(cx + math.cos(a) * rx), 'y': round(cy + 4 + math.sin(a) * ry), 'tipus': 'pastor', 'zona': 'Z0'})

    def construeix(self):
        self.casc_antic_74()
        self.escena_fixa()
        self.masos()
        self.elements_()
        self.punts_()
        for i, c in enumerate(self.cases): c['id'] = f'C{i + 1:03d}'
        for i, c in enumerate(self.elements): c['id'] = f'E{i + 1:03d}'
        for i, c in enumerate(self.punts): c['id'] = f'P{i + 1:04d}'
        return self

    def recompte(self):
        r = {}
        for nom, llista, f in [('cases_classe', self.cases, lambda c: c['tipus'] == 'classe'), ('cases_familia', self.cases, lambda c: c['tipus'] == 'familia'),
                               ('elements', self.elements, lambda c: True), ('persones', self.punts, lambda c: c['tipus'] == 'persona'),
                               ('animals', self.punts, lambda c: c['tipus'] == 'animal'), ('pastors', self.punts, lambda c: c['tipus'] == 'pastor')]:
            d = {z: sum(1 for c in llista if f(c) and c['zona'] == z) for z in ('Z0', 'Z1', 'Z2', 'Z3')}
            d['total'] = sum(d.values()); r[nom] = d
        return r


if __name__ == '__main__':
    m = Mapa().construeix()
    print(json.dumps(m.recompte(), indent=1))
