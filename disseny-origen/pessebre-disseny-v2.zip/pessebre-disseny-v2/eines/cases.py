"""Cases del pessebre v2: generador paramètric de cases de poble antic de pagès.
ViewBox comú 64 x 78, ancoratge (32, 76)."""
import numpy as np
from px import Llenc, RNG, pedres, taques, _id

W, H, AX, AY = 64, 78, 32, 76
BASE = 75  # última filera de mur


def finestra(cv, x, y, w=5, h=6, flors=False, porticons=False, encesa=True, rng=None):
    cv.rect(x, y, w, h, 'contorn')
    if encesa:
        cv.rect(x + 1, y + 1, w - 2, h - 2, 'llum')
        cv.p(x + 1, y + 1, 'llum-clar')
        cv.hl(x + 1, y + h - 2, w - 2, 'llum-ombra')
        if w >= 5:
            cv.vl(x + w // 2, y + 1, h - 2, 'fusta-ombra')
        if h >= 7:
            cv.hl(x + 1, y + h // 2, w - 2, 'fusta-ombra')
    else:
        cv.rect(x + 1, y + 1, w - 2, h - 2, 'nit')
    cv.hl(x - 1, y - 1, w + 2, 'fusta')          # llinda de fusta
    cv.hl(x - 1, y + h, w + 2, 'pedra-clar')      # ampit de pedra
    cv.hl(x - 1, y + h + 1, w + 2, 'facana-ombra')
    if porticons:
        cv.rect(x - 2, y, 2, h, 'porta'); cv.vl(x - 2, y, h, 'porta-ombra')
        cv.rect(x + w, y, 2, h, 'porta'); cv.vl(x + w + 1, y, h, 'porta-ombra')
    if flors:
        for i in range(-1, w + 1):
            cv.p(x + i, y + h - 1, 'fulla' if i % 2 else 'fulla-clar')
            cv.p(x + i, y + h - 2, ['flor', 'flor-clar', 'fruit'][(i + x) % 3] if i % 2 == 0 else 'fulla-ombra')


def porta(cv, cx, w=8, h=12, arc=True):
    x = cx - w // 2
    y = BASE - h + 1
    # brancals i dovelles de pedra
    cv.rect(x - 2, y - 1 + (2 if arc else 0), w + 4, h + 1 - (2 if arc else 0), 'pedra')
    if arc:
        cv.rect(x - 1, y - 2, w + 2, 3, 'pedra'); cv.rect(x, y - 3, w, 1, 'pedra-clar')
        for i in range(0, w + 2, 2):
            cv.p(x - 1 + i, y - 2, 'pedra-ombra')
    else:
        cv.rect(x - 3, y - 3, w + 6, 3, 'fusta'); cv.hl(x - 3, y - 1, w + 6, 'fusta-ombra'); cv.hl(x - 3, y - 3, w + 6, 'fusta-clar')
    for yy in range(y + 2, BASE + 1, 3):
        cv.hl(x - 2, yy, 2, 'pedra-ombra'); cv.hl(x + w, yy + 1, 2, 'pedra-ombra')
    cv.vl(x - 2, y + 1, h - 1, 'pedra-clar')
    # fulla de porta
    cv.rect(x, y, w, h, 'porta')
    if arc:
        cv.p(x, y, 'pedra'); cv.p(x + w - 1, y, 'pedra')
        cv.p(x, y + 1, 'contorn'); cv.p(x + w - 1, y + 1, 'contorn')
        cv.hl(x + 1, y, w - 2, 'contorn')
        for yy in range(y + 2, BASE + 1):
            cv.p(x - 0, yy, 'contorn') if False else None
    else:
        cv.hl(x, y, w, 'porta-ombra')
    cv.vl(x, y + 2, h - 2, 'porta-ombra'); cv.vl(x + w - 1, y + 2, h - 2, 'porta-ombra')
    cv.vl(x + 1, y + 1, h - 1, 'porta-clar')
    for xx in range(x + 3, x + w - 1, 2):
        cv.vl(xx, y + 2, h - 2, 'porta-ombra')
    cv.hl(x + 1, y + h // 2, w - 2, 'porta-ombra')
    cv.p(x + w - 3, y + h // 2 + 2, 'or')
    # graó
    cv.hl(x - 3, BASE, w + 6, 'pedra-clar'); cv.hl(x - 3, BASE + 1, w + 6, 'pedra-ombra')


def teules(cv, m, rng, pas=3):
    """Textura de teula àrab sobre la màscara m (files de canals amb ombra)."""
    ys, xs = np.nonzero(m)
    y0 = ys.min()
    for y, x in zip(ys, xs):
        r = y - y0
        f = r // pas
        c = 'teulada'
        if r % pas == pas - 1:
            c = 'teulada-ombra' if (x + f) % 4 else 'teulada-fosc'
        elif (x + f * 2) % 4 == 0:
            c = 'teulada-ombra'
        elif (x + f * 2) % 4 == 2 and r % pas == 0:
            c = 'teulada-clar'
        cv.g[y, x] = _id(c)
    # carener clar i teules trencades
    for x in set(xs[ys == y0].tolist()):
        cv.g[y0, x] = _id('teulada-clar')
    for _ in range(max(1, len(ys) // 90)):
        i = rng.randrange(len(ys))
        cv.g[ys[i], xs[i]] = _id(rng.choice(['teulada-fosc', 'teulada-clar', 'pedra-ombra']))


def mur(cv, x0, x1, yT, rng, vista=False, costat=0):
    """Façana frontal x0..x1 i paret lateral (ombra) fins x1+costat."""
    cv.rect(x0, yT, x1 - x0 + 1, BASE - yT + 1, 'facana')
    m = np.zeros_like(cv.g, bool); m[yT:BASE + 1, x0:x1 + 1] = True
    if vista:
        pedres(cv, m, rng, base='facana', clar='facana-clar', ombra='facana-ombra', fosc='facana-fosc', alt=3)
    else:
        # arrebossat vell: clapes de llum, pedres que treuen el cap
        for _ in range((x1 - x0) * (BASE - yT) // 26):
            x = rng.randint(x0 + 1, x1 - 3); y = rng.randint(yT + 2, BASE - 5)
            w = rng.randint(2, 4)
            cv.hl(x, y, w, 'facana-ombra'); cv.p(x + w - 1, y + 1, 'facana-ombra')
            if rng.random() < .4:
                cv.hl(x, y - 1, w - 1, 'facana-clar')
        for _ in range(2):
            x = rng.randint(x0 + 2, x1 - 8); y = rng.randint(yT + 4, BASE - 10)
            mm = np.zeros_like(cv.g, bool); mm[y:y + rng.randint(4, 7), x:x + rng.randint(5, 9)] = True
            mm[y, x] = False; mm[y, min(cv.w - 1, x + 8)] = False
            pedres(cv, mm & m, rng, base='facana-ombra', clar='facana', ombra='facana-fosc', fosc='facana-fosc', alt=2)
        cv.vl(x0, yT, BASE - yT + 1, 'facana-clar'); cv.vl(x0 + 1, yT, BASE - yT + 1, 'facana-clar')
    cv.vl(x1, yT, BASE - yT + 1, 'facana-ombra')
    # sòcol de pedra
    ms = np.zeros_like(cv.g, bool); ms[BASE - 4:BASE + 1, x0:x1 + 1] = True
    pedres(cv, ms, rng, alt=3)
    # cantoneres
    for i, y in enumerate(range(BASE - 5, yT + 1, -3)):
        w = 4 if i % 2 else 2
        cv.rect(x0, y - 2, w, 3, 'pedra-clar'); cv.hl(x0, y, w, 'pedra-ombra')
        if not costat:
            cv.rect(x1 - w + 1, y - 2, w, 3, 'pedra'); cv.hl(x1 - w + 1, y, w, 'pedra-ombra')
    if costat:
        cv.rect(x1 + 1, yT, costat, BASE - yT + 1, 'facana-ombra')
        for _ in range(costat * (BASE - yT) // 16):
            x = rng.randint(x1 + 1, x1 + costat - 2); y = rng.randint(yT + 2, BASE - 3)
            cv.hl(x, y, 2, 'facana-fosc')
        cv.vl(x1 + 1, yT, BASE - yT + 1, 'facana-fosc')
        ms = np.zeros_like(cv.g, bool); ms[BASE - 4:BASE + 1, x1 + 1:x1 + costat + 1] = True
        pedres(cv, ms, rng, base='pedra-ombra', clar='pedra', ombra='pedra-fosc', alt=3)


def enfiladissa(cv, x, yT, rng, alt=None, flor='flor'):
    alt = alt or rng.randint(14, 26)
    xx = x
    for y in range(BASE - 1, BASE - alt, -1):
        xx += rng.choice([-1, 0, 0, 1])
        xx = max(x - 2, min(x + 3, xx))
        w = rng.randint(2, 4)
        for k in range(w):
            if cv.get(xx + k, y) not in ('llum', 'llum-clar', 'llum-ombra', 'porta', 'porta-clar', 'porta-ombra', None):
                cv.p(xx + k, y, rng.choice(['fulla', 'fulla', 'fulla-clar', 'fulla-ombra']))
        if rng.random() < .45:
            cv.p(xx + rng.randint(0, w - 1), y, rng.choice([flor, flor, flor + '-clar']))


def xemeneia(cv, x, y, h=7):
    cv.rect(x, y - h, 4, h, 'pedra'); cv.vl(x, y - h, h, 'pedra-clar'); cv.vl(x + 3, y - h, h, 'pedra-ombra')
    cv.rect(x - 1, y - h - 1, 6, 2, 'pedra-clar'); cv.hl(x - 1, y - h, 6, 'pedra-ombra')
    cv.hl(x, y - h - 2, 4, 'teulada-ombra')


def placa(cv, cx, y):
    cv.rect(cx - 7, y, 14, 5, 'placa'); cv.hl(cx - 7, y + 4, 14, 'placa-ombra'); cv.vl(cx + 6, y, 5, 'placa-ombra')
    cv.rect(cx - 8, y - 1, 16, 1, 'fusta-ombra'); cv.rect(cx - 8, y + 5, 16, 1, 'fusta-ombra')
    cv.vl(cx - 8, y, 5, 'fusta-ombra'); cv.vl(cx + 7, y, 5, 'fusta-ombra')


def casa(tipus, seed, amb_placa=True):
    rng = RNG(seed)
    cv = Llenc(W, H)
    T = {
        'LLARGA':   dict(w=40, h=30, costat=0, teul='llarga', rh=13),
        'LLARGA-C': dict(w=32, h=32, costat=9, teul='llarga', rh=13),
        'FRONTAL':  dict(w=36, h=30, costat=0, teul='frontal'),
        'MASIA':    dict(w=46, h=30, costat=0, teul='frontal', galeria=True),
        'ALTA':     dict(w=26, h=46, costat=6, teul='llarga', rh=11),
        'BAIXA':    dict(w=34, h=22, costat=0, teul='llarga', rh=12, porxo=True),
        'VESSANT':  dict(w=34, h=30, costat=0, teul='vessant'),
        'CUPULA':   dict(w=32, h=30, costat=0, teul='cupula'),
        'PEDRA':    dict(w=36, h=34, costat=7, teul='llarga', rh=12, vista=True),
        'TERRAT':   dict(w=34, h=34, costat=0, teul='plana'),
    }[tipus]
    w, h, costat = T['w'], T['h'], T['costat']
    porxo = T.get('porxo')
    tot = w + costat + (12 if porxo else 0)
    x0 = AX - tot // 2 + (12 if porxo else 0)
    x1 = x0 + w - 1
    xR = x1 + costat
    yT = BASE - h + 1
    cx = (x0 + x1) // 2
    teul = T['teul']

    # ---- cos
    if teul == 'frontal':
        gh = int(w * .34)
        cv.poli([(x0, yT), (cx, yT - gh), (cx + 1, yT - gh), (x1, yT)], 'facana')
        mur(cv, x0, x1, yT, rng, vista=T.get('vista', False))
    elif teul == 'vessant':
        d = 9
        cv.poli([(x0, yT - d), (x1, yT), (x0, yT)], 'facana')
        mur(cv, x0, x1, yT, rng)
        cv.vl(x0, yT - d, d, 'facana-clar'); cv.vl(x0 + 1, yT - d + 1, d, 'facana-clar')
    else:
        mur(cv, x0, x1, yT, rng, vista=T.get('vista', False), costat=costat)

    # ---- obertures
    pisos = 1 if h < 26 else (2 if h < 40 else 3)
    px = cx + rng.choice([-7, -4, 0, 4, 7]) if w >= 34 else cx + rng.choice([-3, 0, 3])
    arc = rng.random() < .65
    porta(cv, px, w=8 if w >= 30 else 7, h=13 if arc else 12, arc=arc)
    if amb_placa:
        placa(cv, max(x0 + 9, min(x1 - 8, px)), BASE - 23)
    # finestres per pis
    for pi in range(pisos):
        yb = BASE - 9 - pi * 14 - (6 if pi else 0)
        if pi == 0:
            xs = [x for x in (x0 + 4, x1 - 10) if abs(x + 3 - px) > 10]
            y = BASE - 12
        else:
            n = 2 if w < 34 else 3
            xs = [x0 + 4 + round(i * (w - 15) / (n - 1)) for i in range(n)]
            y = yT + 4 + (pisos - 1 - pi) * 13 if pisos == 3 else yT + 4
            if amb_placa and pisos == 2:
                y = yT + 3
        for i, x in enumerate(xs):
            fw = 7 if w >= 32 else 5
            if amb_placa and abs(y - (BASE - 23)) < 9 and abs(x + fw // 2 - max(x0 + 9, min(x1 - 8, px))) < 9 + fw // 2 + 2:
                continue
            finestra(cv, x, y, fw, 7 if pi else 6, flors=(pi > 0 and rng.random() < .45), porticons=(pi > 0 and w >= 40 and rng.random() < .35))
    if costat >= 6:
        finestra(cv, x1 + 2 + (costat - 5) // 2, yT + 6, 4, 5)
        cv.hl(x1 + 1, yT + 5, costat, 'facana-fosc') if False else None

    # ---- teulada
    if teul == 'llarga':
        rh = T['rh']
        m = np.zeros_like(cv.g, bool)
        for r in range(rh):
            t = (rh - 1 - r) / (rh - 1)
            a = x0 - 3 + round(t * 6)
            b = xR + 3 - round(t * (6 if not costat else 3 + costat * .9))
            m[yT - rh + r, a:b + 1] = True
        teules(cv, m, rng)
        cv.hl(x0 - 3, yT, xR - x0 + 7, 'contorn')
        cv.hl(x0, yT + 1, xR - x0 + 1, 'facana-fosc'); cv.hl(x0, yT + 2, x1 - x0 + 1, 'facana-ombra')
        if costat:   # aresta del carener cap al lateral
            cv.linia(xR + 2, yT - 1, x1 - 2, yT - rh, 'teulada-fosc')
        xemeneia(cv, x0 + rng.choice([5, w - 12]), yT - rh + 4, h=rng.randint(6, 8))
    elif teul == 'frontal':
        gh = int(w * .34)
        for s in (-1, 1):
            for i in range(0, w // 2 + 4):
                xx = cx + (0 if s < 0 else 1) + s * i
                yy = yT - gh - 2 + round(i * gh / (w / 2))
                for k in range(4):
                    c = ['teulada-clar', 'teulada', 'teulada', 'teulada-ombra'][k]
                    if i % 3 == 2 and k in (1, 2):
                        c = 'teulada-ombra'
                    if s > 0 and k == 0:
                        c = 'teulada'
                    cv.p(xx, yy + k, c)
                cv.p(xx, yy + 4, 'contorn')
        cv.rect(cx - 1, yT - gh - 4, 4, 3, 'teulada-clar')
        if T.get('galeria'):
            gy = yT - 5
            for i in range(-1, 2):
                gx = cx - 2 + i * 8
                cv.rect(gx, gy, 5, 6, 'contorn'); cv.rect(gx + 1, gy + 1, 3, 5, 'llum'); cv.p(gx + 1, gy + 1, 'llum-clar'); cv.hl(gx + 1, gy + 5, 3, 'llum-ombra')
                cv.p(gx, gy, 'facana'); cv.p(gx + 4, gy, 'facana')
            cv.hl(cx - 12, gy + 6, 26, 'fusta'); cv.hl(cx - 12, gy + 7, 26, 'fusta-ombra')
        else:
            cv.rect(cx - 1, yT - gh + 7, 4, 4, 'contorn'); cv.rect(cx, yT - gh + 8, 2, 2, 'llum')
        cv.hl(x0, yT, w, 'facana-ombra') if False else None
        xemeneia(cv, x1 - 9, yT - gh // 2 - 1, h=8)
    elif teul == 'vessant':
        d = 9
        m = np.zeros_like(cv.g, bool)
        for x in range(x0 - 3, x1 + 4):
            ya = yT - d + round((x - x0) * d / (w - 1))
            m[ya - 9:ya, x] = True
        for r in range(9):  # retall esquerre inclinat
            m[:, :x0 - 3 + (8 - r) // 3][yT - d - 12 + r:yT - d - 11 + r] = False
        teules(cv, m, rng)
        for x in range(x0 - 3, x1 + 4):
            ya = yT - d + round((x - x0) * d / (w - 1))
            cv.p(x, ya, 'contorn'); cv.p(x, ya + 1, 'facana-fosc') if x0 <= x <= x1 else None
        xemeneia(cv, x0 + 6, yT - d - 5, h=6)
    elif teul == 'cupula':
        cv.rect(x0 - 1, yT - 3, w + 2, 4, 'pedra'); cv.hl(x0 - 1, yT - 3, w + 2, 'pedra-clar'); cv.hl(x0 - 1, yT, w + 2, 'pedra-ombra')
        for xx in range(x0, x1, 4):
            cv.p(xx + 2, yT - 2, 'pedra-ombra')
        rx = w * .34; ry = rx * .72
        m0 = cv.plena().copy()
        cv.ellipse(cx + .5, yT - 3, rx, ry, 'teulada')
        m = cv.plena() & ~m0; m[yT - 3:, :] = False
        ys, xs = np.nonzero(m)
        for y, x in zip(ys, xs):
            dx = (x - cx) / rx; dy = (yT - 3 - y) / ry
            c = 'teulada'
            if dx < -.25 and dy > .35 and dx * dx + dy * dy < .8: c = 'teulada-clar'
            if dx > .45 or (dx > .2 and dy < .3): c = 'teulada-ombra'
            if abs(dx) > .05 and int(abs(dx) * 7 + dy * 1.5) != int(abs(dx) * 7 + dy * 1.5 + .22) and c != 'teulada-clar': c = 'teulada-ombra' if c == 'teulada' else 'teulada-fosc'
            cv.g[y, x] = _id(c)
        cv.rect(cx, yT - 3 - int(ry) - 4, 2, 4, 'or'); cv.p(cx, yT - 3 - int(ry) - 5, 'or')
    elif teul == 'plana':
        cv.rect(x0 - 1, yT - 4, w + 2, 5, 'pedra')
        mm = np.zeros_like(cv.g, bool); mm[yT - 4:yT + 1, x0 - 1:x1 + 2] = True
        pedres(cv, mm, rng, alt=3)
        for xx in range(x0 - 1, x1 + 1, 6):
            cv.rect(xx, yT - 6, 4, 2, 'pedra-clar'); cv.vl(xx + 3, yT - 6, 2, 'pedra-ombra')
        cv.hl(x0, yT + 1, w, 'facana-fosc'); cv.hl(x0, yT + 2, w, 'facana-ombra')
        # pèrgola amb roba estesa
        cv.vl(x0 + 4, yT - 13, 8, 'fusta'); cv.vl(x1 - 5, yT - 13, 8, 'fusta'); cv.hl(x0 + 2, yT - 13, w - 5, 'fusta-ombra')
        for i, xx in enumerate(range(x0 + 7, x1 - 8, 5)):
            cv.rect(xx, yT - 12, 4, 4 + i % 2, ['blanc', 'roba2', 'blanc-ombra', 'vermell'][i % 4])
        # tendal de la porta
        for i in range(-7, 8):
            cv.vl(px + i, BASE - 17, 3 if abs(i) < 7 else 2, 'vermell' if (i // 2) % 2 else 'blanc')
        cv.hl(px - 7, BASE - 14, 15, 'contorn')

    # ---- porxo de fusta (cobert) a l'esquerra
    if porxo:
        pxa = x0 - 12
        cv.rect(pxa + 1, BASE - 13, 11, 14, 'nit')
        cv.rect(pxa + 2, BASE - 6, 5, 7, 'palla'); cv.hl(pxa + 2, BASE - 6, 5, 'palla-clar'); cv.vl(pxa + 6, BASE - 5, 6, 'palla-ombra')
        cv.rect(pxa + 8, BASE - 4, 3, 5, 'fusta'); cv.hl(pxa + 8, BASE - 3, 3, 'fusta-ombra')
        cv.vl(pxa + 1, BASE - 13, 14, 'fusta'); cv.vl(pxa, BASE - 13, 14, 'fusta-clar')
        m = np.zeros_like(cv.g, bool)
        for r in range(6):
            m[BASE - 19 + r, pxa - 2 + (5 - r) // 2: x0 + 1] = True
        teules(cv, m, rng, pas=3)
        cv.hl(pxa - 2, BASE - 13, 14, 'contorn')

    # ---- vegetació enfilada i testos
    if rng.random() < .7:
        enfiladissa(cv, rng.choice([x0 + 1, x1 - 4]), yT, rng, flor=rng.choice(['flor', 'flor', 'fruit']))
    if rng.random() < .5:
        tx = rng.choice([x0 + 3, x1 - 5])
        if cv.get(tx, BASE - 1) not in ('porta', 'porta-ombra', 'porta-clar', 'pedra', 'pedra-clar', 'pedra-ombra') or True:
            cv.rect(tx, BASE - 1, 3, 2, 'teulada'); cv.hl(tx, BASE - 1, 3, 'teulada-clar')
            cv.rect(tx - 1, BASE - 4, 5, 3, 'fulla'); cv.p(tx, BASE - 4, 'flor'); cv.p(tx + 2, BASE - 3, 'flor-clar'); cv.p(tx + 1, BASE - 5, 'fulla-clar')

    cv.contorn()
    # ombra a terra (llum per l'esquerra)
    for x in range(x0 - (13 if porxo else 1), xR + 5):
        for y in (BASE + 1, BASE + 2):
            if cv.get(x, y) is None and x - (y - BASE) * 0 < W:
                cv.p(x, y, 'ombra-terra')
    return cv


TIPUS = ['LLARGA', 'LLARGA-C', 'FRONTAL', 'MASIA', 'ALTA', 'BAIXA', 'VESSANT', 'CUPULA', 'PEDRA', 'TERRAT']
PERSONALITZABLES = ['facana', 'teulada', 'porta']


def totes():
    out = {}
    for i, t in enumerate(TIPUS):
        out[f'CASA-{t}-P'] = casa(t, 100 + i, True)
        out[f'CASA-{t}-SP'] = casa(t, 100 + i, False)
    return out
