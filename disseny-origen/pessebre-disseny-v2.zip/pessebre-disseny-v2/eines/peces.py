"""Reuneix totes les peces, n'escriu els SVG i el registre.json."""
import json, os, sys
import numpy as np
import px, cases, natura, figures, escena, variants

PERSONALITZA = {
    'CASA': ['facana', 'teulada', 'porta'],
    'PER-ADU': ['roba', 'mocador'], 'PER-PAS': ['roba', 'mocador'], 'PER-INF': ['roba2'],
}
ANCORES = {'ESC-NAIXEMENT': (94, 134), 'ESC-ESTEL': (18, 24), 'ESC-ANGEL': (17, 28), 'ESC-PONT': (60, 37), 'DEC-FUM': (5, 21)}
_cache = None


def totes():
    global _cache
    if _cache is None:
        _cache = {}
        for m in (cases, natura, figures, escena, variants):
            _cache.update(m.totes())
    return _cache


def ancora(codi, cv):
    if codi in ANCORES:
        return ANCORES[codi]
    if codi.startswith('CASA'):
        return (cases.AX, cases.AY)
    if codi.startswith('DEC') or codi.startswith('MARCA') or codi in ('ESC-CASTELL', 'ESC-AQUEDUCTE'):
        return (cv.w // 2, cv.h - 1)
    return (cv.w // 2, cv.h - 2)


def categoria(codi):
    return {'CASA': 'casa', 'PER': 'persona', 'ANI': 'animal', 'ELE': 'element', 'ESC': 'escena', 'DEC': 'decoracio', 'MARCA': 'marca'}[codi.split('-')[0]]


def fitxa(codi, cv):
    ax, ay = ancora(codi, cv)
    m = cv.g != 0
    m &= cv.g != px._IDS['ombra-terra']
    ys, xs = np.nonzero(m)
    pers = []
    for pre, rols in PERSONALITZA.items():
        if codi.startswith(pre):
            pers = rols
    return {
        'fitxer': f'peces/{codi}.svg', 'categoria': categoria(codi), 'viewBox': [0, 0, cv.w, cv.h], 'ancoratge': [ax, ay],
        'caixa': [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1],
        'rols': cv.rols(), 'personalitzables': pers, 'placa': ([cases.AX - 8, cases.BASE - 24, 16, 7] if codi.endswith('-P') and codi.startswith('CASA') else None),
    }


def registre():
    return {c: fitxa(c, cv) for c, cv in totes().items()}


if __name__ == '__main__':
    arrel = sys.argv[1]
    os.makedirs(os.path.join(arrel, 'peces'), exist_ok=True)
    reg = registre()
    for c, cv in totes().items():
        with open(os.path.join(arrel, 'peces', c + '.svg'), 'w') as f:
            f.write(cv.svg(c, reg[c]['ancoratge']))
    json.dump({'versio': '2.0 (10 nov 2026)', 'nota': 'x, y dels JSON = punt d\'ancoratge. caixa = rectangle opac dins el viewBox. Cada rol té variants -clar, -ombra i -fosc.', 'colors': {n: v[0] for n, v in px.ROLS.items()}, 'opacitats': {n: v[1] for n, v in px.ROLS.items() if v[1] < 1}, 'peces': reg},
              open(os.path.join(arrel, 'registre.json'), 'w'), ensure_ascii=False, indent=1)
    print(len(reg), 'peces')
