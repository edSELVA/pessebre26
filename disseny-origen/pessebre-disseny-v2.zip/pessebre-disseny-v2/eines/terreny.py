"""Terreny del pessebre v2: vall orgànica vista des del vessant del davant.
Genera terreny.svg (capa de fons), llum.svg (capa de llum i atmosfera) i una
màscara de tipus de terra per col·locar-hi llocs."""
import math, random
from PIL import Image, ImageDraw

W, H = 2400, 800
NAIX = (1640, 590)          # ancoratge del naixement
CLAR = (345, 378)           # centre de la clariana dels pastors
FRANGES = {'Z0': [[780, 1820]], 'Z1': [[540, 780], [1820, 2020]], 'Z2': [[270, 540], [2020, 2210]], 'Z3': [[0, 270], [2210, 2400]]}


def zona(x):
    for z, trams in FRANGES.items():
        for a, b in trams:
            if a <= x < b:
                return z
    return 'Z3'


# ------------------------------------------------------------ relleu
def carena(x):
    """Línia on la vall toca el cel (turons propers)."""
    return (232 - 36 * math.exp(-((x - 1090) / 330) ** 2) - 30 * math.exp(-((x - 330) / 270) ** 2)
            - 48 * math.exp(-((x - 2130) / 230) ** 2) - 14 * math.exp(-((x - 1560) / 120) ** 2)
            + 6 * math.sin(x / 90) + 4 * math.sin(x / 37 + 1))


D = [44, 100, 158, 216, 276, 338, 400, 464, 530, 598]
NIV = len(D)


def nivell(k, x):
    """Alçada (y) de la feixa k a la posició x. k=0 és la més alta (lluny)."""
    t = (k + 1) / NIV
    lluny = carena(x) + D[k]
    prop = 232 + D[k] + 12 * math.sin(x / 260 + k * 1.3) - 10 * math.exp(-((x - NAIX[0]) / 260) ** 2) * (k - 5)
    y = lluny * (1 - t) + prop * t
    y += 5 * math.sin(x / 53 + k * 2.1) + 3 * math.sin(x / 23 + k)
    return y


def esglao(pts):
    """Camí SVG en escala (aspecte de píxel) a partir de punts (x, y)."""
    d = [f'M{pts[0][0]} {round(pts[0][1])}']
    py = round(pts[0][1])
    for x, y in pts[1:]:
        y = round(y)
        d.append(f'H{x}')
        if y != py:
            d.append(f'V{y}')
            py = y
    return ''.join(d)


def banda(f, x0=0, x1=W, pas=3, fins=H, dy=0):
    pts = [(x, f(x) + dy) for x in range(x0, x1 + 1, pas)]
    if pts[-1][0] != x1:
        pts.append((x1, f(x1) + dy))
    return esglao(pts) + f'V{fins}H{x0}Z'


def franja(f, x0, x1, g0, g1, pas=3):
    """Franja entre f(x)+g0 i f(x)+g1 (per a murs, vores i ombres)."""
    xs = list(range(x0, x1 + 1, pas))
    dalt = [(x, f(x) + (g0(x) if callable(g0) else g0)) for x in xs]
    baix = [(x, f(x) + (g1(x) if callable(g1) else g1)) for x in reversed(xs)]
    d = esglao(dalt)
    d += f'V{round(baix[0][1])}'
    py = round(baix[0][1])
    for x, y in baix[1:]:
        y = round(y)
        d += f'H{x}'
        if y != py:
            d += f'V{y}'; py = y
    return d + 'Z'


# ------------------------------------------------------------ traçats
RIU = [(742, 236, 8), (768, 282, 10), (734, 332, 12), (774, 388, 14), (732, 446, 16), (768, 506, 19), (744, 572, 22), (750, 640, 26), (766, 672, 36)]
ESTANYS = [(846, 724, 124, 40), (936, 738, 96, 32), (782, 704, 62, 28), (880, 700, 70, 22)]       # cx, cy, rx, ry (unió)
ESTANY = (862, 726, 168, 44)
SORTIDA = [(960, 745, 44), (1010, 775, 40), (1040, 805, 40)]

CAMI = [(-10, 708), (120, 716), (260, 712), (400, 698), (520, 672), (620, 648), (690, 634), (810, 634), (900, 648), (1010, 664),
        (1130, 672), (1260, 664), (1380, 646), (1480, 628), (1560, 618), (1640, 616), (1730, 620), (1850, 632), (1980, 654),
        (2110, 664), (2250, 652), (2410, 640)]
BRANQUES = [
    [(560, 662), (540, 610), (500, 560), (455, 510), (430, 460), (400, 420), (372, 398)],                 # cap a la clariana
    [(1760, 622), (1820, 560), (1880, 500), (1960, 440), (2030, 380), (2080, 320), (2110, 268)],          # cap al castell
    [(1980, 654), (2060, 700), (2150, 730), (2260, 742), (2410, 750)],                                    # cap als horts
    [(1380, 646), (1400, 610), (1408, 560), (1404, 500), (1396, 440)],                                    # pujada est del poble
    [(900, 648), (868, 600), (838, 550), (822, 490), (826, 430)],                                         # pujada oest del poble
    [(260, 712), (200, 660), (150, 600), (120, 540), (110, 480)],                                         # masos de ponent
    [(1130, 672), (1160, 720), (1220, 760), (1300, 805)],                                                 # cap al davant
    [(2250, 652), (2300, 600), (2330, 540), (2312, 470), (2270, 410), (2250, 350)],
    [(520, 672), (474, 720), (404, 760), (330, 805)],
    [(1480, 628), (1500, 690), (1544, 742), (1604, 805)],
    [(1850, 632), (1900, 700), (1962, 760), (2004, 805)],
    [(110, 480), (150, 430), (130, 370), (150, 310)],
    [(1404, 500), (1460, 470), (1500, 420), (1490, 360), (1520, 300)],
]
PLACA_NAIX = (NAIX[0], NAIX[1] + 22, 168, 30)
# ---- casc antic: turó de carrers esglaonats
CASC_FILES = [(1100, 104), (1120, 166), (1094, 214), (1112, 250), (1102, 274), (1116, 288), (1106, 290), (1112, 268)]   # (centre, mitja amplada) de cada filera
PLACETES = [(1108, 84, 3), (1004, 70, 5), (1240, 72, 6), (1170, 60, 1)]   # (x centre, amplada, filera)


def fila_y(r, x):
    return 252 + r * 47 + 11 * ((x - 1110) / 300) ** 2 + 4 * math.sin(x / 41 + r * 1.7)


def dins_casc(x, y, marge=26):
    if y < 252 - 80 or y > fila_y(7, x) + 20:
        return False
    r = max(0, min(7, (y - 252 + 28) / 47))
    a, b = CASC_FILES[int(r)], CASC_FILES[min(7, int(r) + 1)]
    t = r - int(r)
    cx = a[0] + (b[0] - a[0]) * t; half = a[1] + (b[1] - a[1]) * t
    return abs(x - cx) <= half + marge


def turo_casc():
    """Contorn suau i irregular del turó del poble (les cases en sobresurten)."""
    esq, dre = [], []
    for r, (cx, half) in enumerate(CASC_FILES):
        xe, xd = cx - half - 12 + 7 * math.sin(r * 2.3), cx + half + 12 + 7 * math.sin(r * 1.7 + 1)
        esq.append((xe, fila_y(r, xe) - (26 if r == 0 else 8)))
        dre.append((xd, fila_y(r, xd) - (26 if r == 0 else 8)))
    cx, half = CASC_FILES[-1]
    esq.append((cx - half - 22, fila_y(7, cx - half) + 10)); dre.append((cx + half + 22, fila_y(7, cx + half) + 10))
    baix = [(x, fila_y(7, x) + 12 + 2 * math.sin(x / 17)) for x in range(int(cx - half - 10), int(cx + half + 11), 20)]
    anell = suau_tancat(esq + baix + dre[::-1], 5)
    return anell


HORT = (2090, 712, 2392, 792)
# camps conreats sobre feixes: (feixa de dalt, x0, x1, patró)
CAMPS = [(4, 40, 236, 'vinya'), (6, 300, 470, 'solc'), (2, 1950, 2090, 'vinya'), (5, 2190, 2380, 'vinya'), (7, 1500, 1610, 'solc'), (3, 560, 690, 'vinya'), (8, 420, 560, 'solc')]


def camp_vores(k, x):
    return nivell(k, x) + 13, nivell(k + 1, x) - 20


def suau(pts, n=8):
    """Catmull-Rom per fer camins sinuosos."""
    out = []
    P = [pts[0]] + list(pts) + [pts[-1]]
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for j in range(n):
            t = j / n
            out.append(tuple(.5 * ((2 * p1[c]) + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t * t + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t ** 3) for c in range(len(p1))))
    out.append(tuple(pts[-1]))
    return out


def poligon_riu(pts):
    s = suau(pts, 10)
    esq, dre = [], []
    for i, p in enumerate(s):
        a = s[max(0, i - 1)]; b = s[min(len(s) - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(dx, dy) or 1
        nx, ny = -dy / L, dx / L
        w = p[2] / 2 + 1.5 * math.sin(i * .9)
        esq.append((round(p[0] + nx * w), round(p[1] + ny * w)))
        dre.append((round(p[0] - nx * w), round(p[1] - ny * w)))
    return esq + dre[::-1]


def suau_tancat(pts, n=5):
    out = []
    L = len(pts)
    for i in range(L):
        p0, p1, p2, p3 = pts[(i - 1) % L], pts[i], pts[(i + 1) % L], pts[(i + 2) % L]
        for j in range(n):
            t = j / n
            out.append(tuple(.5 * ((2 * p1[c]) + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t * t + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t ** 3) for c in range(2)))
    return out


def pts2d(pts):
    return 'M' + 'L'.join(f'{round(x)} {round(y)}' for x, y in pts) + 'Z'


def cami_d(pts):
    s = suau(pts, 6)
    return 'M' + 'L'.join(f'{round(p[0])} {round(p[1])}' for p in s)


# ------------------------------------------------------------ màscara
HERBA, CAMI_T, AIGUA, PLACA_T, RESERVAT, EMPEDRAT, CAMP = 0, 1, 2, 3, 4, 5, 6


def fa_mascara():
    im = Image.new('L', (W, H), HERBA)
    d = ImageDraw.Draw(im)
    for x in range(0, W, 2):                      # cel
        d.rectangle([x, 0, x + 2, carena(x) + 6], fill=RESERVAT)
    d.rectangle(HORT, fill=CAMP)
    for (k, xa, xb, _) in CAMPS:
        for x in range(xa, xb, 2):
            a, b = camp_vores(k, x)
            d.rectangle([x, a, x + 2, b], fill=CAMP)
    for pts in [CAMI] + BRANQUES:
        s = suau(pts, 6)
        d.line([(p[0], p[1]) for p in s], fill=CAMI_T, width=18)
    cx, cy, rx, ry = PLACA_NAIX
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=PLACA_T)
    d.polygon(poligon_riu(RIU), fill=AIGUA)
    s = suau(RIU, 10)
    d.line([(p[0], p[1]) for p in s], fill=AIGUA, width=30)
    for (cx, cy, rx, ry) in ESTANYS:
        d.ellipse([cx - rx - 6, cy - ry - 6, cx + rx + 6, cy + ry + 6], fill=AIGUA)
    d.polygon(poligon_riu(SORTIDA), fill=AIGUA)
    d.line([(p[0], p[1]) for p in SORTIDA], fill=AIGUA, width=52)
    # naixement i el seu respir
    d.polygon([(round(x), round(y)) for x, y in turo_casc()], fill=EMPEDRAT)
    d.rectangle([NAIX[0] - 112, NAIX[1] - 150, NAIX[0] + 112, NAIX[1] + 6], fill=RESERVAT)
    d.rectangle([60, 660, 306, 794], fill=RESERVAT)      # Reis
    # clariana
    d.ellipse([CLAR[0] - 92, CLAR[1] - 40, CLAR[0] + 92, CLAR[1] + 36], fill=RESERVAT)
    # pont i molí
    d.rectangle([686, 600, 814, 652], fill=RESERVAT)
    d.rectangle([690, 462, 806, 538], fill=RESERVAT)
    return im


# ------------------------------------------------------------ SVG
def muntanyes(rng, base, alt, n, c_llum, c_ombra, c_peu, idg):
    """Serra facetada: cares clares a l'esquerra i fosques a la dreta, amb boira al peu."""
    xs = [round((i + .5 + rng.uniform(-.3, .3)) * W / n) for i in range(n)]
    cims = [(-40, base - alt * .3)]
    for i, x in enumerate(xs):
        cims.append((x, base - alt * rng.uniform(.45, 1.0) if i % 2 == 0 else base - alt * rng.uniform(.05, .4)))
    cims.append((W + 40, base - alt * .4))
    def y_a(x):
        for (xa, ya), (xb, yb) in zip(cims, cims[1:]):
            if xa <= x <= xb:
                t = (x - xa) / (xb - xa)
                return ya + (yb - ya) * t + 2 * math.sin(x / 9)
        return base
    s = f'<path d="{banda(y_a, 0, W, 4, base + 80)}" fill="url(#{idg})"/>'
    # cares d'ombra: trams que baixen cap a la dreta
    for (xa, ya), (xb, yb) in zip(cims, cims[1:]):
        if yb > ya + 6:
            xm = xa + (xb - xa) * .35
            s += f'<path d="M{round(xa)} {round(ya)}L{round(xb)} {round(yb)}L{round(xb)} {base + 80}L{round(xm)} {base + 80}Z" fill="{c_ombra}" fill-opacity=".45"/>'
    return s


def svg_terreny(seed=4):
    rng = random.Random(seed)
    o = []
    A = o.append
    A(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" shape-rendering="crispEdges">')
    A('''<defs>
<linearGradient id="g-cel" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--cel-alt, #0A1247)"/><stop offset=".5" stop-color="var(--cel-mig, #1A2A7C)"/><stop offset=".85" stop-color="var(--cel-baix, #3B3C9C)"/><stop offset="1" stop-color="var(--cel-horitzo, #6B58B4)"/></linearGradient>
<linearGradient id="g-m1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--munt-lluny, #7C6CCB)"/><stop offset="1" stop-color="var(--munt-boira, #A89ADF)"/></linearGradient>
<linearGradient id="g-m2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--munt-mig, #5C56B4)"/><stop offset="1" stop-color="var(--munt-boira2, #8478CC)"/></linearGradient>
<linearGradient id="g-m3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--munt-prop, #3E4594)"/><stop offset="1" stop-color="var(--munt-boira3, #5A5CB0)"/></linearGradient>
<linearGradient id="g-turo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--turo, #2A6650)"/><stop offset="1" stop-color="var(--turo-baix, #3F8A4C)"/></linearGradient>
<pattern id="p-herba" width="48" height="32" patternUnits="userSpaceOnUse"><path d="M5 6h1v3h-1zM7 7h1v2h-1zM30 20h1v3h-1zM32 21h1v2h-1zM19 13h2v1h-2zM41 4h1v2h-1z" fill="var(--herba-brot, #B9DE58)" fill-opacity=".55"/><path d="M14 25h1v3h-1zM16 26h1v2h-1zM38 12h1v3h-1zM40 13h1v2h-1zM24 2h2v1h-2zM3 18h2v1h-2z" fill="var(--herba-fosca, #3F7F34)" fill-opacity=".4"/></pattern>
<pattern id="p-mur" width="44" height="12" patternUnits="userSpaceOnUse"><rect width="44" height="12" fill="var(--mur, #C9B397)"/><path d="M0 0h9v3h-9zM21 0h8v3h-8zM11 4h7v3h-7zM33 4h9v3h-9zM4 8h8v3h-8zM24 8h7v3h-7z" fill="var(--mur-clar, #E6D5BA)"/><path d="M10 0h10v3h-10zM30 0h13v3h-13zM0 4h10v3h-10zM19 4h13v3h-13zM13 8h10v3h-10zM32 8h11v3h-11z" fill="var(--mur, #C9B397)"/><path d="M0 3h44v1h-44zM0 7h44v1h-44zM0 11h44v1h-44zM9 0h1v3h-1zM20 0h1v3h-1zM29 0h1v3h-1zM43 0h1v3h-1zM10 4h1v3h-1zM18 4h1v3h-1zM32 4h1v3h-1zM42 4h1v3h-1zM3 8h1v3h-1zM12 8h1v3h-1zM23 8h1v3h-1zM31 8h1v3h-1z" fill="var(--mur-ombra, #9A836E)"/></pattern>
<pattern id="p-cami" width="40" height="24" patternUnits="userSpaceOnUse"><path d="M4 5h3v1h-3zM22 14h4v1h-4zM33 3h2v1h-2zM12 19h3v1h-3z" fill="var(--cami-ombra, #C7A56C)" fill-opacity=".7"/><path d="M15 8h3v1h-3zM30 18h3v1h-3zM2 14h2v1h-2z" fill="var(--cami-clar, #FFF1CC)" fill-opacity=".8"/></pattern>
<pattern id="p-llamb" width="20" height="10" patternUnits="userSpaceOnUse"><rect width="20" height="10" fill="var(--empedrat, #DCC49C)"/><path d="M0 0h8v4h-8zM10 5h8v4h-8z" fill="var(--empedrat-clar, #EDDAB4)"/><path d="M0 4h20v1h-20zM0 9h20v1h-20zM8 0h1v4h-1zM18 0h1v4h-1zM4 5h1v4h-1zM9 5h1v4h-1z" fill="var(--empedrat-ombra, #B79C76)"/></pattern>
<pattern id="p-aigua" width="40" height="16" patternUnits="userSpaceOnUse"><path d="M3 3h8v1h-8zM24 11h9v1h-9z" fill="var(--aigua-clar, #8FD0FA)"/><path d="M18 5h5v1h-5zM5 12h4v1h-4z" fill="var(--aigua-llum, #D6F0FF)" fill-opacity=".8"/><path d="M28 3h7v1h-7zM10 8h8v1h-8z" fill="var(--aigua-ombra, #2C68C4)" fill-opacity=".6"/></pattern>
<pattern id="p-solc" width="16" height="12" patternUnits="userSpaceOnUse"><rect width="16" height="12" fill="var(--solc, #8A5A3A)"/><path d="M0 9h16v3h-16z" fill="var(--solc-ombra, #6A4028)"/><path d="M0 0h16v1h-16z" fill="var(--solc-clar, #A8724A)"/><path d="M3 4h2v4h-2zM11 5h2v3h-2z" fill="var(--brot, #5FAF3C)"/><path d="M2 5h1v1h-1zM5 5h1v1h-1zM10 6h1v1h-1zM13 6h1v1h-1zM3 3h2v1h-2z" fill="var(--brot-clar, #9AD64E)"/></pattern>
<pattern id="p-vinya" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M2 5h5v4h-5zM9 6h3v3h-3z" fill="var(--vinya, #4C9A3A)"/><path d="M2 5h3v1h-3zM9 6h2v1h-2z" fill="var(--vinya-clar, #8ACB48)"/><path d="M3 9h3v1h-3zM10 9h1v2h-1zM4 10h1v2h-1z" fill="var(--vinya-ombra, #2F6B33)"/></pattern>
</defs>''')
    # ---- cel i estels
    A(f'<rect width="{W}" height="300" fill="url(#g-cel)"/>')
    est = []
    for _ in range(190):
        x, y = rng.randrange(4, W - 4), rng.randrange(4, 200)
        if y > carena(x) - 70 and rng.random() < .7:
            continue
        if rng.random() < .22:
            est.append(f'M{x - 2} {y}h5v1h-5zM{x} {y - 2}h1v5h-1z')
        else:
            est.append(f'M{x} {y}h{rng.choice([1, 2, 2])}v{rng.choice([1, 2])}h-1z')
    A(f'<path d="{"".join(est[:120])}" fill="var(--estel-fi, #FFFFFF)" fill-opacity=".9"/><path d="{"".join(est[120:])}" fill="var(--estel-fi2, #FFE9A8)" fill-opacity=".8"/>')
    # ---- sol (només visible de dia i a la posta; posició per variables CSS --sol-x / --sol-y)
    A('<g id="sol" style="opacity:var(--sol-op,0);transform:translate(var(--sol-x,0px),var(--sol-y,0px))">'
      '<circle r="120" fill="var(--sol,#FFF3B0)" fill-opacity=".16"/><circle r="70" fill="var(--sol,#FFF3B0)" fill-opacity=".24"/>'
      '<circle r="34" fill="var(--sol,#FFF3B0)"/><circle r="26" fill="#FFFFFF" fill-opacity=".7"/></g>')
    # ---- muntanyes en tres plans
    A(muntanyes(rng, 196, 120, 26, '', '#5B4FB0', '', 'g-m1'))
    A(muntanyes(rng, 214, 86, 20, '', '#3F3F96', '', 'g-m2'))
    A(muntanyes(rng, 232, 52, 16, '', '#2A3078', '', 'g-m3'))
    # ---- turons del fons (bosc fosc)
    def turo(x):
        return carena(x) - 20 - 14 * math.sin(x / 150 + 2) - 8 * math.sin(x / 61) - 3 * abs(math.sin(x / 7))
    A(f'<path d="{banda(turo, 0, W, 2, 330)}" fill="url(#g-turo)"/>')
    cop = []
    for _ in range(260):
        x = rng.randrange(0, W); y = turo(x) + rng.randrange(4, 22)
        r = rng.choice([3, 4, 5])
        cop.append(f'M{x - r} {round(y)}h{2 * r}v{r}h-{2 * r}zM{x - r + 1} {round(y) - 1}h{2 * r - 2}v1h-{2 * r - 2}z')
    A(f'<path d="{"".join(cop[:130])}" fill="var(--turo-llum, #4E9A56)" fill-opacity=".8"/><path d="{"".join(cop[130:])}" fill="var(--turo-ombra, #1F5046)" fill-opacity=".7"/>')
    # ---- feixes: de lluny a prop, verds esglaonats
    A(f'<path d="{banda(carena, 0, W, 3)}" fill="var(--feixa-0, #4E9446)"/>')
    tons = ['#539640', '#5FA03F', '#6CAA3E', '#79B33E', '#84BA3F', '#8BBF41', '#86B93E', '#7CB03B', '#72A738', '#689E35']
    for k in range(NIV):
        f = (lambda kk: (lambda x: nivell(kk, x)))(k)
        A(f'<path d="{banda(f, 0, W, 3)}" fill="var(--feixa-{k + 1}, {tons[k]})"/>')
        # llum al caire i ombra del marge
        A(f'<path d="{franja(f, 0, W, -2, 0)}" fill="var(--feixa-caire, #C4E460)" fill-opacity=".5"/>')
        A(f'<path d="{franja(f, 0, W, 0, 4)}" fill="var(--feixa-ombra, #2F6B33)" fill-opacity=".45"/>')
        A(f'<path d="{franja(f, 0, W, 4, 9)}" fill="var(--feixa-ombra, #2F6B33)" fill-opacity=".18"/>')
    cl, fo = [], []
    for _ in range(46):
        x = rng.randrange(0, W); y = rng.randrange(int(carena(x)) + 40, H)
        (cl if rng.random() < .5 else fo).append(rodona(x, y, rng.randrange(50, 150), rng.randrange(12, 30), 3))
    A(f'<path d="{"".join(cl)}" fill="var(--herba-clapa, #C6E25A)" fill-opacity=".2"/><path d="{"".join(fo)}" fill="var(--feixa-ombra, #2F6B33)" fill-opacity=".16"/>')
    A(f'<path d="{banda(carena, 0, W, 3)}" fill="url(#p-herba)"/>')
    return o, rng


def rodona(cx, cy, rx, ry, pas=2):
    """El·lipse amb vora de píxel."""
    d = []
    for y in range(int(cy - ry), int(cy + ry) + 1, pas):
        t = 1 - ((y + pas / 2 - cy) / ry) ** 2
        if t <= 0:
            continue
        w = rx * math.sqrt(t)
        d.append(f'M{round(cx - w)} {y}h{round(2 * w)}v{pas}h-{round(2 * w)}z')
    return ''.join(d)
