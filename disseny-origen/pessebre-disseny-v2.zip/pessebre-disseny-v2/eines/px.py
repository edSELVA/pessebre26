"""Eina de píxels per a les peces del pessebre v2.

Cada peça es dibuixa sobre una graella (1 píxel = 1 unitat) on cada cel·la
guarda un ROL de color. En exportar, cada rol esdevé un <path> amb
fill="var(--rol, #valor)". Sense imatges, filtres ni text.
"""
import random
import numpy as np

# ---------------------------------------------------------------- rols
ROLS = {}      # nom -> (hex, opacitat)
_IDS = {}      # nom -> id enter
_NOMS = [None]


def rol(nom, hexa, op=1.0):
    if nom not in _IDS:
        _IDS[nom] = len(_NOMS)
        _NOMS.append(nom)
    ROLS[nom] = (hexa, op)
    return nom


def _id(c):
    if c is None:
        return 0
    return _IDS[c]


# Paleta base (valors per defecte). Rols personalitzables: tríades clar/base/ombra.
for n, h in {
    'contorn': '#3A2820',
    # façana
    'facana-clar': '#FFEFCB', 'facana': '#F5D9A8', 'facana-ombra': '#D8AE7C', 'facana-fosc': '#B98A60',
    # pedra (murs, sòcols, cantoneres)
    'pedra-clar': '#E9DAC2', 'pedra': '#CDB79C', 'pedra-ombra': '#A48D76', 'pedra-fosc': '#7A6658',
    # teulada
    'teulada-clar': '#F08A55', 'teulada': '#D9603A', 'teulada-ombra': '#A8402C', 'teulada-fosc': '#7A2C22',
    # fusta / porta
    'porta-clar': '#B07A46', 'porta': '#8A5A35', 'porta-ombra': '#633D24',
    'fusta-clar': '#B88350', 'fusta': '#8F6038', 'fusta-ombra': '#5E3C24',
    # llum
    'llum-clar': '#FFF3A8', 'llum': '#FFD24F', 'llum-ombra': '#F09A32',
    'placa': '#F6E6C0', 'placa-ombra': '#D4BC8E',
    # vegetació
    'fulla-llum': '#B0DC58', 'fulla-clar': '#7DC046', 'fulla': '#4E9B3B', 'fulla-ombra': '#2F7737', 'fulla-fosc': '#1D5230',
    'xiprer-clar': '#4E9A5A', 'xiprer': '#2F7446', 'xiprer-ombra': '#1E5238', 'xiprer-fosc': '#143A2C',
    'tronc-clar': '#A9744A', 'tronc': '#7C5133', 'tronc-ombra': '#573622',
    'flor-clar': '#FFA6CE', 'flor': '#F0649E', 'flor-ombra': '#B93C78',
    'fruit': '#E5443A', 'fruit-clar': '#FF8A6A',
    'groc-clar': '#FFF0A0', 'groc': '#FFD23F', 'groc-ombra': '#E0A020', 'taronja': '#F39A2E',
    'herba-clar': '#B4D94F', 'herba': '#8CBF3F', 'herba-ombra': '#5E9A37',
    # aigua
    'aigua-clar': '#8FD0FA', 'aigua': '#4696E6', 'aigua-ombra': '#2C68C4', 'escuma': '#EAF7FF',
    # persones
    'pell': '#F6C89A', 'pell-ombra': '#D99C70',
    'roba-clar': '#6FA3EA', 'roba': '#3F7FD8', 'roba-ombra': '#2A57A6',
    'roba2-clar': '#F2B054', 'roba2': '#E39A2E', 'roba2-ombra': '#B4731F',
    'mocador-clar': '#FFFFFF', 'mocador': '#F3EBDD', 'mocador-ombra': '#CBBBA4',
    'cabell': '#6B4630', 'cabell-ombra': '#4A2E20',
    'blanc': '#FFFFFF', 'blanc-ombra': '#DCD8E6', 'llana': '#FBF6EA', 'llana-ombra': '#D9CDB8',
    'gris-clar': '#B7B2B8', 'gris': '#8E8992', 'gris-ombra': '#625E6A',
    'bru-clar': '#D59A5A', 'bru': '#B5733A', 'bru-ombra': '#84502A',
    'camell-clar': '#F3BE6A', 'camell': '#DB9A44', 'camell-ombra': '#A96E2C',
    'palla-clar': '#FFE48A', 'palla': '#F2C24E', 'palla-ombra': '#C8922E', 'palla-fosc': '#96681F',
    'or': '#FFD23F', 'or-ombra': '#D9A21E',
    'foc-clar': '#FFF2A0', 'foc': '#FFB52E', 'foc-ombra': '#F0642A',
    'vermell': '#D9443A', 'vermell-ombra': '#A32C2C', 'verd': '#3F9A52', 'verd-ombra': '#2B7040',
    'lila': '#8A5FC0', 'lila-ombra': '#5E3F92',
    'terra-clar': '#F6E2B4', 'terra': '#E6C88E', 'terra-ombra': '#C29E66',
    'solc': '#8A5A3A', 'solc-ombra': '#6A4028',
    'nit': '#22264A',
}.items():
    rol(n, h)
rol('ombra-terra', '#1B2A2A', 0.28)
rol('halo', '#FFE08A', 0.35)
rol('fum', '#F4F1FA', 0.75)
rol('fum-ombra', '#C9C4DE', 0.75)


# ---------------------------------------------------------------- llenç
class Llenc:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.g = np.zeros((h, w), dtype=np.int16)

    # primitives
    def p(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.g[y, x] = _id(c)

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return _NOMS[self.g[y, x]]
        return None

    def rect(self, x, y, w, h, c):
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(self.w, x + w), min(self.h, y + h)
        if x1 > x0 and y1 > y0:
            self.g[y0:y1, x0:x1] = _id(c)

    def hl(self, x, y, w, c):
        self.rect(x, y, w, 1, c)

    def vl(self, x, y, h, c):
        self.rect(x, y, 1, h, c)

    def linia(self, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        e = dx + dy
        while True:
            self.p(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * e
            if e2 >= dy:
                e += dy; x0 += sx
            if e2 <= dx:
                e += dx; y0 += sy

    def poli(self, pts, c):
        ys = [p[1] for p in pts]
        for y in range(int(min(ys)), int(max(ys)) + 1):
            xs = []
            n = len(pts)
            for i in range(n):
                (xa, ya), (xb, yb) = pts[i], pts[(i + 1) % n]
                if ya == yb:
                    if y == ya:
                        xs += [xa, xb]
                    continue
                if min(ya, yb) <= y <= max(ya, yb):
                    t = (y - ya) / (yb - ya)
                    xs.append(xa + t * (xb - xa))
            if xs:
                self.hl(int(round(min(xs))), y, int(round(max(xs))) - int(round(min(xs))) + 1, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                if ((x - cx) / max(rx, .01)) ** 2 + ((y - cy) / max(ry, .01)) ** 2 <= 1.0:
                    self.p(x, y, c)

    # màscares i ombrejat
    def mask(self, *cs):
        ids = [_id(c) for c in cs]
        return np.isin(self.g, ids)

    def plena(self):
        return self.g != 0

    def pinta(self, m, c):
        self.g[m] = _id(c)

    def substitueix(self, a, b):
        self.g[self.g == _id(a)] = _id(b)

    def contorn(self, c='contorn', dins=None, diag=False):
        """Pinta de contorn les cel·les buides veïnes de cel·les plenes."""
        f = self.g != 0
        if dins is not None:
            f = f & dins
        v = np.zeros_like(f)
        v[1:, :] |= f[:-1, :]; v[:-1, :] |= f[1:, :]
        v[:, 1:] |= f[:, :-1]; v[:, :-1] |= f[:, 1:]
        if diag:
            v[1:, 1:] |= f[:-1, :-1]; v[:-1, :-1] |= f[1:, 1:]
            v[1:, :-1] |= f[:-1, 1:]; v[:-1, 1:] |= f[1:, :-1]
        self.g[v & (self.g == 0)] = _id(c)

    def blit(self, o, x, y, mirall=False):
        g = o.g[:, ::-1] if mirall else o.g
        for yy in range(o.h):
            for xx in range(o.w):
                if g[yy, xx]:
                    X, Y = x + xx, y + yy
                    if 0 <= X < self.w and 0 <= Y < self.h:
                        self.g[Y, X] = g[yy, xx]

    def retalla(self):
        ys, xs = np.nonzero(self.g)
        return xs.min(), ys.min(), xs.max(), ys.max()

    # exportació
    def camins(self):
        out = []
        for i in sorted(set(self.g.flatten().tolist()) - {0}):
            m = self.g == i
            runs = {}  # (x,w) -> llista de y
            rects = []
            oberts = {}
            for y in range(self.h):
                fila = m[y]
                nous = {}
                x = 0
                while x < self.w:
                    if fila[x]:
                        x0 = x
                        while x < self.w and fila[x]:
                            x += 1
                        k = (x0, x - x0)
                        if k in oberts:
                            nous[k] = oberts.pop(k)
                        else:
                            nous[k] = y
                    else:
                        x += 1
                for (x0, w), y0 in oberts.items():
                    rects.append((x0, y0, w, y - y0))
                oberts = nous
            for (x0, w), y0 in oberts.items():
                rects.append((x0, y0, w, self.h - y0))
            rects.sort(key=lambda r: (r[1], r[0]))
            d = ''.join(f'M{x} {y}h{w}v{h}h-{w}z' for x, y, w, h in rects)
            out.append((_NOMS[i], d))
        return out

    def svg_interior(self, sagnat='  '):
        s = []
        for nom, d in self.camins():
            hexa, op = ROLS[nom]
            o = f' fill-opacity="{op}"' if op < 1 else ''
            s.append(f'{sagnat}<path class="{nom}" fill="var(--{nom}, {hexa})"{o} d="{d}"/>')
        return '\n'.join(s)

    def svg(self, codi, ancora):
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" width="{self.w}" height="{self.h}" '
                f'shape-rendering="crispEdges" data-codi="{codi}" data-ancoratge="{ancora[0]},{ancora[1]}">\n'
                + self.svg_interior() + '\n</svg>\n')

    def rols(self):
        return [_NOMS[i] for i in sorted(set(self.g.flatten().tolist()) - {0})]


# ---------------------------------------------------------------- textures
def pedres(cv, m, rng, base='pedra', clar='pedra-clar', ombra='pedra-ombra', fosc='pedra-fosc', alt=3, densitat=1.0):
    """Mur de pedra seca: filades irregulars amb junta fosca."""
    ys, xs = np.nonzero(m)
    if len(ys) == 0:
        return
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    y = y0
    fila = 0
    while y <= y1:
        h = alt + (rng.random() < .3)
        x = x0 - rng.randint(0, 3)
        while x <= x1:
            w = rng.randint(3, 7)
            to = rng.choice([base, base, base, clar, clar, ombra])
            if rng.random() > densitat:
                to = None
            for yy in range(y, min(y + h, y1 + 1)):
                for xx in range(x, x + w):
                    if 0 <= xx < cv.w and m[yy, xx]:
                        if to is None:
                            continue
                        c = to
                        if yy == y + h - 1 or xx == x + w - 1:
                            c = ombra if to != ombra else fosc
                        elif yy == y and to == base and rng.random() < .5:
                            c = clar
                        cv.g[yy, xx] = _id(c)
            x += w
        y += h
        fila += 1


def taques(cv, m, rng, c, n, mida=(1, 3)):
    ys, xs = np.nonzero(m)
    if len(ys) == 0:
        return
    for _ in range(n):
        i = rng.randrange(len(ys))
        w = rng.randint(*mida)
        for k in range(w):
            x = xs[i] + k
            if x < cv.w and m[ys[i], x]:
                cv.g[ys[i], x] = _id(c)


def RNG(s):
    return random.Random(s)
